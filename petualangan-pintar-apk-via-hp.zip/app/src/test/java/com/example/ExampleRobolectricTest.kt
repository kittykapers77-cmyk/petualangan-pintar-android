package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.AppDatabase
import com.example.data.local.CategoryProgressEntity
import com.example.data.local.GameDao
import com.example.data.local.UserProfileEntity
import com.example.data.model.AgeBracket
import com.example.data.model.QuestionAnswerRecord
import com.example.data.model.QuizCategory
import com.example.data.repository.GameRepository
import com.example.data.source.QuestionBank
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    private lateinit var db: AppDatabase
    private lateinit var dao: GameDao
    private lateinit var repository: GameRepository

    @Before
    fun setup() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        dao = db.gameDao()
        repository = GameRepository(dao)
    }

    @After
    fun tearDown() {
        db.close()
    }

    @Test
    fun `read app_name string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Petualangan Pintar", appName)
    }

    @Test
    fun `verify database seeding and quiz completion persistence`() = runBlocking {
        AppDatabase.seedInitialData(dao)

        val questions = QuestionBank.getQuestionsForQuiz(QuizCategory.MATEMATIKA, AgeBracket.AGE_5_6, limit = 10)
        assertEquals(10, questions.size)

        // Simulate 10 correct answers with 0 hints
        val records = questions.map { q ->
            QuestionAnswerRecord(
                question = q,
                selectedOptionIndex = q.correctIndex,
                isCorrect = true,
                usedHint = false
            )
        }

        val summary = repository.recordQuizCompletion(
            category = QuizCategory.MATEMATIKA,
            ageBracket = AgeBracket.AGE_5_6,
            records = records
        )

        assertEquals(10, summary.correctCount)
        assertEquals(3, summary.starsEarned)
        assertTrue("Badges should be unlocked on first perfect quiz", summary.newBadgesUnlocked.isNotEmpty())

        val mathProgress = dao.getCategoryProgress("math")
        assertNotNull(mathProgress)
        assertEquals(3, mathProgress?.starsEarned)
        assertEquals(10, mathProgress?.highestScore)
        assertEquals(1, mathProgress?.timesPlayed)
    }

    @Test
    fun `verify reset progress clears stars and resets badges`() = runBlocking {
        AppDatabase.seedInitialData(dao)

        dao.insertCategoryProgress(
            CategoryProgressEntity(categoryId = "math", starsEarned = 15, highestScore = 10, timesPlayed = 5, currentLevel = 3)
        )
        dao.insertOrUpdateProfile(
            UserProfileEntity(id = 1, totalStars = 15, completedQuizzesCount = 5, explorerRank = "Kapten Petualang")
        )

        repository.resetAllProgress()

        val mathAfterReset = dao.getCategoryProgress("math")
        assertEquals(0, mathAfterReset?.starsEarned ?: 0)
        assertEquals(0, mathAfterReset?.highestScore ?: 0)
    }
}
