package com.example

import com.example.data.model.AgeBracket
import com.example.data.model.QuizCategory
import com.example.data.source.QuestionBank
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun verifyTotalQuestionCountIsAtLeast2000() {
        val total = QuestionBank.allQuestions.size
        assertTrue("Total soal harus minimal 2.000, ditemukan: $total", total >= 2000)
        assertEquals("Total soal harus tepat 2.000", 2000, total)
    }

    @Test
    fun verifyCategoryQuestionCounts() {
        val mathCount = QuestionBank.allQuestions.count { it.category == QuizCategory.MATEMATIKA }
        val bahasaCount = QuestionBank.allQuestions.count { it.category == QuizCategory.BAHASA_INDONESIA }
        val logikaCount = QuestionBank.allQuestions.count { it.category == QuizCategory.LOGIKA }
        val umumCount = QuestionBank.allQuestions.count { it.category == QuizCategory.PENGETAHUAN_UMUM }
        val bonusCount = QuestionBank.allQuestions.count { it.category == QuizCategory.BONUS_CAMPURAN }

        assertEquals("Matematika harus tepat 600 soal", 600, mathCount)
        assertEquals("Bahasa Indonesia harus tepat 450 soal", 450, bahasaCount)
        assertEquals("Logika dan Pola harus tepat 450 soal", 450, logikaCount)
        assertEquals("Pengetahuan Umum harus tepat 450 soal", 450, umumCount)
        assertEquals("Bonus Campuran harus tepat 50 soal", 50, bonusCount)
    }

    @Test
    fun verifyBalancedAgeDistribution() {
        // Matematika: 200, 200, 200
        assertEquals(200, QuestionBank.allQuestions.count { it.category == QuizCategory.MATEMATIKA && it.ageBracket == AgeBracket.AGE_5_6 })
        assertEquals(200, QuestionBank.allQuestions.count { it.category == QuizCategory.MATEMATIKA && it.ageBracket == AgeBracket.AGE_7_8 })
        assertEquals(200, QuestionBank.allQuestions.count { it.category == QuizCategory.MATEMATIKA && it.ageBracket == AgeBracket.AGE_9_10 })

        // Bahasa Indonesia: 150, 150, 150
        assertEquals(150, QuestionBank.allQuestions.count { it.category == QuizCategory.BAHASA_INDONESIA && it.ageBracket == AgeBracket.AGE_5_6 })
        assertEquals(150, QuestionBank.allQuestions.count { it.category == QuizCategory.BAHASA_INDONESIA && it.ageBracket == AgeBracket.AGE_7_8 })
        assertEquals(150, QuestionBank.allQuestions.count { it.category == QuizCategory.BAHASA_INDONESIA && it.ageBracket == AgeBracket.AGE_9_10 })

        // Logika: 150, 150, 150
        assertEquals(150, QuestionBank.allQuestions.count { it.category == QuizCategory.LOGIKA && it.ageBracket == AgeBracket.AGE_5_6 })
        assertEquals(150, QuestionBank.allQuestions.count { it.category == QuizCategory.LOGIKA && it.ageBracket == AgeBracket.AGE_7_8 })
        assertEquals(150, QuestionBank.allQuestions.count { it.category == QuizCategory.LOGIKA && it.ageBracket == AgeBracket.AGE_9_10 })

        // Umum: 150, 150, 150
        assertEquals(150, QuestionBank.allQuestions.count { it.category == QuizCategory.PENGETAHUAN_UMUM && it.ageBracket == AgeBracket.AGE_5_6 })
        assertEquals(150, QuestionBank.allQuestions.count { it.category == QuizCategory.PENGETAHUAN_UMUM && it.ageBracket == AgeBracket.AGE_7_8 })
        assertEquals(150, QuestionBank.allQuestions.count { it.category == QuizCategory.PENGETAHUAN_UMUM && it.ageBracket == AgeBracket.AGE_9_10 })

        // Bonus: 17, 17, 16
        assertEquals(17, QuestionBank.allQuestions.count { it.category == QuizCategory.BONUS_CAMPURAN && it.ageBracket == AgeBracket.AGE_5_6 })
        assertEquals(17, QuestionBank.allQuestions.count { it.category == QuizCategory.BONUS_CAMPURAN && it.ageBracket == AgeBracket.AGE_7_8 })
        assertEquals(16, QuestionBank.allQuestions.count { it.category == QuizCategory.BONUS_CAMPURAN && it.ageBracket == AgeBracket.AGE_9_10 })
    }

    @Test
    fun verifyNoDuplicateQuestionIds() {
        val allIds = QuestionBank.allQuestions.map { it.id }
        val uniqueIds = allIds.toSet()
        assertEquals("Semua 2.000 ID soal harus unik dan tidak boleh ada duplikat", allIds.size, uniqueIds.size)
    }

    @Test
    fun verifyNoDuplicateQuestionTextsPerCategoryAndAge() {
        for (category in QuizCategory.entries) {
            for (age in AgeBracket.entries) {
                val questions = QuestionBank.allQuestions.filter { it.category == category && it.ageBracket == age }
                val texts = questions.map { it.questionText }
                val duplicates = texts.groupBy { it }.filter { it.value.size > 1 }
                if (duplicates.isNotEmpty()) {
                    println("DUPLICATES in ${category.title} ${age.label}: ${duplicates.keys.take(5)}")
                }
                assertEquals(
                    "Tidak boleh ada teks pertanyaan duplikat di kategori ${category.title} usia ${age.label}: ${duplicates.keys.take(3)}",
                    texts.size,
                    texts.toSet().size
                )
            }
        }
    }

    @Test
    fun verifyQuestionIntegrityAndOptions() {
        for (q in QuestionBank.allQuestions) {
            assertTrue("Teks pertanyaan tidak boleh kosong: ${q.id}", q.questionText.isNotBlank())
            assertTrue("Visual emoji tidak boleh kosong: ${q.id}", q.visualEmoji.isNotBlank())
            assertTrue("Pilihan jawaban minimal 3: ${q.id}", q.options.size >= 3)
            val dupOptions = q.options.groupBy { it }.filter { it.value.size > 1 }
            if (dupOptions.isNotEmpty()) {
                println("DUP OPTIONS in ${q.id}: ${q.options}")
            }
            assertEquals(
                "Semua pilihan opsi dalam satu soal harus berbeda: ${q.id} -> ${q.options}",
                q.options.size,
                q.options.toSet().size
            )
            assertTrue(
                "Indeks jawaban benar harus berada di rentang opsi: ${q.id}",
                q.correctIndex in q.options.indices
            )
            val correctAnswer = q.options[q.correctIndex]
            assertTrue("Jawaban benar tidak boleh kosong: ${q.id}", correctAnswer.isNotBlank())
            assertTrue("Penjelasan tidak boleh kosong: ${q.id}", q.explanation.isNotBlank())
            assertTrue("Petunjuk tidak boleh kosong: ${q.id}", q.hint.isNotBlank())
            assertTrue("Tingkat kesulitan tidak boleh kosong: ${q.id}", q.difficulty.isNotBlank())
        }
    }

    @Test
    fun verifyOptionShufflingPreservesCorrectAnswer() {
        val sample = QuestionBank.allQuestions.first()
        val originalCorrectText = sample.options[sample.correctIndex]
        val shuffled = sample.withShuffledOptions()

        assertEquals("Teks jawaban benar harus tetap sama setelah diacak", originalCorrectText, shuffled.options[shuffled.correctIndex])
        assertEquals("Jumlah opsi harus tetap sama", sample.options.size, shuffled.options.size)
    }

    @Test
    fun verifyQuizSessionAlwaysReturns10Questions() {
        for (category in QuizCategory.entries) {
            for (age in AgeBracket.entries) {
                val sessionQuestions = QuestionBank.getQuestionsForQuiz(category, age, limit = 10)
                assertEquals(
                    "Sesi kuis untuk ${category.title} usia ${age.label} harus berjumlah 10 soal",
                    10,
                    sessionQuestions.size
                )
            }
        }
    }

    @Test
    fun verifyNoArtificialKeywordsInQuestionTexts() {
        val forbiddenPattern = Regex("(?i)\\b(kartu|soal|nomor|keberapa)\\b")
        for (q in QuestionBank.allQuestions) {
            val match = forbiddenPattern.find(q.questionText)
            assertTrue(
                "Pertanyaan tidak boleh mengandung kata penunjuk soal/kartu '${match?.value}' pada [${q.id}]: '${q.questionText}'",
                match == null
            )
        }
    }
}

