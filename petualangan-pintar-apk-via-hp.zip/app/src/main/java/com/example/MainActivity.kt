package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.ParentGateDialog
import com.example.ui.components.TutorialDialog
import com.example.ui.screens.BadgeCollectionScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.ParentSettingsScreen
import com.example.ui.screens.QuizResultScreen
import com.example.ui.screens.QuizScreen
import com.example.ui.screens.ReviewAnswersScreen
import com.example.ui.theme.CreamBackground
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.GameScreen
import com.example.ui.viewmodel.GameViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = CreamBackground
                ) {
                    PetualanganPintarApp()
                }
            }
        }
    }
}

@Composable
fun PetualanganPintarApp(
    viewModel: GameViewModel = viewModel()
) {
    val currentScreen by viewModel.currentScreen.collectAsStateWithLifecycle()
    val userProfile by viewModel.userProfile.collectAsStateWithLifecycle()
    val categoryProgressList by viewModel.categoryProgressList.collectAsStateWithLifecycle()
    val badgesList by viewModel.badgesList.collectAsStateWithLifecycle()
    val quizState by viewModel.quizState.collectAsStateWithLifecycle()
    val latestResult by viewModel.latestResult.collectAsStateWithLifecycle()

    val showTutorial by viewModel.showTutorial.collectAsStateWithLifecycle()
    val showParentGate by viewModel.showParentGate.collectAsStateWithLifecycle()
    val showExitQuizDialog by viewModel.showExitQuizDialog.collectAsStateWithLifecycle()

    // Dialogs
    if (showTutorial) {
        TutorialDialog(
            onDismiss = { viewModel.closeTutorial() }
        )
    }

    if (showParentGate) {
        ParentGateDialog(
            onDismiss = { viewModel.closeParentGate() },
            onSuccess = { viewModel.onParentGateSuccess() }
        )
    }

    // Screen Routing with BackHandler on every secondary screen
    when (val screen = currentScreen) {
        is GameScreen.Home -> {
            HomeScreen(
                userProfile = userProfile,
                categoryProgressList = categoryProgressList,
                badges = badgesList,
                onSelectAgeBracket = { viewModel.setAgeBracket(it) },
                onStartCategory = { viewModel.startQuiz(it) },
                onOpenBadges = { viewModel.navigateTo(GameScreen.Badges) },
                onOpenTutorial = { viewModel.openTutorial() },
                onOpenParentGate = { viewModel.openParentGate() }
            )
        }

        is GameScreen.Quiz -> {
            BackHandler {
                viewModel.requestExitQuiz()
            }
            QuizScreen(
                state = quizState,
                onSelectOption = { viewModel.selectOption(it) },
                onToggleHint = { viewModel.toggleHint() },
                onNextQuestion = { viewModel.nextQuestion() },
                onRequestExit = { viewModel.requestExitQuiz() },
                onConfirmExit = { viewModel.confirmExitQuiz() },
                onDismissExit = { viewModel.dismissExitQuizDialog() },
                showExitDialog = showExitQuizDialog
            )
        }

        is GameScreen.Result -> {
            BackHandler {
                viewModel.navigateTo(GameScreen.Home)
            }
            latestResult?.let { result ->
                QuizResultScreen(
                    result = result,
                    onPlayAgain = { viewModel.startQuiz(result.category) },
                    onReviewAnswers = { viewModel.navigateTo(GameScreen.ReviewAnswers) },
                    onGoHome = { viewModel.navigateTo(GameScreen.Home) }
                )
            } ?: run {
                viewModel.navigateTo(GameScreen.Home)
            }
        }

        is GameScreen.ReviewAnswers -> {
            BackHandler {
                viewModel.navigateTo(GameScreen.Result)
            }
            ReviewAnswersScreen(
                records = quizState.records,
                onBack = { viewModel.navigateTo(GameScreen.Result) }
            )
        }

        is GameScreen.Badges -> {
            BackHandler {
                viewModel.navigateTo(GameScreen.Home)
            }
            BadgeCollectionScreen(
                badges = badgesList,
                onBack = { viewModel.navigateTo(GameScreen.Home) }
            )
        }

        is GameScreen.ParentSettings -> {
            BackHandler {
                viewModel.navigateTo(GameScreen.Home)
            }
            ParentSettingsScreen(
                userProfile = userProfile,
                onUpdateSettings = { sound, haptic, age ->
                    viewModel.updateSettings(sound, haptic, age)
                },
                onResetProgress = { viewModel.resetAllProgress() },
                onBack = { viewModel.navigateTo(GameScreen.Home) }
            )
        }
    }
}
