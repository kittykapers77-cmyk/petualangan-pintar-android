package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        UserProfileEntity::class,
        CategoryProgressEntity::class,
        BadgeEntity::class,
        QuizHistoryEntity::class
    ],
    version = 2,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun gameDao(): GameDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "petualangan_pintar.db"
                )
                    .fallbackToDestructiveMigration()
                    .addCallback(object : Callback() {
                        override fun onCreate(db: SupportSQLiteDatabase) {
                            super.onCreate(db)
                            CoroutineScope(Dispatchers.IO).launch {
                                INSTANCE?.let { database ->
                                    seedInitialData(database.gameDao())
                                }
                            }
                        }
                    }).build()
                INSTANCE = instance
                instance
            }
        }

        suspend fun seedInitialData(dao: GameDao) {
            dao.insertOrUpdateProfile(
                UserProfileEntity(
                    id = 1,
                    selectedAgeId = "5-6",
                    soundEnabled = true,
                    hapticEnabled = true,
                    totalStars = 0,
                    completedQuizzesCount = 0,
                    explorerRank = "Penjelajah Pemula"
                )
            )

            val categories = listOf("math", "bahasa", "logika", "umum", "bonus")
            dao.insertAllCategoryProgress(
                categories.map { id ->
                    CategoryProgressEntity(
                        categoryId = id,
                        starsEarned = 0,
                        highestScore = 0,
                        timesPlayed = 0,
                        currentLevel = 1
                    )
                }
            )

            val defaultBadges = listOf(
                BadgeEntity("badge_first_mission", "Langkah Pertama", "Menyelesaikan kuis petualangan pertama", "🎒"),
                BadgeEntity("badge_perfect_score", "Bintang Sempurna", "Meraih skor 10/10 tanpa salah!", "🌟"),
                BadgeEntity("badge_math_star", "Jago Hitung Cilik", "Menyelesaikan misi kuis Matematika", "🧮"),
                BadgeEntity("badge_bahasa_star", "Kutu Buku Cilik", "Menyelesaikan misi Bahasa Indonesia", "📖"),
                BadgeEntity("badge_logic_star", "Detektif Pola", "Menyelesaikan misi Logika & Pola", "🧩"),
                BadgeEntity("badge_nature_star", "Sahabat Dunia", "Menyelesaikan misi Pengetahuan Umum", "🌍"),
                BadgeEntity("badge_five_stars", "Kolektor Bintang", "Kumpulkan total 15 bintang emas", "⭐"),
                BadgeEntity("badge_explorer_master", "Kapten Petualang", "Mencapai Level 5 dalam petualangan", "🧭"),
                BadgeEntity("badge_no_hints", "Mandiri Hebat", "Menyelesaikan sesi tanpa membuka petunjuk", "💡")
            )
            dao.seedBadges(defaultBadges)
        }
    }
}
