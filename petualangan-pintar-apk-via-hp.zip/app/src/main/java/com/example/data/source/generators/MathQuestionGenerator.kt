package com.example.data.source.generators

import com.example.data.model.AgeBracket
import com.example.data.model.Question
import com.example.data.model.QuizCategory

object MathQuestionGenerator {

    fun generateQuestions(): List<Question> {
        val list = ArrayList<Question>(600)
        list.addAll(generateAge56())
        list.addAll(generateAge78())
        list.addAll(generateAge910())
        return list
    }

    private fun makeOptions(correct: String, vararg candidates: String, count: Int = 4): List<String> {
        val result = linkedSetOf(correct)
        for (c in candidates) {
            if (c != correct && c.isNotBlank()) {
                result.add(c)
                if (result.size == count) break
            }
        }
        val correctNum = correct.filter { it.isDigit() }.toIntOrNull()
        var offset = 1
        while (result.size < count) {
            val fallback = if (correctNum != null) {
                val candidate = (correctNum + offset).toString()
                offset++
                candidate
            } else {
                val candidate = "$correct ($offset)"
                offset++
                candidate
            }
            if (fallback != correct && !result.contains(fallback)) {
                result.add(fallback)
            }
        }
        return result.toList()
    }

    // =========================================================================
    // USIA 5-6 TAHUN (200 SOAL)
    // =========================================================================
    private fun generateAge56(): List<Question> {
        val questions = ArrayList<Question>(200)
        var qId = 1

        // 1. Counting visual objects (50 soal) - 10 items x 5 distinct natural phrasing templates
        val countItems = listOf(
            Pair("apel merah", "🍎"), Pair("bintang berkilau", "⭐"), Pair("mobil balap", "🚗"),
            Pair("ikan lumba-lumba", "🐬"), Pair("kucing lucu", "🐱"), Pair("kupu-kupu cantik", "🦋"),
            Pair("balon warna-warni", "🎈"), Pair("bebek kuning", "🦆"), Pair("permen manis", "🍬"),
            Pair("bunga mawar", "🌸")
        )
        val questionTemplates = listOf(
            "Berapa banyak buah {item} yang terlihat?",
            "Ada berapa jumlah {item} pada gambar?",
            "Hitunglah berapa banyak {item} ini!",
            "Berapa ekor atau buah {item} yang terkumpul?",
            "Coba hitung berapa seluruh {item} di sini!"
        )

        for (item in countItems) {
            for (count in 1..5) {
                val emojiString = List(count) { item.second }.joinToString(" ")
                val correctVal = count.toString()
                val options = makeOptions(correctVal, (count + 1).toString(), (if (count > 1) count - 1 else count + 2).toString(), count = 3)
                val template = questionTemplates[count - 1]
                val qText = template.replace("{item}", item.first)

                questions.add(
                    Question(
                        id = "math_56_$qId",
                        category = QuizCategory.MATEMATIKA,
                        ageBracket = AgeBracket.AGE_5_6,
                        questionText = qText,
                        visualEmoji = emojiString,
                        options = options,
                        correctIndex = 0,
                        explanation = "Ada tepat $count ${item.first}. Yuk hitung satu per satu!",
                        hint = "Tunjuk gambar dengan jari dan hitung perlahan.",
                        difficulty = "Mudah"
                    )
                )
                qId++
            }
        } // 50 questions done

        // 2. Simple Addition within 10 (50 soal) - 50 unique (a, b) pairs
        val additionPairs = mutableListOf<Pair<Int, Int>>()
        for (sum in 2..15) {
            for (a in 1 until sum) {
                val b = sum - a
                if (a <= 10 && b <= 10) {
                    additionPairs.add(Pair(a, b))
                    if (additionPairs.size == 50) break
                }
            }
            if (additionPairs.size == 50) break
        }
        val addEmojis = listOf("🍎", "⭐", "🎈", "🍭", "🍪")
        for (i in 0 until 50) {
            val (a, b) = additionPairs[i]
            val emoji = addEmojis[i % addEmojis.size]
            val sum = a + b
            val visual = List(a) { emoji }.joinToString("") + " + " + List(b) { emoji }.joinToString("")
            val correctVal = sum.toString()
            val options = makeOptions(correctVal, (sum + 1).toString(), (if (sum > 2) sum - 1 else sum + 2).toString(), count = 3)

            questions.add(
                Question(
                    id = "math_56_$qId",
                    category = QuizCategory.MATEMATIKA,
                    ageBracket = AgeBracket.AGE_5_6,
                    questionText = "Berapakah hasil dari $a ditambah $b?",
                    visualEmoji = visual,
                    options = options,
                    correctIndex = 0,
                    explanation = "$a ditambah $b sama dengan $sum $emoji.",
                    hint = "Gabungkan semua benda dan hitung jumlah totalnya.",
                    difficulty = "Mudah"
                )
            )
            qId++
        } // 100 questions done

        // 3. Simple Subtraction within 10 (40 soal) - 40 unique (total, minus) pairs
        val subPairs = mutableListOf<Pair<Int, Int>>()
        for (total in 2..10) {
            for (minus in 1 until total) {
                subPairs.add(Pair(total, minus))
                if (subPairs.size == 40) break
            }
            if (subPairs.size == 40) break
        }
        val fruitNames = listOf("jeruk", "pisang", "mangga", "stroberi", "kue")
        val fruitEmojis = listOf("🍊", "🍌", "🥭", "🍓", "🧁")
        for (i in 0 until 40) {
            val (total, minus) = subPairs[i]
            val sisa = total - minus
            val correctVal = sisa.toString()
            val options = makeOptions(correctVal, (sisa + 1).toString(), (if (sisa > 1) sisa - 1 else sisa + 2).toString(), count = 3)
            val fruit = fruitNames[i % fruitNames.size]
            val emoji = fruitEmojis[i % fruitEmojis.size]

            questions.add(
                Question(
                    id = "math_56_$qId",
                    category = QuizCategory.MATEMATIKA,
                    ageBracket = AgeBracket.AGE_5_6,
                    questionText = "Ada $total buah $fruit, lalu dimakan $minus buah. Berapakah sisanya?",
                    visualEmoji = emoji.repeat(total) + " - " + emoji.repeat(minus),
                    options = options,
                    correctIndex = 0,
                    explanation = "$total dikurangi $minus menyisakan $sisa buah $fruit segar.",
                    hint = "Hitung sisa buah yang belum dimakan.",
                    difficulty = "Sedang"
                )
            )
            qId++
        } // 140 questions done

        // 4. Shapes and Objects Recognition (30 soal) - 30 distinct real world objects
        val shapesData = listOf(
            Triple("roda sepeda", "Lingkaran", "🚲"),
            Triple("potongan pizza", "Segitiga", "🍕"),
            Triple("ubin lantai kamar", "Persegi", "🔲"),
            Triple("daun pintu lemari", "Persegi Panjang", "🚪"),
            Triple("bintang di langit malam", "Bintang", "⭐"),
            Triple("sebutir telur ayam", "Lonjong", "🥚"),
            Triple("donat cokelat bulat", "Lingkaran", "🍩"),
            Triple("atap tenda kemah", "Segitiga", "⛺"),
            Triple("sebuah dadu permainan", "Persegi", "🎲"),
            Triple("layar televisi ruang tamu", "Persegi Panjang", "📺"),
            Triple("keping uang logam", "Lingkaran", "🪙"),
            Triple("bendera segitiga pramuka", "Segitiga", "🚩"),
            Triple("kotak kado ulang tahun", "Persegi", "🎁"),
            Triple("papan tulis di sekolah", "Persegi Panjang", "📋"),
            Triple("piring makan siang", "Lingkaran", "🍽️"),
            Triple("gantungan baju kawat", "Segitiga", "🪝"),
            Triple("bingkai foto keluarga", "Persegi", "🖼️"),
            Triple("buku tulis anak", "Persegi Panjang", "📖"),
            Triple("jam dinding bundar", "Lingkaran", "⏰"),
            Triple("atap rumah pondok", "Segitiga", "🏠"),
            Triple("kue biskuit kubus", "Persegi", "🧇"),
            Triple("penggaris kayu lurus", "Persegi Panjang", "📏"),
            Triple("ban mobil mini", "Lingkaran", "🛞"),
            Triple("rambu lalu lintas peringatan", "Segitiga", "⚠️"),
            Triple("saputangan kain lipat", "Persegi", "🧣"),
            Triple("kasur tempat tidur empuk", "Persegi Panjang", "🛏️"),
            Triple("cincin emas melingkar", "Lingkaran", "💍"),
            Triple("piramida di padang pasir", "Segitiga", "🔺"),
            Triple("papan permainan catur", "Persegi", "♟️"),
            Triple("handphone layar sentuh", "Persegi Panjang", "📱")
        )
        for (item in shapesData) {
            val correctShape = item.second
            val allShapes = listOf("Lingkaran", "Segitiga", "Persegi", "Persegi Panjang", "Bintang", "Lonjong")
            val wrongShapes = allShapes.filter { it != correctShape }.take(2)
            val options = makeOptions(correctShape, wrongShapes[0], wrongShapes[1], count = 3)

            questions.add(
                Question(
                    id = "math_56_$qId",
                    category = QuizCategory.MATEMATIKA,
                    ageBracket = AgeBracket.AGE_5_6,
                    questionText = "Benda ${item.first} memiliki bentuk bangun datar apa?",
                    visualEmoji = item.third,
                    options = options,
                    correctIndex = 0,
                    explanation = "${item.first} menyerupai bentuk bangun datar $correctShape.",
                    hint = "Perhatikan garis tepi dan sudut-sudutnya.",
                    difficulty = "Mudah"
                )
            )
            qId++
        } // 170 questions done

        // 5. Number Sequences & Comparisons (30 soal) - 15 unique next numbers + 15 unique pairs
        for (num in 1..15) {
            val nextNum = num + 1
            val correctVal = nextNum.toString()
            val options = makeOptions(correctVal, (nextNum + 1).toString(), (if (nextNum > 2) nextNum - 2 else nextNum + 3).toString(), count = 3)
            questions.add(
                Question(
                    id = "math_56_$qId",
                    category = QuizCategory.MATEMATIKA,
                    ageBracket = AgeBracket.AGE_5_6,
                    questionText = "Berapakah angka setelah angka $num?",
                    visualEmoji = "$num ➔ ?",
                    options = options,
                    correctIndex = 0,
                    explanation = "Setelah angka $num pada hitungan maju adalah angka $nextNum.",
                    hint = "Lanjutkan urutan berhitung satu angka ke depan.",
                    difficulty = "Mudah"
                )
            )
            qId++
        }
        val comparePairs = listOf(
            Pair(1, 4), Pair(2, 5), Pair(3, 7), Pair(4, 8), Pair(5, 9),
            Pair(6, 10), Pair(2, 8), Pair(3, 9), Pair(1, 6), Pair(4, 9),
            Pair(2, 7), Pair(5, 10), Pair(3, 8), Pair(1, 5), Pair(4, 10)
        )
        for ((a, b) in comparePairs) {
            val options = listOf("$b", "$a", "Sama besar")
            questions.add(
                Question(
                    id = "math_56_$qId",
                    category = QuizCategory.MATEMATIKA,
                    ageBracket = AgeBracket.AGE_5_6,
                    questionText = "Manakah angka yang nilainya lebih besar antara $a dan $b?",
                    visualEmoji = "$a 🆚 $b",
                    options = options,
                    correctIndex = 0,
                    explanation = "Angka $b bernilai lebih banyak daripada $a.",
                    hint = "Pilih angka yang letaknya paling akhir saat berhitung.",
                    difficulty = "Mudah"
                )
            )
            qId++
        } // Exactly 200 questions for Age 5-6!

        return questions
    }

    // =========================================================================
    // USIA 7-8 TAHUN (200 SOAL)
    // =========================================================================
    private fun generateAge78(): List<Question> {
        val questions = ArrayList<Question>(200)
        var qId = 1

        // 1. Two-digit Addition within 100 (50 soal) - 50 unique (a, b) pairs
        val add78Pairs = mutableListOf<Pair<Int, Int>>()
        for (i in 1..50) {
            val a = 11 + i
            val b = 15 + (i * 3) % 35
            add78Pairs.add(Pair(a, b))
        }
        for ((a, b) in add78Pairs) {
            val sum = a + b
            val correctVal = sum.toString()
            val options = makeOptions(correctVal, (sum + 2).toString(), (sum - 2).toString(), (sum + 10).toString(), count = 4)

            questions.add(
                Question(
                    id = "math_78_$qId",
                    category = QuizCategory.MATEMATIKA,
                    ageBracket = AgeBracket.AGE_7_8,
                    questionText = "Berapakah hasil dari $a + $b?",
                    visualEmoji = "🔢 $a + $b = ?",
                    options = options,
                    correctIndex = 0,
                    explanation = "Penjumlahan $a + $b = $sum.",
                    hint = "Jumlahkan angka satuan terlebih dahulu, lalu puluhannya.",
                    difficulty = "Mudah"
                )
            )
            qId++
        } // 50 questions done

        // 2. Subtraction within 100 (50 soal) - 50 unique (a, b) pairs
        val sub78Pairs = mutableListOf<Pair<Int, Int>>()
        for (i in 1..50) {
            val a = 50 + i
            val b = 12 + (i * 2) % 35
            sub78Pairs.add(Pair(a, b))
        }
        for ((a, b) in sub78Pairs) {
            val diff = a - b
            val correctVal = diff.toString()
            val options = makeOptions(correctVal, (diff + 3).toString(), (diff - 2).toString(), (diff + 10).toString(), count = 4)

            questions.add(
                Question(
                    id = "math_78_$qId",
                    category = QuizCategory.MATEMATIKA,
                    ageBracket = AgeBracket.AGE_7_8,
                    questionText = "Berapakah hasil dari $a - $b?",
                    visualEmoji = "➖ $a - $b = ?",
                    options = options,
                    correctIndex = 0,
                    explanation = "Pengurangan $a - $b = $diff.",
                    hint = "Kurangkan nilai satuan, lalu kurangkan puluhannya.",
                    difficulty = "Sedang"
                )
            )
            qId++
        } // 100 questions done

        // 3. Multiplication times tables 2, 3, 4, 5, 10 (40 soal) - 40 unique (a, b) pairs
        val multPairs = mutableListOf<Pair<Int, Int>>()
        for (a in listOf(2, 3, 4, 5, 10)) {
            for (b in 2..9) {
                multPairs.add(Pair(a, b))
            }
        }
        for (i in 0 until 40) {
            val (a, b) = multPairs[i]
            val product = a * b
            val correctVal = product.toString()
            val options = makeOptions(correctVal, (product + a).toString(), (product - a).toString(), (product + 10).toString(), (product - 2).toString(), count = 4)

            questions.add(
                Question(
                    id = "math_78_$qId",
                    category = QuizCategory.MATEMATIKA,
                    ageBracket = AgeBracket.AGE_7_8,
                    questionText = "Berapakah hasil perkalian $a × $b?",
                    visualEmoji = "✖️ $a × $b = ?",
                    options = options,
                    correctIndex = 0,
                    explanation = "$a dikali $b sama dengan $product.",
                    hint = "Hitung penjumlahan berulang $b sebanyak $a kali.",
                    difficulty = "Sedang"
                )
            )
            qId++
        } // 140 questions done

        // 4. Money & Practical Word Problems (30 soal) - 30 distinct scenarios
        val wordScenarios = listOf(
            "Budi membeli 2 buah buku gambar seharga Rp 2.000 per buah",
            "Siti membeli 3 batang pensil tulis seharga Rp 1.500 per batang",
            "Doni membeli 4 bungkus biskuit cokelat seharga Rp 1.000 per bungkus",
            "Ani membeli 2 kotak susu segar seharga Rp 3.000 per kotak",
            "Rian membeli 5 butir kelereng kaca seharga Rp 500 per butir",
            "Eka membeli 3 buah roti manis seharga Rp 2.500 per buah",
            "Toni membeli 2 buah penghapus karet seharga Rp 1.000 per buah",
            "Rina membeli 4 ikat bayam segar seharga Rp 2.000 per ikat",
            "Dimas membeli 3 buah apel merah seharga Rp 3.000 per buah",
            "Lani membeli 2 buah penggaris plastik seharga Rp 1.500 per buah",
            "Bayu membeli 5 buah permen lolipop seharga Rp 1.000 per buah",
            "Nia membeli 3 bungkus wafer keju seharga Rp 2.000 per bungkus",
            "Fajar membeli 2 mangkok bakso kuah seharga Rp 5.000 per mangkok",
            "Dewi membeli 4 buah jeruk manis seharga Rp 2.500 per buah",
            "Agus membeli 3 buah buku tulis halus seharga Rp 3.500 per buah",
            "Maya membeli 2 ikat kangkung segar seharga Rp 1.500 per ikat",
            "Hendra membeli 5 buah gantungan kunci seharga Rp 2.000 per buah",
            "Putri membeli 3 porsi es krim cangkir seharga Rp 4.000 per porsi",
            "Rizky membeli 2 buah pulpen biru seharga Rp 2.500 per buah",
            "Sari membeli 4 kantong keripik pisang seharga Rp 3.000 per kantong",
            "Bambang membeli 3 buah donat gula seharga Rp 2.000 per buah",
            "Indah membeli 2 potong kue lapis seharga Rp 1.500 per potong",
            "Surya membeli 4 lembar kertas karton seharga Rp 1.000 per lembar",
            "Ratna membeli 3 botol jus jambu seharga Rp 4.500 per botol",
            "Galang membeli 2 buah rautan pensil seharga Rp 2.000 per buah",
            "Mega membeli 5 lembar stiker lucu seharga Rp 500 per lembar",
            "Wahyu membeli 3 cangkir teh manis seharga Rp 3.000 per cangkir",
            "Dita membeli 2 piring siomay kukus seharga Rp 4.000 per piring",
            "Ilham membeli 4 buah pastel isi wortel seharga Rp 1.500 per buah",
            "Ayu membeli 3 bungkus kacang goreng seharga Rp 2.500 per bungkus"
        )
        val scenarioPrices = listOf(
            4000, 4500, 4000, 6000, 2500, 7500, 2000, 8000, 9000, 3000,
            5000, 6000, 10000, 10000, 10500, 3000, 10000, 12000, 5000, 12000,
            6000, 3000, 4000, 13500, 4000, 2500, 9000, 8000, 6000, 7500
        )
        for (i in 0 until 30) {
            val scenario = wordScenarios[i]
            val totalHarga = scenarioPrices[i]
            val correctVal = "Rp $totalHarga"
            val options = makeOptions(correctVal, "Rp ${totalHarga + 1000}", "Rp ${totalHarga - 1000}", "Rp ${totalHarga + 2000}", count = 4)

            questions.add(
                Question(
                    id = "math_78_$qId",
                    category = QuizCategory.MATEMATIKA,
                    ageBracket = AgeBracket.AGE_7_8,
                    questionText = "$scenario. Berapa total harga yang harus dibayar?",
                    visualEmoji = "🧁 💰",
                    options = options,
                    correctIndex = 0,
                    explanation = "Total belanjaan yang harus dibayar adalah Rp $totalHarga.",
                    hint = "Kalikan jumlah barang dengan harga satuannya.",
                    difficulty = "Sedang"
                )
            )
            qId++
        } // 170 questions done

        // 5. Geometry, Units, and Time (30 soal) - 30 distinct questions
        val facts = listOf(
            Triple("Berapa jumlah sisi pada sebuah bangun persegi?", "4 sisi", listOf("3 sisi", "5 sisi", "6 sisi")),
            Triple("Berapa jumlah sudut lancip pada bangun segitiga?", "3 sudut", listOf("4 sudut", "2 sudut", "5 sudut")),
            Triple("1 meter sama dengan berapa sentimeter (cm)?", "100 cm", listOf("10 cm", "50 cm", "1000 cm")),
            Triple("1 menit terdiri dari berapa detik?", "60 detik", listOf("30 detik", "100 detik", "120 detik")),
            Triple("1 jam terdiri dari berapa menit?", "60 menit", listOf("30 menit", "50 menit", "100 menit")),
            Triple("Bangun datar yang tidak memiliki sudut sama sekali adalah?", "Lingkaran", listOf("Persegi", "Segitiga", "Belah Ketupat")),
            Triple("Berapa jumlah sisi pada bangun persegi panjang?", "4 sisi", listOf("2 sisi", "6 sisi", "3 sisi")),
            Triple("1 kilogram sama dengan berapa gram?", "1.000 gram", listOf("100 gram", "500 gram", "10 gram")),
            Triple("Jarum panjang di angka 12, jarum pendek di angka 6 menunjukkan waktu?", "Pukul 06.00", listOf("Pukul 12.06", "Pukul 12.00", "Pukul 06.12")),
            Triple("Jarum panjang di angka 6, jarum pendek di antara 2 dan 3 menunjukkan waktu?", "Pukul 02.30", listOf("Pukul 03.30", "Pukul 06.02", "Pukul 02.06")),
            Triple("Berapa banyak titik sudut pada bangun persegi?", "4 titik sudut", listOf("3 titik sudut", "5 titik sudut", "6 titik sudut")),
            Triple("Berapa banyak titik sudut pada bangun segitiga?", "3 titik sudut", listOf("4 titik sudut", "2 titik sudut", "6 titik sudut")),
            Triple("Setengah jam sama dengan berapa menit?", "30 menit", listOf("15 menit", "45 menit", "60 menit")),
            Triple("Seperempat jam sama dengan berapa menit?", "15 menit", listOf("20 menit", "30 menit", "10 menit")),
            Triple("1 hari 1 malam terdiri dari berapa jam?", "24 jam", listOf("12 jam", "20 jam", "48 jam")),
            Triple("1 minggu terdiri dari berapa hari?", "7 hari", listOf("5 hari", "6 hari", "10 hari")),
            Triple("Panjang 2 meter sama nilainya dengan berapa sentimeter?", "200 cm", listOf("20 cm", "120 cm", "2000 cm")),
            Triple("Berat 2 kilogram sama nilainya dengan berapa gram?", "2.000 gram", listOf("200 gram", "500 gram", "20 gram")),
            Triple("Bangun datar layang-layang memiliki berapa pasang sisi sama panjang?", "2 pasang", listOf("1 pasang", "3 pasang", "4 pasang")),
            Triple("Berapa jumlah sudut siku-siku pada bangun persegi?", "4 sudut siku-siku", listOf("2 sudut siku-siku", "3 sudut siku-siku", "5 sudut siku-siku")),
            Triple("Jarum panjang di angka 12, jarum pendek di angka 9 menunjukkan waktu?", "Pukul 09.00", listOf("Pukul 12.09", "Pukul 09.12", "Pukul 06.00")),
            Triple("Jarum panjang di angka 12, jarum pendek di angka 3 menunjukkan waktu?", "Pukul 03.00", listOf("Pukul 12.03", "Pukul 03.12", "Pukul 06.00")),
            Triple("Jarum panjang di angka 6, jarum pendek di antara 8 dan 9 menunjukkan waktu?", "Pukul 08.30", listOf("Pukul 09.30", "Pukul 08.06", "Pukul 06.08")),
            Triple("Alat ukur yang paling cocok untuk mengukur panjang buku tulis adalah?", "Penggaris", listOf("Timbangan", "Termometer", "Stopwatch")),
            Triple("Alat ukur yang digunakan untuk menimbang berat buah apel di pasar adalah?", "Timbangan", listOf("Penggaris", "Meteran pita", "Jam")),
            Triple("Berapa jumlah rusuk pada bangun kubus sederhana?", "12 rusuk", listOf("6 rusuk", "8 rusuk", "10 rusuk")),
            Triple("Berapa jumlah sisi permukaan pada bangun kubus?", "6 sisi", listOf("4 sisi", "8 sisi", "12 sisi")),
            Triple("Berapa jumlah titik sudut pada bangun balok?", "8 titik sudut", listOf("6 titik sudut", "12 titik sudut", "4 titik sudut")),
            Triple("Garis yang menghubungkan dua sudut berhadapan pada persegi disebut?", "Diagonal", listOf("Sisi", "Rusuk", "Jari-jari")),
            Triple("Lingkaran memiliki jari-jari 5 cm, maka panjang diameternya adalah?", "10 cm", listOf("7 cm", "15 cm", "25 cm"))
        )
        for (fact in facts) {
            val options = makeOptions(fact.second, fact.third[0], fact.third[1], fact.third[2], count = 4)

            questions.add(
                Question(
                    id = "math_78_$qId",
                    category = QuizCategory.MATEMATIKA,
                    ageBracket = AgeBracket.AGE_7_8,
                    questionText = fact.first,
                    visualEmoji = "📐 ⏰",
                    options = options,
                    correctIndex = 0,
                    explanation = "Jawaban yang tepat adalah ${fact.second}.",
                    hint = "Ingat materi dasar geometri dan satuan waktu.",
                    difficulty = "Sedang"
                )
            )
            qId++
        } // Exactly 200 questions for Age 7-8!

        return questions
    }

    // =========================================================================
    // USIA 9-10 TAHUN (200 SOAL)
    // =========================================================================
    private fun generateAge910(): List<Question> {
        val questions = ArrayList<Question>(200)
        var qId = 1

        // 1. Multi-digit Multiplication (45 soal) - 45 unique (a, b) pairs
        val mult910Pairs = mutableListOf<Pair<Int, Int>>()
        for (i in 1..45) {
            val a = 12 + i
            val b = 4 + (i % 8)
            mult910Pairs.add(Pair(a, b))
        }
        for ((a, b) in mult910Pairs) {
            val product = a * b
            val correctVal = product.toString()
            val options = makeOptions(correctVal, (product + b).toString(), (product - a).toString(), (product + 10).toString(), count = 4)

            questions.add(
                Question(
                    id = "math_910_$qId",
                    category = QuizCategory.MATEMATIKA,
                    ageBracket = AgeBracket.AGE_9_10,
                    questionText = "Berapakah hasil perkalian $a × $b?",
                    visualEmoji = "✖️ $a × $b",
                    options = options,
                    correctIndex = 0,
                    explanation = "Perkalian bersusun $a × $b = $product.",
                    hint = "Kalikan puluhan dan satuannya secara terpisah lalu jumlahkan.",
                    difficulty = "Sedang"
                )
            )
            qId++
        } // 45 questions done

        // 2. Division (45 soal) - 45 unique (dividend, divisor) pairs
        val div910Pairs = mutableListOf<Pair<Int, Int>>()
        for (i in 1..45) {
            val divisor = 4 + (i % 7)
            val quotient = 10 + i
            val dividend = divisor * quotient
            div910Pairs.add(Pair(dividend, divisor))
        }
        for ((dividend, divisor) in div910Pairs) {
            val quotient = dividend / divisor
            val correctVal = quotient.toString()
            val options = makeOptions(correctVal, (quotient + 2).toString(), (quotient - 1).toString(), (quotient + 5).toString(), count = 4)

            questions.add(
                Question(
                    id = "math_910_$qId",
                    category = QuizCategory.MATEMATIKA,
                    ageBracket = AgeBracket.AGE_9_10,
                    questionText = "Berapakah hasil pembagian $dividend : $divisor?",
                    visualEmoji = "➗ $dividend : $divisor",
                    options = options,
                    correctIndex = 0,
                    explanation = "$dividend dibagi $divisor adalah $quotient, karena $divisor × $quotient = $dividend.",
                    hint = "Gunakan perkalian kebalikan dari pembagian.",
                    difficulty = "Sedang"
                )
            )
            qId++
        } // 90 questions done

        // 3. Area and Perimeter (35 soal) - 35 distinct shape scenarios
        for (i in 1..35) {
            val sisi = 5 + i
            val isSquare = i <= 20
            val isArea = (i % 2 == 1)
            val p = 6 + i
            val l = 4 + (i % 5)

            val qText = when {
                isSquare && isArea -> "Sebuah persegi memiliki panjang sisi $sisi cm. Berapakah luasnya?"
                isSquare && !isArea -> "Sebuah persegi memiliki panjang sisi $sisi cm. Berapakah kelilingnya?"
                !isSquare && isArea -> "Persegi panjang memiliki panjang $p cm dan lebar $l cm. Berapakah luasnya?"
                else -> "Persegi panjang memiliki panjang $p cm dan lebar $l cm. Berapakah kelilingnya?"
            }

            val correctVal = when {
                isSquare && isArea -> "${sisi * sisi} cm²"
                isSquare && !isArea -> "${4 * sisi} cm"
                !isSquare && isArea -> "${p * l} cm²"
                else -> "${2 * (p + l)} cm"
            }

            val numVal = correctVal.filter { it.isDigit() }.toInt()
            val options = makeOptions(
                correctVal,
                if (correctVal.endsWith("cm²")) "${numVal + 10} cm²" else "${numVal + 4} cm",
                if (correctVal.endsWith("cm²")) "${numVal + 25} cm²" else "${numVal + 8} cm",
                if (correctVal.endsWith("cm²")) "${numVal - 5} cm²" else "${numVal - 4} cm",
                count = 4
            )

            questions.add(
                Question(
                    id = "math_910_$qId",
                    category = QuizCategory.MATEMATIKA,
                    ageBracket = AgeBracket.AGE_9_10,
                    questionText = qText,
                    visualEmoji = "📐 Geometri",
                    options = options,
                    correctIndex = 0,
                    explanation = "Jawaban yang benar adalah $correctVal.",
                    hint = "Gunakan rumus luas atau keliling bangun datar terkait.",
                    difficulty = "Tantangan"
                )
            )
            qId++
        } // 125 questions done

        // 4. Fractions & Operations (35 soal) - 35 distinct fraction questions
        val fractionsList = listOf(
            Triple("Berapa bentuk paling sederhana dari pecahan 2/4?", "1/2", listOf("1/4", "2/2", "3/4")),
            Triple("Berapa bentuk paling sederhana dari pecahan 3/6?", "1/2", listOf("1/3", "2/3", "3/3")),
            Triple("Berapa bentuk paling sederhana dari pecahan 4/8?", "1/2", listOf("1/4", "2/4", "3/8")),
            Triple("Berapa bentuk paling sederhana dari pecahan 5/10?", "1/2", listOf("1/5", "2/5", "3/10")),
            Triple("Berapa bentuk paling sederhana dari pecahan 6/12?", "1/2", listOf("1/3", "2/4", "3/6")),
            Triple("Berapa bentuk paling sederhana dari pecahan 4/16?", "1/4", listOf("1/2", "2/8", "1/8")),
            Triple("Berapa bentuk paling sederhana dari pecahan 3/12?", "1/4", listOf("1/3", "1/6", "2/6")),
            Triple("Berapa bentuk paling sederhana dari pecahan 5/20?", "1/4", listOf("1/5", "2/10", "1/2")),
            Triple("Berapa bentuk paling sederhana dari pecahan 9/27?", "1/3", listOf("1/9", "3/9", "2/3")),
            Triple("Berapa bentuk paling sederhana dari pecahan 6/18?", "1/3", listOf("1/6", "2/6", "3/6")),
            Triple("Berapakah hasil penjumlahan dari 1/5 + 2/5?", "3/5", listOf("3/10", "2/10", "4/5")),
            Triple("Berapakah hasil penjumlahan dari 2/7 + 3/7?", "5/7", listOf("5/14", "4/7", "6/7")),
            Triple("Berapakah hasil penjumlahan dari 1/8 + 3/8?", "4/8 (1/2)", listOf("4/16", "3/8", "5/8")),
            Triple("Berapakah hasil penjumlahan dari 2/9 + 4/9?", "6/9 (2/3)", listOf("6/18", "5/9", "7/9")),
            Triple("Berapakah hasil penjumlahan dari 3/10 + 4/10?", "7/10", listOf("7/20", "6/10", "8/10")),
            Triple("Berapakah hasil pengurangan dari 5/8 - 2/8?", "3/8", listOf("3/16", "2/8", "7/8")),
            Triple("Berapakah hasil pengurangan dari 7/9 - 4/9?", "3/9 (1/3)", listOf("3/18", "2/9", "5/9")),
            Triple("Berapakah hasil pengurangan dari 4/5 - 1/5?", "3/5", listOf("3/10", "2/5", "4/10")),
            Triple("Berapakah hasil pengurangan dari 8/11 - 3/11?", "5/11", listOf("5/22", "4/11", "6/11")),
            Triple("Berapakah hasil pengurangan dari 9/12 - 5/12?", "4/12 (1/3)", listOf("4/24", "3/12", "5/12")),
            Triple("Manakah pecahan berikut yang nilainya senilai dengan 1/2?", "4/8", listOf("2/5", "3/8", "4/10")),
            Triple("Manakah pecahan berikut yang nilainya senilai dengan 1/3?", "3/9", listOf("2/9", "4/9", "1/6")),
            Triple("Manakah pecahan berikut yang nilainya senilai dengan 1/4?", "2/8", listOf("3/8", "2/6", "4/10")),
            Triple("Manakah pecahan berikut yang nilainya senilai dengan 2/3?", "4/6", listOf("3/6", "5/6", "2/6")),
            Triple("Manakah pecahan berikut yang nilainya senilai dengan 3/4?", "6/8", listOf("5/8", "4/6", "3/8")),
            Triple("Pecahan desimal dari 1/2 adalah?", "0,5", listOf("0,2", "0,25", "0,75")),
            Triple("Pecahan desimal dari 1/4 adalah?", "0,25", listOf("0,2", "0,5", "0,75")),
            Triple("Pecahan desimal dari 3/4 adalah?", "0,75", listOf("0,34", "0,5", "0,25")),
            Triple("Pecahan desimal dari 1/5 adalah?", "0,2", listOf("0,5", "0,15", "0,25")),
            Triple("Pecahan desimal dari 2/5 adalah?", "0,4", listOf("0,25", "0,5", "0,45")),
            Triple("Bentuk persen (%) dari pecahan 1/2 adalah?", "50%", listOf("20%", "25%", "75%")),
            Triple("Bentuk persen (%) dari pecahan 1/4 adalah?", "25%", listOf("14%", "20%", "50%")),
            Triple("Bentuk persen (%) dari pecahan 3/4 adalah?", "75%", listOf("34%", "50%", "80%")),
            Triple("Bentuk persen (%) dari pecahan 1/5 adalah?", "20%", listOf("15%", "25%", "50%")),
            Triple("Bentuk persen (%) dari pecahan 4/5 adalah?", "80%", listOf("45%", "70%", "90%"))
        )
        for (frac in fractionsList) {
            val options = makeOptions(frac.second, frac.third[0], frac.third[1], frac.third[2], count = 4)

            questions.add(
                Question(
                    id = "math_910_$qId",
                    category = QuizCategory.MATEMATIKA,
                    ageBracket = AgeBracket.AGE_9_10,
                    questionText = frac.first,
                    visualEmoji = "🥧 Pecahan",
                    options = options,
                    correctIndex = 0,
                    explanation = "Jawaban yang benar adalah ${frac.second}.",
                    hint = "Sederhanakan pembilang dan penyebut dengan faktor yang sama.",
                    difficulty = "Tantangan"
                )
            )
            qId++
        } // 160 questions done

        // 5. Mixed Operations, Primes & Word Problems (40 soal) - 40 unique arithmetic triples
        for (i in 1..40) {
            val a = 10 + i
            val b = 5 + (i * 2) % 15
            val c = 2 + (i % 5)
            val result = (a + b) * c
            val correctVal = result.toString()
            val options = makeOptions(correctVal, (result + 5).toString(), (result - 10).toString(), (a + b * c).toString(), count = 4)

            questions.add(
                Question(
                    id = "math_910_$qId",
                    category = QuizCategory.MATEMATIKA,
                    ageBracket = AgeBracket.AGE_9_10,
                    questionText = "Berapakah nilai dari ($a + $b) × $c?",
                    visualEmoji = "🧮 ($a + $b) × $c",
                    options = options,
                    correctIndex = 0,
                    explanation = "Hitung operasi di dalam kurung terlebih dahulu: $a + $b = ${a + b}. Lalu ${a + b} × $c = $result.",
                    hint = "Operasi di dalam tanda kurung wajib dihitung pertama kali.",
                    difficulty = "Tantangan"
                )
            )
            qId++
        } // Exactly 200 questions for Age 9-10!

        return questions
    }
}
