package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import kotlinx.coroutines.flow.Flow

@Dao
interface GameDao {

    @Query("SELECT * FROM user_profile WHERE id = 1 LIMIT 1")
    fun getUserProfile(): Flow<UserProfileEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateProfile(profile: UserProfileEntity)

    @Query("SELECT * FROM category_progress")
    fun getAllCategoryProgress(): Flow<List<CategoryProgressEntity>>

    @Query("SELECT * FROM category_progress WHERE categoryId = :categoryId LIMIT 1")
    suspend fun getCategoryProgress(categoryId: String): CategoryProgressEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCategoryProgress(progress: CategoryProgressEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllCategoryProgress(list: List<CategoryProgressEntity>)

    @Query("SELECT * FROM badges ORDER BY isUnlocked DESC, id ASC")
    fun getAllBadges(): Flow<List<BadgeEntity>>

    @Query("SELECT * FROM badges WHERE isUnlocked = 1")
    suspend fun getUnlockedBadges(): List<BadgeEntity>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun seedBadges(badges: List<BadgeEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun updateBadge(badge: BadgeEntity)

    @Query("UPDATE badges SET isUnlocked = 1, unlockedAt = :timestamp WHERE id = :badgeId AND isUnlocked = 0")
    suspend fun unlockBadge(badgeId: String, timestamp: Long): Int

    @Insert
    suspend fun insertQuizHistory(history: QuizHistoryEntity)

    @Query("SELECT * FROM quiz_history ORDER BY timestamp DESC LIMIT 30")
    fun getRecentHistory(): Flow<List<QuizHistoryEntity>>

    @Transaction
    @Query("DELETE FROM user_profile")
    suspend fun clearProfile()

    @Transaction
    @Query("DELETE FROM category_progress")
    suspend fun clearCategoryProgress()

    @Transaction
    @Query("UPDATE badges SET isUnlocked = 0, unlockedAt = 0")
    suspend fun resetBadges()

    @Query("DELETE FROM quiz_history")
    suspend fun clearHistory()
}
