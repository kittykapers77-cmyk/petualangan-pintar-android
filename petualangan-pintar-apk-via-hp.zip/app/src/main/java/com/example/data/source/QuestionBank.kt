package com.example.data.source

import com.example.data.model.AgeBracket
import com.example.data.model.Question
import com.example.data.model.QuizCategory
import com.example.data.source.generators.BahasaQuestionGenerator
import com.example.data.source.generators.BonusQuestionGenerator
import com.example.data.source.generators.LogikaQuestionGenerator
import com.example.data.source.generators.MathQuestionGenerator
import com.example.data.source.generators.UmumQuestionGenerator

object QuestionBank {

    val allQuestions: List<Question> by lazy {
        val list = ArrayList<Question>(2000)
        list.addAll(MathQuestionGenerator.generateQuestions())
        list.addAll(BahasaQuestionGenerator.generateQuestions())
        list.addAll(LogikaQuestionGenerator.generateQuestions())
        list.addAll(UmumQuestionGenerator.generateQuestions())
        list.addAll(BonusQuestionGenerator.generateQuestions())
        list
    }

    // Keep track of recently used question IDs in memory to avoid repetitive questions across sessions
    private val recentlyUsedQuestionIds = mutableSetOf<String>()

    fun getQuestionsForQuiz(
        category: QuizCategory,
        ageBracket: AgeBracket,
        currentLevel: Int = 1,
        limit: Int = 10
    ): List<Question> {
        val pool = allQuestions.filter { it.category == category && it.ageBracket == ageBracket }
        if (pool.isEmpty()) {
            return emptyList()
        }

        // Adjust difficulty based on player's current level in that category
        val preferredPool = when {
            currentLevel >= 4 -> {
                // Advanced level: prioritize Tantangan & Sedang
                val hard = pool.filter { it.difficulty == "Tantangan" || it.difficulty == "Sedang" }
                if (hard.size >= limit) hard else pool
            }
            currentLevel in 2..3 -> {
                // Intermediate level: mix Mudah and Sedang
                val mid = pool.filter { it.difficulty == "Sedang" || it.difficulty == "Mudah" }
                if (mid.size >= limit) mid else pool
            }
            else -> {
                // Beginner level: start with Mudah
                val easy = pool.filter { it.difficulty == "Mudah" }
                if (easy.size >= limit) easy else pool
            }
        }

        // Filter out recently used questions to avoid immediate repetition
        val freshQuestions = preferredPool.filter { it.id !in recentlyUsedQuestionIds }
        val candidateQuestions = if (freshQuestions.size >= limit) {
            freshQuestions
        } else {
            // If we ran out of fresh questions in this slice, reset recent history for this pool
            val poolIds = pool.map { it.id }.toSet()
            recentlyUsedQuestionIds.removeAll(poolIds)
            pool
        }

        val selected = candidateQuestions.shuffled().take(limit)

        // Record used questions
        recentlyUsedQuestionIds.addAll(selected.map { it.id })
        // Cap recently used cache size
        if (recentlyUsedQuestionIds.size > 500) {
            val toRemove = recentlyUsedQuestionIds.take(150).toSet()
            recentlyUsedQuestionIds.removeAll(toRemove)
        }

        // Return questions with shuffled options so correct answer position is varied!
        return selected.map { it.withShuffledOptions() }
    }

    fun clearRecentHistory() {
        recentlyUsedQuestionIds.clear()
    }
}
