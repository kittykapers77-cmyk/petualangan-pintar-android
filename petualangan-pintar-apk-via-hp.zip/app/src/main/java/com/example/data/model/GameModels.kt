package com.example.data.model

enum class AgeBracket(
    val id: String,
    val label: String,
    val subtitle: String,
    val iconEmoji: String
) {
    AGE_5_6("5-6", "Usia 5–6 Tahun", "Mengenal angka, huruf, warna & bentuk", "🐣"),
    AGE_7_8("7-8", "Usia 7–8 Tahun", "Berhitung seru, membaca & fakta dunia", "🦁"),
    AGE_9_10("9-10", "Usia 9–10 Tahun", "Tantangan soal cerita, logika & sains", "🚀");

    companion object {
        fun fromId(id: String): AgeBracket {
            return entries.firstOrNull { it.id == id } ?: AGE_5_6
        }
    }
}

enum class QuizCategory(
    val id: String,
    val title: String,
    val shortDesc: String,
    val iconEmoji: String,
    val colorHex: Long
) {
    MATEMATIKA(
        "math",
        "Matematika",
        "Hitung seru, tebak angka & bentuk",
        "🔢",
        0xFFFB8500
    ),
    BAHASA_INDONESIA(
        "bahasa",
        "Bahasa Indonesia",
        "Kosa kata, lawan kata & menyusun kalimat",
        "📖",
        0xFF2A9D8F
    ),
    LOGIKA(
        "logika",
        "Logika & Pola",
        "Asah otak, urutan pola & teka-teki",
        "🧩",
        0xFF0077B6
    ),
    PENGETAHUAN_UMUM(
        "umum",
        "Pengetahuan Umum",
        "Dunia hewan, tata surya & Indonesia",
        "🌍",
        0xFF7209B7
    ),
    BONUS_CAMPURAN(
        "bonus",
        "Tantangan Campuran",
        "Ekspedisi seru kombinasi semua pulau",
        "🎁",
        0xFFE76F51
    );

    companion object {
        fun fromId(id: String): QuizCategory {
            return entries.firstOrNull { it.id == id } ?: MATEMATIKA
        }
    }
}

data class Question(
    val id: String,
    val category: QuizCategory,
    val ageBracket: AgeBracket,
    val questionText: String,
    val visualEmoji: String,
    val options: List<String>,
    val correctIndex: Int,
    val explanation: String,
    val hint: String,
    val difficulty: String = "Mudah"
) {
    fun withShuffledOptions(): Question {
        val correctValue = options.getOrNull(correctIndex) ?: return this
        val shuffled = options.shuffled()
        val newCorrectIndex = shuffled.indexOf(correctValue)
        return copy(options = shuffled, correctIndex = newCorrectIndex)
    }
}

data class QuestionAnswerRecord(
    val question: Question,
    val selectedOptionIndex: Int,
    val isCorrect: Boolean,
    val usedHint: Boolean
)

data class QuizResultSummary(
    val category: QuizCategory,
    val ageBracket: AgeBracket,
    val totalQuestions: Int,
    val correctCount: Int,
    val starsEarned: Int,
    val scorePercentage: Int,
    val hintsUsedCount: Int,
    val records: List<QuestionAnswerRecord>,
    val newBadgesUnlocked: List<BadgeInfo> = emptyList()
)

data class BadgeInfo(
    val id: String,
    val title: String,
    val description: String,
    val emoji: String,
    val isUnlocked: Boolean = false,
    val unlockedAt: Long = 0L
)
