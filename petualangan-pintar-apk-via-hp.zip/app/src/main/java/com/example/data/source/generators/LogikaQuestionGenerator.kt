package com.example.data.source.generators

import com.example.data.model.AgeBracket
import com.example.data.model.Question
import com.example.data.model.QuizCategory

object LogikaQuestionGenerator {

    fun generateQuestions(): List<Question> {
        val list = ArrayList<Question>(450)
        list.addAll(generateAge56())
        list.addAll(generateAge78())
        list.addAll(generateAge910())
        return list
    }

    private fun makeOptions(correct: String, vararg candidates: String, count: Int = 4): List<String> {
        val result = linkedSetOf(correct)
        for (c in candidates) {
            if (c != correct && c.isNotBlank()) {
                result.add(c)
                if (result.size == count) break
            }
        }
        var offset = 1
        while (result.size < count) {
            val fallback = "$correct (pilihan $offset)"
            offset++
            if (fallback != correct && !result.contains(fallback)) {
                result.add(fallback)
            }
        }
        return result.toList()
    }

    // =========================================================================
    // USIA 5-6 TAHUN (150 PERTANYAAN LOGIKA ALAMI)
    // =========================================================================
    private fun generateAge56(): List<Question> {
        val questions = ArrayList<Question>(150)
        var qId = 1

        // 1. Pola Visual Bergantian (50 pola unik berbeda)
        val patterns50 = listOf(
            Triple("Pola buah segar: 🍎 🍌 🍎 🍌 🍎 ... buah apakah berikutnya?", "🍌 Pisang", listOf("🍎 Apel", "🍇 Anggur")),
            Triple("Pola lingkaran warna: 🔴 🔵 🔴 🔵 🔴 ... warna apakah berikutnya?", "🔵 Biru", listOf("🔴 Merah", "🟡 Kuning")),
            Triple("Pola benda langit: ⭐ 🌙 ⭐ 🌙 ⭐ ... gambar apakah selanjutnya?", "🌙 Bulan", listOf("⭐ Bintang", "☀️ Matahari")),
            Triple("Pola hewan peliharaan: 🐱 🐶 🐱 🐶 🐱 ... hewan apakah berikutnya?", "🐶 Anjing", listOf("🐱 Kucing", "🐰 Kelinci")),
            Triple("Pola kendaraan jalan: 🚗 🚲 🚗 🚲 🚗 ... kendaraan apakah berikutnya?", "🚲 Sepeda", listOf("🚗 Mobil", "🚌 Bus")),
            Triple("Pola jajanan manis: 🍦 🍩 🍦 🍩 🍦 ... makanan manis apakah berikutnya?", "🍩 Donat", listOf("🍦 Es krim", "🍰 Kue")),
            Triple("Pola bentuk geometri: 🔺 🟦 🔺 🟦 🔺 ... bentuk apakah selanjutnya?", "🟦 Kotak", listOf("🔺 Segitiga", "🟡 Lingkaran")),
            Triple("Pola hewan laut: 🐟 🦀 🐟 🦀 🐟 ... hewan laut apakah berikutnya?", "🦀 Kepiting", listOf("🐟 Ikan", "🐙 Gurita")),
            Triple("Pola taman bunga: 🌸 🌻 🌸 🌻 🌸 ... bunga apakah berikutnya?", "🌻 Bunga Matahari", listOf("🌸 Bunga Mawar", "🍃 Daun")),
            Triple("Pola hadiah pesta: 🎈 🎁 🎈 🎁 🎈 ... benda apakah selanjutnya?", "🎁 Kado", listOf("🎈 Balon", "🎉 Terompet")),
            Triple("Pola buah tropis: 🍊 🍇 🍊 🍇 🍊 ... buah apakah selanjutnya?", "🍇 Anggur", listOf("🍊 Jeruk", "🍎 Apel")),
            Triple("Pola buah musim panas: 🍉 🍍 🍉 🍍 🍉 ... buah apakah selanjutnya?", "🍍 Nanas", listOf("🍉 Semangka", "🍌 Pisang")),
            Triple("Pola bentuk warna: 🟢 🟡 🟢 🟡 🟢 ... warna apakah selanjutnya?", "🟡 Kuning", listOf("🟢 Hijau", "🔵 Biru")),
            Triple("Pola simbol hati: 💖 💙 💖 💙 💖 ... hati warna apakah berikutnya?", "💙 Hati Biru", listOf("💖 Hati Pink", "💛 Hati Kuning")),
            Triple("Pola serangga lucu: 🐝 🦋 🐝 🦋 🐝 ... serangga apakah berikutnya?", "🦋 Kupu-kupu", listOf("🐝 Lebah", "🐞 Kumbang")),
            Triple("Pola alas kaki: 👟 🩴 👟 🩴 👟 ... alas kaki apakah selanjutnya?", "🩴 Sandal", listOf("👟 Sepatu", "🧦 Kaus kaki")),
            Triple("Pola sarapan pagi: 🍞 🥛 🍞 🥛 🍞 ... minuman apakah selanjutnya?", "🥛 Gelas Susu", listOf("🍞 Roti Tawar", "🍳 Telur")),
            Triple("Pola alat tulis: ✏️ 📏 ✏️ 📏 ✏️ ... alat tulis apakah selanjutnya?", "📏 Penggaris", listOf("✏️ Pensil", "✂️ Gunting")),
            Triple("Pola daun pohon: 🍁 🍃 🍁 🍃 🍁 ... daun apakah selanjutnya?", "🍃 Daun Hijau", listOf("🍁 Daun Merah", "🌸 Bunga")),
            Triple("Pola cuaca langit: ☀️ 🌧️ ☀️ 🌧️ ☀️ ... cuaca apakah selanjutnya?", "🌧️ Hujan", listOf("☀️ Cerah", "❄️ Salju")),
            Triple("Pola burung angkasa: 🦅 🦉 🦅 🦉 🦅 ... burung apakah selanjutnya?", "🦉 Burung Hantu", listOf("🦅 Elang", "🦆 Bebek")),
            Triple("Pola hewan ternak: 🐮 🐑 🐮 🐑 🐮 ... hewan ternak apakah selanjutnya?", "🐑 Domba", listOf("🐮 Sapi", "🐴 Kuda")),
            Triple("Pola tanaman sayur: 🥕 🥦 🥕 🥦 🥕 ... sayuran apakah selanjutnya?", "🥦 Brokoli", listOf("🥕 Wortel", "🍅 Tomat")),
            Triple("Pola buah berair: 🍓 🍒 🍓 🍒 🍓 ... buah berry apakah berikutnya?", "🍒 Ceri Merah", listOf("🍓 Stroberi", "🍋 Lemon")),
            Triple("Pola alat makan: 🥄 🍴 🥄 🍴 🥄 ... peralatan makan apakah selanjutnya?", "🍴 Garpu dan Pisau", listOf("🥄 Sendok Makan", "🥣 Mangkuk")),
            Triple("Pola pelindung badan: ☂️ 🧥 ☂️ 🧥 ☂️ ... pakaian apakah selanjutnya?", "🧥 Jas Hujan", listOf("☂️ Payung", "🧢 Topi")),
            Triple("Pola olahraga bola: ⚽ 🏀 ⚽ 🏀 ⚽ ... bola olahraga apakah selanjutnya?", "🏀 Bola Basket", listOf("⚽ Bola Sepak", "⚾ Bola Kasti")),
            Triple("Pola perlengkapan musik: 🎸 🥁 🎸 🥁 🎸 ... alat musik apakah selanjutnya?", "🥁 Drum Musik", listOf("🎸 Gitar", "🎹 Piano")),
            Triple("Pola hewan hutan: 🦁 🐯 🦁 🐯 🦁 ... hewan buas apakah berikutnya?", "🐯 Harimau", listOf("🦁 Singa", "🐻 Beruang")),
            Triple("Pola benda berkilau: 💎 👑 💎 👑 💎 ... perhiasan apakah selanjutnya?", "👑 Mahkota", listOf("💎 Berlian", "💍 Cincin")),
            Triple("Pola buah asam manis: 🍋 🍊 🍋 🍊 🍋 ... buah sitrus apakah selanjutnya?", "🍊 Jeruk Manis", listOf("🍋 Lemon Kuning", "🍏 Apel Hijau")),
            Triple("Pola tanaman bunga: 🌷 🌹 🌷 🌹 🌷 ... bunga apakah selanjutnya?", "🌹 Mawar Merah", listOf("🌷 Tulip Pink", "🌼 Aster")),
            Triple("Pola unggas air: 🦆 🦢 🦆 🦢 🦆 ... unggas anggun apakah selanjutnya?", "🦢 Angsa Putih", listOf("🦆 Bebek", "🐔 Ayam")),
            Triple("Pola buah kebun: 🍐 🍑 🍐 🍑 🍐 ... buah apakah berikutnya?", "🍑 Persik Manis", listOf("🍐 Pir Hijau", "🍈 Melon")),
            Triple("Pola waktu siang malam: 🌞 🌜 🌞 🌜 🌞 ... benda langit apakah selanjutnya?", "🌜 Bulan Sabit", listOf("🌞 Matahari", "⭐ Bintang")),
            Triple("Pola camilan gurih: 🍿 🥨 🍿 🥨 🍿 ... camilan apakah berikutnya?", "🥨 Pretzel", listOf("🍿 Popcorn", "🍪 Biskuit")),
            Triple("Pola bentuk kotak warna: 🟧 🟦 🟧 🟦 🟧 ... kotak warna apakah selanjutnya?", "🟦 Kotak Biru", listOf("🟧 Kotak Oranye", "🟨 Kotak Kuning")),
            Triple("Pola jamur kebun: 🍄 🌱 🍄 🌱 🍄 ... tumbuhan apakah selanjutnya?", "🌱 Tunas Hijau", listOf("🍄 Jamur Merah", "🌳 Pohon")),
            Triple("Pola ikan karang: 🐠 🐡 🐠 🐡 🐠 ... ikan laut apakah selanjutnya?", "🐡 Ikan Buntal", listOf("🐠 Ikan Badut", "🐬 Lumba-lumba")),
            Triple("Pola serangga malam: 🦗 🐞 🦗 🐞 🦗 ... serangga apakah berikutnya?", "🐞 Kumbang Kecil", listOf("🦗 Belalang", "🐜 Semut")),
            Triple("Pola makanan hangat: 🥣 🍲 🥣 🍲 🥣 ... makanan apakah berikutnya?", "🍲 Sup Hangat", listOf("🥣 Sereal Sarapan", "🥗 Salad")),
            Triple("Pola hidangan pesta: 🎂 🧁 🎂 🧁 🎂 ... kue manis apakah berikutnya?", "🧁 Cupcake", listOf("🎂 Kue Tart", "🍩 Donat")),
            Triple("Pola simbol berkilau: ✨ 💫 ✨ 💫 ✨ ... simbol cahaya apakah selanjutnya?", "💫 Bintang Meluncur", listOf("✨ Kilau Terang", "💥 Ledakan")),
            Triple("Pola transportasi udara: ✈️ 🚁 ✈️ 🚁 ✈️ ... kendaraan udara apakah selanjutnya?", "🚁 Helikopter", listOf("✈️ Pesawat", "🚀 Roket")),
            Triple("Pola kendaraan laut: ⛵ 🚢 ⛵ 🚢 ⛵ ... kendaraan air apakah selanjutnya?", "🚢 Kapal Feri", listOf("⛵ Perahu Layar", "🚤 Perahu Cepat")),
            Triple("Pola buah segar: 🍏 🍎 🍏 🍎 🍏 ... apel warna apakah selanjutnya?", "🍎 Apel Merah", listOf("🍏 Apel Hijau", "🍐 Pir")),
            Triple("Pola minuman sehat: 🥛 🧃 🥛 🧃 🥛 ... kemasan apakah selanjutnya?", "🧃 Kotak Jus Buah", listOf("🥛 Gelas Susu", "🍵 Teh Hangat")),
            Triple("Pola hewan mungil: 🐭 🐹 🐭 🐹 🐭 ... hewan mungil apakah selanjutnya?", "🐹 Hamster Lucu", listOf("🐭 Tikus Kecil", "🐰 Kelinci")),
            Triple("Pola kendaraan darat: 🚌 🚕 🚌 🚕 🚌 ... kendaraan kota apakah selanjutnya?", "🚕 Taksi Kuning", listOf("🚌 Bus Kota", "🚙 Mobil Jip")),
            Triple("Pola petualangan alam: 🏕️ 🏔️ 🏕️ 🏔️ 🏕️ ... bentang alam apakah selanjutnya?", "🏔️ Gunung Salju", listOf("🏕️ Tenda Kemah", "🌲 Pohon Cemara"))
        )
        for (item in patterns50) {
            val options = makeOptions(item.second, item.third[0], item.third[1], count = 3)
            questions.add(
                Question(
                    id = "logika_56_$qId",
                    category = QuizCategory.LOGIKA,
                    ageBracket = AgeBracket.AGE_5_6,
                    questionText = item.first,
                    visualEmoji = "🧩 Pola Ceria",
                    options = options,
                    correctIndex = 0,
                    explanation = "Pola ini bergantian secara teratur, sehingga berikutnya adalah '${item.second}'.",
                    hint = "Perhatikan pola yang berulang secara bergantian.",
                    difficulty = "Mudah"
                )
            )
            qId++
        } // 50 questions done

        // 2. Temukan yang Berbeda / Bukan Kelompoknya (50 pertanyaan unik alami)
        val oddOneOut50 = listOf(
            Triple("Manakah yang bukan termasuk kelompok hewan berkaki empat?", "Ayam", listOf("Kucing", "Sapi", "Kambing")),
            Triple("Manakah benda yang tidak bisa terbang tinggi di angkasa?", "Sepatu", listOf("Burung", "Pesawat", "Balon")),
            Triple("Manakah yang bukan termasuk jenis buah-buahan manis?", "Batu kali", listOf("Apel", "Pisang", "Jeruk")),
            Triple("Manakah yang bukan peralatan mandi bersih di kamar mandi?", "Panci masak", listOf("Sabun mandi", "Sikat gigi", "Handuk")),
            Triple("Manakah hewan yang tidak hidup di dalam air sungai atau laut?", "Kelinci", listOf("Ikan lele", "Udang", "Kepiting")),
            Triple("Manakah yang bukan perlengkapan belajar di dalam kelas?", "Guling tidur", listOf("Buku tulis", "Pensil", "Penghapus")),
            Triple("Manakah yang bukan benda langit yang ada di angkasa?", "Sepeda motor", listOf("Matahari", "Bulan", "Bintang")),
            Triple("Manakah yang bukan sayuran hijau segar untuk dimasak?", "Batu bata", listOf("Bayam", "Kangkung", "Sawi")),
            Triple("Manakah yang bukan jenis alat musik bersuara merdu?", "Kaus kaki", listOf("Gitar", "Piano", "Seruling")),
            Triple("Manakah yang bukan kendaraan beroda yang melaju di jalanan?", "Perahu dayung", listOf("Sepeda", "Mobil", "Sepeda motor")),
            Triple("Manakah hewan yang tidak memiliki sayap untuk terbang?", "Kucing", listOf("Kupu-kupu", "Burung", "Capung")),
            Triple("Manakah yang bukan minuman segar pelepas dahaga?", "Kapur tulis", listOf("Air putih", "Susu sapi", "Jus jeruk")),
            Triple("Manakah yang bukan pakaian yang kita kenakan di badan?", "Wajan goreng", listOf("Kemeja", "Celana", "Jaket")),
            Triple("Manakah benda yang tidak terbuat dari bahan kertas?", "Gelas kaca", listOf("Buku cerita", "Koran", "Kertas origami")),
            Triple("Manakah yang bukan termasuk rasa yang dikecap oleh lidah kita?", "Bulat", listOf("Manis", "Asin", "Pahit")),
            Triple("Manakah yang bukan anggota panca indra pada tubuh manusia?", "Rambut", listOf("Mata", "Telinga", "Hidung")),
            Triple("Manakah yang bukan warna dasar pelangi di langit?", "Hitam legam", listOf("Merah", "Kuning", "Biru")),
            Triple("Manakah yang bukan hewan peliharaan jinak di sekitar rumah?", "Buaya liar", listOf("Kelinci", "Ikan mas", "Kucing")),
            Triple("Manakah peralatan yang tidak kita gunakan saat menyantap hidangan?", "Sapu lantai", listOf("Piring makan", "Sendok", "Garpu")),
            Triple("Manakah yang bukan bunga hias beraroma wangi di taman?", "Pohon kelapa", listOf("Bunga mawar", "Bunga melati", "Bunga anggrek")),
            Triple("Manakah yang bukan peralatan tidur di kamar tidur anak?", "Kompor gas", listOf("Bantal empuk", "Selimut hangat", "Kasur")),
            Triple("Manakah hewan berkaki dua yang menghasilkan telur lezat?", "Sapi perah", listOf("Ayam betina", "Bebek", "Burung puyuh")),
            Triple("Manakah benda yang sifatnya tajam dan berbahaya jika tidak hati-hati?", "Gunting tajam", listOf("Bantal kapuk", "Boneka bulu", "Spons lembut")),
            Triple("Manakah yang bukan benda cair yang dapat mengalir?", "Batu kali", listOf("Air putih", "Minyak goreng", "Susu cair")),
            Triple("Manakah hewan liar berbadan raksasa dan memiliki belalai panjang?", "Gajah sumatera", listOf("Kucing anggora", "Kelinci hias", "Tupai")),
            Triple("Manakah yang bukan bagian utama dari sebatang pohon rindang?", "Roda gigi", listOf("Akar tanah", "Batang kayu", "Daun rimbun")),
            Triple("Manakah alas kaki yang kita pakai saat musim hujan becek?", "Sepatu bot karet", listOf("Kaus kaki wol saja", "Sepatu kain", "Kertas tipis")),
            Triple("Manakah yang bukan permainan asyik di taman bermain anak?", "Menyetrika baju", listOf("Ayunan rantai", "Perosotan licin", "Jungkat-jungkit")),
            Triple("Manakah bahan makanan manis yang dihasilkan oleh lebah madu?", "Madu lebah", listOf("Garam laut", "Cuka masam", "Kecap asin")),
            Triple("Manakah yang bukan alat kebersihan rumah tangga?", "Televisi", listOf("Sapu lidi", "Kain pel lantai", "Kemoceng bulu")),
            Triple("Manakah makanan pokok orang Indonesia yang dimasak dari beras?", "Nasi putih", listOf("Roti gandum", "Permen karet", "Es krim")),
            Triple("Manakah yang bukan anggota keluarga inti di dalam rumah?", "Montir mobil", listOf("Ayah", "Ibu", "Adik")),
            Triple("Manakah hewan yang bergerak dengan cara melompat gesit?", "Katak hijau", listOf("Siput kebun", "Kura-kura", "Cacing tanah")),
            Triple("Manakah hewan laut berlengan delapan yang mengeluarkan tinta hitam?", "Gurita laut", listOf("Ikan paus", "Udang karang", "Kuda laut")),
            Triple("Manakah benda yang jika terkena api menyala akan meletus bersuara dar?", "Balon udara", listOf("Batu kerikil", "Besi baja", "Bata merah")),
            Triple("Manakah yang bukan hari sekolah dari Senin sampai Jumat?", "Hari Minggu", listOf("Hari Selasa", "Hari Rabu", "Hari Kamis")),
            Triple("Manakah yang bukan bentuk bangun geometri dua dimensi?", "Buku cerita tebal", listOf("Segitiga", "Lingkaran", "Persegi")),
            Triple("Manakah sumber cahaya alami terbesar di siang hari yang terang?", "Matahari", listOf("Lilin kecil", "Lampu senter", "Korek api")),
            Triple("Manakah tempat yang tepat untuk berobat saat kita merasa demam?", "Puskesmas atau klinik", listOf("Pasar tradisional", "Stasiun kereta", "Bioskop")),
            Triple("Manakah alas tidur yang diletakkan di atas kasur agar bersih dan rapi?", "Seprai kasur", listOf("Gorden jendela", "Taplak meja", "Keset kaki")),
            Triple("Manakah alat komunikasi canggih yang bisa dibawa ke mana-mana untuk menelepon?", "Ponsel pintar", listOf("Kulkas dapur", "Mesin cuci", "Kipas angin")),
            Triple("Manakah yang bukan rasa es krim yang sering dinikmati anak-anak?", "Rasa pedas cabai", listOf("Rasa cokelat", "Rasa stroberi", "Rasa vanila")),
            Triple("Manakah tempat membeli obat sesuai resep dokter yang benar?", "Apotek obat", listOf("Bengkel las", "Toko bunga", "Salon kecantikan")),
            Triple("Manakah yang bukan pelindung tubuh dari sengatan terik panas matahari?", "Jaket es kutub", listOf("Topi bundar", "Payung peneduh", "Kacamata hitam")),
            Triple("Manakah burung cantik bertubuh besar yang bisa melebarkan bulu ekor merak warna-warni?", "Burung merak", listOf("Burung gereja", "Burung dara", "Ayam kalkun")),
            Triple("Manakah hewan yang terkenal berjalan sangat lambat membawa rumah cangkangnya?", "Siput kebun", listOf("Kuda balap", "Harimau tutul", "Kancil cerdik")),
            Triple("Manakah yang bukan nama hari dalam sepekan di kalender?", "Bulan Januari", listOf("Hari Senin", "Hari Jumat", "Hari Sabtu")),
            Triple("Manakah benda yang jika jatuh ke lantai ubin bisa mudah pecah berkeping-keping?", "Piring kaca", listOf("Bantal kapas", "Bola karet", "Kaus kaki")),
            Triple("Manakah yang bukan perlengkapan melukis pemandangan indah?", "Sendok semen", listOf("Kuas lukis", "Cat air warna", "Kertas gambar")),
            Triple("Manakah yang merupakan sumber air minum alami yang paling jernih dan segar?", "Mata air pegunungan", listOf("Air kubangan becek", "Air selokan", "Air cucian piring"))
        )
        for (item in oddOneOut50) {
            val wrongs = item.third.take(3)
            val options = makeOptions(item.second, wrongs[0], wrongs.getOrElse(1) { "LAIN" }, wrongs.getOrElse(2) { "BEDA" }, count = 4)

            questions.add(
                Question(
                    id = "logika_56_$qId",
                    category = QuizCategory.LOGIKA,
                    ageBracket = AgeBracket.AGE_5_6,
                    questionText = item.first,
                    visualEmoji = "🔎 Logika Cermat",
                    options = options,
                    correctIndex = 0,
                    explanation = "Tepat! Pilihan '${item.second}' tidak termasuk dalam kelompok yang dimaksud.",
                    hint = "Perhatikan sifat atau kelompok benda yang paling berbeda.",
                    difficulty = "Mudah"
                )
            )
            qId++
        } // 100 questions done

        // 3. Pasangan Logis & Kegunaan Sehari-hari (50 pertanyaan unik alami)
        val logicPairs50 = listOf(
            Triple("Jika burung terbang di udara bebas, maka ikan berenang di mana?", "Air sungai atau laut", listOf("Dahan pohon", "Tanah kering", "Atap rumah")),
            Triple("Gelas digunakan untuk minum air segar, sedangkan piring ceper digunakan untuk apa?", "Makan hidangan", listOf("Mencuci baju", "Menyiram tanaman", "Menyisir rambut")),
            Triple("Sepatu dipakai rapi di kedua kaki, sedangkan topi bundar dipakai di mana?", "Kepala", listOf("Tangan", "Punggung", "Lutut")),
            Triple("Pensil digunakan untuk menulis di kertas, sedangkan penghapus karet digunakan untuk apa?", "Menghapus coretan salah", listOf("Menggunting kertas", "Mewarnai dinding", "Mengukur panjang")),
            Triple("Sendok digunakan untuk mengambil sup kuah, sedangkan garpu digunakan untuk apa?", "Menusuk makanan padat", listOf("Memotong kayu", "Menampung air", "Mengaduk cat")),
            Triple("Mata kita gunakan untuk melihat pemandangan, sedangkan telinga kita gunakan untuk apa?", "Mendengar suara", listOf("Mencium wangi", "Mengecap rasa", "Meraba benda")),
            Triple("Hidung digunakan untuk bernapas dan mencium aroma, sedangkan mulut digunakan untuk apa?", "Berbicara dan makan", listOf("Melihat pemandangan", "Melompat tinggi", "Berlari")),
            Triple("Kuas digunakan bersama cat untuk melukis, sedangkan pensil warna digunakan untuk apa?", "Mewarnai gambar", listOf("Menghapus meja", "Mencuci piring", "Menyapu")),
            Triple("Gunting digunakan untuk memotong bahan kertas, sedangkan lem kertas digunakan untuk apa?", "Merekatkan kertas", listOf("Merobek buku", "Menulis cerita", "Mewarnai")),
            Triple("Sikat gigi digunakan bersama odol untuk gigi, sedangkan sampo rambut digunakan untuk apa?", "Mencuci rambut kepala", listOf("Membersihkan sepatu", "Menyikat baju", "Mencuci mobil")),
            Triple("Kompor gas berada di dapur untuk memasak, sedangkan kasur empuk berada di mana?", "Kamar tidur", listOf("Kamar mandi", "Garasi motor", "Halaman taman")),
            Triple("Mobil diparkir aman di dalam garasi, sedangkan buku pelajaran disimpan di mana?", "Rak buku atau lemari", listOf("Kulkas makanan", "Mesin cuci", "Wajan")),
            Triple("Pakaian bersih disimpan di lemari pakaian, sedangkan makanan dingin disimpan di mana?", "Kulkas pendingin", listOf("Kotak sepatu", "Tas ransel", "Bawah tempat tidur")),
            Triple("Payung digunakan saat hujan agar tidak basah, sedangkan selimut tidur digunakan untuk apa?", "Menghangatkan tubuh saat tidur", listOf("Menahan angin topan", "Menerangi kamar", "Membersihkan lantai")),
            Triple("Sarung tangan melindungi kedua tangan kita, sedangkan kaus kaki melindungi bagian apa?", "Kedua telapak kaki", listOf("Kedua telinga", "Leher kita", "Kepala kita")),
            Triple("Kipas angin digunakan saat cuaca terasa gerah panas, sedangkan jaket tebal dipakai saat apa?", "Cuaca terasa dingin", listOf("Sedang kepanasan", "Saat berenang", "Saat makan")),
            Triple("Buku cerita untuk dibaca dengan saksama, sedangkan musik ceria untuk apa?", "Didengarkan dengan gembira", listOf("Dimakan dengan sendok", "Dilihat di cermin", "Disapu bersih")),
            Triple("Sepeda dikayuh menggunakan kekuatan kaki, sedangkan mobil berjalan menggunakan apa?", "Mesin bertenaga bahan bakar", listOf("Kayuhan tangan", "Tiupan angin mulut", "Ditarik tali")),
            Triple("Sapu lidi digunakan untuk menyapu halaman daun, sedangkan kain pel digunakan untuk apa?", "Mengepel lantai rumah yang basah", listOf("Membersihkan atap langit", "Menghapus papan tulis", "Menyisir rambut")),
            Triple("Cermin digunakan untuk melihat bayangan diri kita, sedangkan jam dinding digunakan untuk apa?", "Mengetahui waktu", listOf("Mendengarkan siaran musik", "Menyalakan api", "Menyimpan uang")),
            Triple("Helm dipakai pengendara motor di kepala, sedangkan sabuk pengaman mobil dipasang di mana?", "Menyilang di badan penumpang", listOf("Di atas kepala", "Di telapak kaki", "Di tangan")),
            Triple("Gembok digunakan untuk mengunci pintu pagar, sedangkan kunci logam digunakan untuk apa?", "Membuka dan mengunci gembok", listOf("Memotong tali", "Menyalakan kompor", "Menulis")),
            Triple("Kelinci suka memakan wortel renyah, sedangkan monyet sangat suka memakan buah apa?", "Pisang manis", listOf("Cabai rawit pedas", "Daging sapi mentah", "Rumput ilalang")),
            Triple("Sapi menghasilkan susu murni yang lezat, sedangkan ayam betina menghasilkan apa?", "Telur ayam", listOf("Madu lebah", "Minyak goreng", "Gula pasir")),
            Triple("Lebah mengumpulkan nektar bunga untuk membuat madu, sedangkan ulat sutra menghasilkan apa?", "Serat benang sutra", listOf("Minyak kelapa", "Batu kapur", "Tepung terigu")),
            Triple("Siang hari diterangi oleh teriknya matahari, sedangkan malam hari diterangi oleh apa?", "Bulan dan bintang-bintang", listOf("Pelangi warna-warni", "Awan mendung", "Tanah basah")),
            Triple("Saat kita lapar tubuh kita membutuhkan makan, sedangkan saat kita haus tubuh membutuhkan apa?", "Minum air bersih", listOf("Tidur lelap", "Bermain sepeda", "Membaca buku")),
            Triple("Saat tubuh terasa lelah kita beristirahat tidur, sedangkan saat tubuh kotor kita perlu apa?", "Mandi dengan sabun bersih", listOf("Makan permen manis", "Berlari kencang", "Bermain pasir")),
            Triple("Bunga melati harum bermahkota warna putih, sedangkan daun mangga segar berwarna apa?", "Hijau", listOf("Merah muda", "Biru laut", "Cokelat tua")),
            Triple("Api yang menyala menghasilkan rasa panas, sedangkan balok es menghasilkan rasa apa?", "Dingin membeku", listOf("Manis legit", "Hangat suam", "Asin gurih")),
            Triple("Batu kali saat dipegang terasa keras dan padat, sedangkan kapas bantal terasa bagaimana?", "Lembut dan empuk", listOf("Kasar dan tajam", "Panas membakar", "Berat sekali")),
            Triple("Gula pasir memberikan rasa manis pada minuman, sedangkan garam dapur memberikan rasa apa?", "Asin gurih", listOf("Pahit getir", "Masam segar", "Pedas menyengat")),
            Triple("Cabai merah yang digigit menghasilkan rasa pedas, sedangkan buah lemon menghasilkan rasa apa?", "Asam masam segar", listOf("Manis legit", "Pahit obat", "Tawar")),
            Triple("Pelari tercepat di darat adalah citah, sedangkan burung tercepat menukik di angkasa adalah?", "Burung alap-alap kawah", listOf("Ayam petelur", "Bebek danau", "Burung pipit")),
            Triple("Kelinci bergerak dengan cara melompat lincah, sedangkan ular bergerak dengan cara bagaimana?", "Melata di atas tanah", listOf("Terbang dengan sayap", "Mengayuh pedal", "Berjalan dua kaki")),
            Triple("Kura-kura berlindung di dalam cangkang kerasnya, sedangkan siput berlindung di dalam apa?", "Cangkang cangkirnya", listOf("Sarang burung", "Kandang kayu", "Bawah tanah")),
            Triple("Burung bertelur dan menetas di sarangnya di dahan, sedangkan lebah madu tinggal di mana?", "Sarang sarang lebah", listOf("Dalam lubang air", "Bawah kasur", "Kandang ayam")),
            Triple("Semut berjalan beriringan membawa butir gula, sedangkan rayap hidup memakan bahan apa?", "Kayu lapuk", listOf("Batu bata", "Besi baja", "Kaca jendela")),
            Triple("Nelayan berlayar menangkap ikan di laut, sedangkan petani bekerja menanam apa di sawah?", "Padi dan sayuran", listOf("Ikan paus", "Sepeda motor", "Batu permata")),
            Triple("Sopir bertugas mengemudikan mobil bus, sedangkan masinis bertugas menjalankan kendaraan apa?", "Kereta api jalur rel", listOf("Pesawat terbang", "Kapal selam", "Sepeda kayuh")),
            Triple("Pilot bertugas menerbangkan pesawat di angkasa, sedangkan nakhoda bertugas mengemudikan apa?", "Kapal laut di samudra", listOf("Mobil balap", "Kereta bawah tanah", "Delman kuda")),
            Triple("Guru bertugas mengajar murid-murid di sekolah, sedangkan dokter bertugas merawat siapa?", "Pasien yang sedang sakit", listOf("Mobil yang mogok", "Pohon yang layu", "Pakaian sobek")),
            Triple("Koki bertugas memasak masakan lezat di restoran, sedangkan penjahit bertugas membuat apa?", "Pakaian dan baju rapi", listOf("Sepatu roda", "Kue tart", "Gedung tinggi")),
            Triple("Pustakawan menjaga ketertiban dan buku di perpustakaan, sedangkan kasir bertugas apa?", "Melayani pembayaran belanja", listOf("Mengendarai bus", "Menyiram tanaman", "Menambal ban")),
            Triple("Polisi lalu lintas bertugas mengatur keamanan di jalan raya, sedangkan pemadam kebakaran bertugas apa?", "Memadamkan kobaran api bencana", listOf("Menjual buku bacaan", "Memeriksa gigi anak", "Mencukur rambut")),
            Triple("Tukang pos mengantarkan surat dan paket ke alamat rumah, sedangkan kurir mengantarkan apa?", "Barang pesanan pelanggan", listOf("Obat di rumah sakit", "Tiket kereta api", "Ikan di pasar")),
            Triple("Arsitek merancang gambar denah rumah kokoh, sedangkan montir bertugas memperbaiki apa?", "Kendaraan yang rusak", listOf("Piring pecah", "Buku robek", "Sepatu kain")),
            Triple("Penjaga gawang dalam sepak bola bertugas menangkap bola, sedangkan wasit bertugas apa?", "Memimpin jalannya pertandingan dengan adil", listOf("Menendang gol", "Menonton di tribun", "Menjual tiket")),
            Triple("Murid yang rajin belajar akan bertambah pandai, sedangkan jika sering berlatih olahraga tubuh menjadi?", "Sehat dan bugar", listOf("Mudah lemas", "Sering sakit", "Bertambah kurus")),
            Triple("Jika kita menyayangi hewan peliharaan dengan memberi makan teratur, hewan akan bersikap?", "Jinak dan setia menyayangi kita", listOf("Takut dan kabur", "Menggigit tanpa sebab", "Marah setiap saat"))
        )
        for (item in logicPairs50) {
            val wrongs = item.third.take(3)
            val options = makeOptions(item.second, wrongs[0], wrongs.getOrElse(1) { "LAIN" }, wrongs.getOrElse(2) { "BEDA" }, count = 4)

            questions.add(
                Question(
                    id = "logika_56_$qId",
                    category = QuizCategory.LOGIKA,
                    ageBracket = AgeBracket.AGE_5_6,
                    questionText = item.first,
                    visualEmoji = "🔗 Pasangan Logis",
                    options = options,
                    correctIndex = 0,
                    explanation = "Jawaban yang tepat secara logika adalah '${item.second}'.",
                    hint = "Pikirkan hubungan pasangan fungsi dan perannya dalam kehidupan.",
                    difficulty = "Mudah"
                )
            )
            qId++
        } // Exactly 150 questions for Age 5-6!

        return questions
    }

    // =========================================================================
    // USIA 7-8 TAHUN (150 PERTANYAAN LOGIKA ALAMI)
    // =========================================================================
    private fun generateAge78(): List<Question> {
        val questions = ArrayList<Question>(150)
        var qId = 1

        // 1. Pola Tiga Elemen & Simbol Berulang (50 urutan unik berbeda)
        val patterns78 = listOf(
            Triple("Perhatikan pola bentuk: Segitiga, Persegi, Lingkaran, Segitiga, Persegi, ... bentuk apakah berikutnya?", "Lingkaran", listOf("Segitiga", "Persegi", "Bintang")),
            Triple("Perhatikan pola arah panah: ⬆️ Atas, ➡️ Kanan, ⬇️ Bawah, ⬆️ Atas, ➡️ Kanan, ... arah panah berikutnya adalah?", "⬇️ Bawah", listOf("⬆️ Atas", "⬅️ Kiri", "↗️ Serong")),
            Triple("Perhatikan pola cuaca alam: ☀️ Cerah, ⛅ Berawan, 🌧️ Hujan, ☀️ Cerah, ⛅ Berawan, ... cuaca berikutnya adalah?", "🌧️ Hujan", listOf("☀️ Cerah", "⛅ Berawan", "⚡ Petir")),
            Triple("Perhatikan pola ukuran lingkaran: Kecil, Sedang, Besar, Kecil, Sedang, ... ukuran lingkaran berikutnya adalah?", "Besar", listOf("Kecil", "Sedang", "Raksasa")),
            Triple("Perhatikan urutan warna rambu lalu lintas: Merah, Kuning, Hijau, Merah, Kuning, ... warna lampu berikutnya adalah?", "Hijau", listOf("Merah", "Kuning", "Biru")),
            Triple("Perhatikan pola bangun datar: 3 sisi (segitiga), 4 sisi (segi empat), 5 sisi (segi lima), ... bangun berikutnya bersisi berapa?", "6 sisi (segi enam)", listOf("3 sisi", "4 sisi", "7 sisi")),
            Triple("Perhatikan pola lompatan dua langkah: 2, 4, 6, 8, 10, ... angka bilangan berikutnya adalah?", "12", listOf("11", "13", "14")),
            Triple("Perhatikan pola kelipatan tiga: 3, 6, 9, 12, 15, ... angka bilangan berikutnya adalah?", "18", listOf("16", "17", "20")),
            Triple("Perhatikan pola pengurangan mundur: 20, 18, 16, 14, 12, ... angka bilangan berikutnya adalah?", "10", listOf("8", "9", "11")),
            Triple("Perhatikan pola kelipatan lima: 5, 10, 15, 20, 25, ... angka bilangan berikutnya adalah?", "30", listOf("26", "28", "35")),
            Triple("Perhatikan urutan huruf alfabet berselang satu: A, C, E, G, ... huruf alfabet berikutnya adalah?", "I", listOf("H", "J", "K")),
            Triple("Perhatikan urutan huruf alfabet berurutan ganda: AA, BB, CC, DD, ... pasangan huruf berikutnya adalah?", "EE", listOf("EF", "FF", "DE")),
            Triple("Perhatikan pola angka ganjil: 1, 3, 5, 7, 9, ... angka bilangan berikutnya adalah?", "11", listOf("10", "12", "13")),
            Triple("Perhatikan pola angka genap: 10, 12, 14, 16, 18, ... angka bilangan berikutnya adalah?", "20", listOf("19", "21", "22")),
            Triple("Perhatikan pola pengurangan lima: 50, 45, 40, 35, 30, ... angka bilangan berikutnya adalah?", "25", listOf("20", "24", "28")),
            Triple("Perhatikan pola perkalian dua: 1, 2, 4, 8, 16, ... angka bilangan berikutnya adalah?", "32", listOf("24", "28", "30")),
            Triple("Perhatikan pola bertambah bertingkat: 1, 2, 4, 7, 11 (+1, +2, +3, +4), ... angka berikutnya adalah?", "16 (+5)", listOf("15", "14", "17")),
            Triple("Perhatikan pola huruf alfabet mundur: Z, Y, X, W, V, ... huruf alfabet berikutnya adalah?", "U", listOf("T", "S", "R")),
            Triple("Perhatikan pola urutan waktu harian: Pagi, Siang, Sore, Malam, Pagi, Siang, ... waktu berikutnya adalah?", "Sore", listOf("Malam", "Pagi", "Subuh")),
            Triple("Perhatikan pola urutan musim tropis: Kemarau, Hujan, Kemarau, Hujan, Kemarau, ... musim berikutnya adalah?", "Hujan", listOf("Kemarau", "Salju", "Semi")),
            Triple("Perhatikan pola urutan siklus kupu-kupu: Telur, Ulat, Kepompong, Kupu-kupu, Telur, Ulat, ... tahap berikutnya adalah?", "Kepompong", listOf("Kupu-kupu", "Telur", "Kepiting")),
            Triple("Perhatikan pola perkalian tiga: 1, 3, 9, 27, ... angka bilangan berikutnya adalah?", "81", listOf("54", "60", "72")),
            Triple("Perhatikan deret bilangan lompat empat: 4, 8, 12, 16, 20, ... angka bilangan berikutnya adalah?", "24", listOf("22", "23", "28")),
            Triple("Perhatikan deret bilangan lompat enam: 6, 12, 18, 24, 30, ... angka bilangan berikutnya adalah?", "36", listOf("32", "34", "40")),
            Triple("Perhatikan deret bilangan lompat tujuh: 7, 14, 21, 28, 35, ... angka bilangan berikutnya adalah?", "42", listOf("38", "40", "49")),
            Triple("Perhatikan deret bilangan lompat delapan: 8, 16, 24, 32, 40, ... angka bilangan berikutnya adalah?", "48", listOf("44", "46", "52")),
            Triple("Perhatikan deret bilangan lompat sembilan: 9, 18, 27, 36, 45, ... angka bilangan berikutnya adalah?", "54", listOf("50", "52", "60")),
            Triple("Perhatikan deret bilangan lompat sepuluh: 10, 20, 30, 40, 50, ... angka bilangan berikutnya adalah?", "60", listOf("55", "70", "100")),
            Triple("Perhatikan deret mundur lompat sepuluh: 100, 90, 80, 70, 60, ... angka bilangan berikutnya adalah?", "50", listOf("40", "55", "30")),
            Triple("Perhatikan deret bilangan kuadrat dasar: 1, 4, 9, 16, 25, ... angka bilangan berikutnya adalah?", "36", listOf("30", "32", "40")),
            Triple("Perhatikan pola lambang wajik dan sekop: ♠️ Sekop, ♥️ Hati, ♦️ Wajik, ♣️ Keriting, ♠️ Sekop, ... lambang berikutnya adalah?", "♥️ Hati", listOf("♦️ Wajik", "♣️ Keriting", "⭐ Bintang")),
            Triple("Perhatikan pola deret desimal sederhana: 0.2, 0.4, 0.6, 0.8, ... angka bilangan berikutnya adalah?", "1.0", listOf("0.9", "1.2", "1.5")),
            Triple("Perhatikan pola pecahan sederhana: 1/4, 2/4, 3/4, ... pecahan berikutnya adalah?", "4/4 (atau 1)", listOf("5/4", "3/8", "2/4")),
            Triple("Perhatikan pola bilangan ganjil mundur: 21, 19, 17, 15, 13, ... angka bilangan berikutnya adalah?", "11", listOf("9", "10", "12")),
            Triple("Perhatikan pola waktu jam: Pukul 01.00, 03.00, 05.00, 07.00, ... waktu berikutnya adalah?", "Pukul 09.00", listOf("Pukul 08.00", "Pukul 10.00", "Pukul 11.00")),
            Triple("Perhatikan pola hari berselang: Senin, Rabu, Jumat, ... hari berselang berikutnya adalah?", "Minggu", listOf("Sabtu", "Selasa", "Kamis")),
            Triple("Perhatikan pola urutan nama bulan awal: Januari, Februari, Maret, April, Mei, ... bulan berikutnya adalah?", "Juni", listOf("Juli", "Agustus", "September")),
            Triple("Perhatikan pola huruf berselang dua: A, D, G, J, ... huruf berikutnya adalah?", "M", listOf("K", "L", "N")),
            Triple("Perhatikan pola kombinasi angka-huruf: 1A, 2B, 3C, 4D, ... kombinasi berikutnya adalah?", "5E", listOf("5F", "6E", "4E")),
            Triple("Perhatikan pola segitiga bertambah titik: 1 titik, 3 titik, 6 titik, 10 titik, ... jumlah titik berikutnya adalah?", "15 titik", listOf("12 titik", "14 titik", "16 titik")),
            Triple("Perhatikan pola deret berselang tambah dan kurang: 10, 12, 11, 13, 12, 14, ... angka berikutnya adalah?", "13", listOf("15", "12", "16")),
            Triple("Perhatikan pola bilangan ganda selang-seling: 2, 2, 4, 4, 6, 6, ... angka bilangan berikutnya adalah?", "8", listOf("7", "6", "10")),
            Triple("Perhatikan pola susunan kubus bertingkat: 1 tingkat, 2 tingkat, 3 tingkat, 4 tingkat, ... susunan berikutnya adalah?", "5 tingkat", listOf("6 tingkat", "7 tingkat", "4 tingkat")),
            Triple("Perhatikan pola putaran sudut: 0°, 90°, 180°, 270°, ... besar sudut putaran berikutnya adalah?", "360° (Satu putaran penuh)", listOf("300°", "320°", "400°")),
            Triple("Perhatikan pola bilangan ratusan: 100, 200, 300, 400, 500, ... angka bilangan berikutnya adalah?", "600", listOf("550", "700", "1000")),
            Triple("Perhatikan pola pembagian dua: 64, 32, 16, 8, ... angka bilangan berikutnya adalah?", "4", listOf("2", "6", "0")),
            Triple("Perhatikan pola pembagian tiga: 81, 27, 9, ... angka bilangan berikutnya adalah?", "3", listOf("1", "6", "0")),
            Triple("Perhatikan pola bertambah bertahap (+10): 15, 25, 35, 45, 55, ... angka bilangan berikutnya adalah?", "65", listOf("60", "70", "75")),
            Triple("Perhatikan pola hitung mundur (-3): 30, 27, 24, 21, 18, ... angka bilangan berikutnya adalah?", "15", listOf("12", "14", "16")),
            Triple("Perhatikan pola hitung maju (+11): 11, 22, 33, 44, 55, ... angka bilangan berikutnya adalah?", "66", listOf("60", "65", "77"))
        )
        for (item in patterns78) {
            val wrongs = item.third.take(3)
            val options = makeOptions(item.second, wrongs[0], wrongs.getOrElse(1) { "LAIN" }, wrongs.getOrElse(2) { "BEDA" }, count = 4)

            questions.add(
                Question(
                    id = "logika_78_$qId",
                    category = QuizCategory.LOGIKA,
                    ageBracket = AgeBracket.AGE_7_8,
                    questionText = item.first,
                    visualEmoji = "📈 Deret Teratur",
                    options = options,
                    correctIndex = 0,
                    explanation = "Pola ini bergerak teratur, jawaban yang benar adalah '${item.second}'.",
                    hint = "Hitung selisih atau aturan pengulangan dari tiap elemen.",
                    difficulty = "Sedang"
                )
            )
            qId++
        } // 50 questions done

        // 2. Hubungan Analogi Logika Kata (50 analogi unik berbeda)
        val analogies50 = listOf(
            Triple("Lengkapilah analogi ini: Dokter : Rumah Sakit = Guru : ... ?", "Sekolah", listOf("Pasar", "Sawah", "Stasiun")),
            Triple("Lengkapilah analogi ini: Siang : Terang = Malam : ... ?", "Gelap", listOf("Mendung", "Silau", "Dingin")),
            Triple("Lengkapilah analogi ini: Burung : Sayap = Ikan : ... ?", "Sirip", listOf("Kaki", "Ekor saja", "Paruh")),
            Triple("Lengkapilah analogi ini: Mobil : Garasi = Burung : ... ?", "Sarang", listOf("Langit", "Pohon saja", "Kandang besi")),
            Triple("Lengkapilah analogi ini: Sepatu : Kaki = Sarung Tangan : ... ?", "Tangan", listOf("Telinga", "Leher", "Kepala")),
            Triple("Lengkapilah analogi ini: Buku : Membaca = Lagu : ... ?", "Mendengarkan", listOf("Melihat", "Menulis", "Menyiram")),
            Triple("Lengkapilah analogi ini: Lapar : Makan = Haus : ... ?", "Minum", listOf("Tidur", "Berlari", "Bermain")),
            Triple("Lengkapilah analogi ini: Petani : Cangkul = Pelukis : ... ?", "Kuas lukis", listOf("Pisau bedah", "Palu", "Gergaji")),
            Triple("Lengkapilah analogi ini: Nelayan : Laut = Petani : ... ?", "Sawah atau ladang", listOf("Kantor", "Bengkel", "Pabrik")),
            Triple("Lengkapilah analogi ini: Api : Panas = Es : ... ?", "Dingin", listOf("Manis", "Asin", "Hangat")),
            Triple("Lengkapilah analogi ini: Jam : Waktu = Termometer : ... ?", "Suhu", listOf("Panjang", "Berat", "Jarak")),
            Triple("Lengkapilah analogi ini: Penggaris : Panjang = Timbangan : ... ?", "Berat", listOf("Waktu", "Volume", "Suhu")),
            Triple("Lengkapilah analogi ini: Kacamata : Mata = Alat Bantu Dengar : ... ?", "Telinga", listOf("Hidung", "Mulut", "Lidah")),
            Triple("Lengkapilah analogi ini: Jaket : Dingin = Payung : ... ?", "Hujan atau terik", listOf("Angin", "Malam", "Tidur")),
            Triple("Lengkapilah analogi ini: Singa : Daging = Sapi : ... ?", "Rumput", listOf("Ikan", "Madu", "Buah apel")),
            Triple("Lengkapilah analogi ini: Ayam : Telur = Sapi : ... ?", "Susu murni", listOf("Minyak", "Madu", "Beras")),
            Triple("Lengkapilah analogi ini: Gajah : Belalai = Badak : ... ?", "Cula", listOf("Sayap", "Taring", "Tanduk")),
            Triple("Lengkapilah analogi ini: Katak : Melompat = Ular : ... ?", "Melata", listOf("Terbang", "Berenang saja", "Berlari")),
            Triple("Lengkapilah analogi ini: Kapal : Nakhoda = Pesawat : ... ?", "Pilot", listOf("Sopir", "Masinis", "Kondektur")),
            Triple("Lengkapilah analogi ini: Kereta : Masinis = Mobil Bus : ... ?", "Sopir", listOf("Pilot", "Nakhoda", "Petani")),
            Triple("Lengkapilah analogi ini: Kamera : Foto = Perekam Suara : ... ?", "Audio rekaman", listOf("Lukisan", "Buku", "Patung")),
            Triple("Lengkapilah analogi ini: Pena : Tinta = Pensil : ... ?", "Karbon grafit", listOf("Air", "Cat minyak", "Kapur")),
            Triple("Lengkapilah analogi ini: Rumah : Manusia = Sarang : ... ?", "Burung", listOf("Ikan", "Cacing", "Batu")),
            Triple("Lengkapilah analogi ini: Air : Mengalir = Udara : ... ?", "Berembus", listOf("Membeku", "Menyala", "Mendidih")),
            Triple("Lengkapilah analogi ini: Gula : Manis = Garam : ... ?", "Asin", listOf("Pahit", "Pedas", "Asam")),
            Triple("Lengkapilah analogi ini: Cabai : Pedas = Kopi Murni : ... ?", "Pahit", listOf("Manis", "Asin", "Asam")),
            Triple("Lengkapilah analogi ini: Lemon : Asam = Madu : ... ?", "Manis", listOf("Pahit", "Asin", "Tawar")),
            Triple("Lengkapilah analogi ini: Matahari : Siang = Bintang : ... ?", "Malam", listOf("Sore", "Pagi", "Subuh")),
            Triple("Lengkapilah analogi ini: Roti : Terigu = Tahu : ... ?", "Kedelai", listOf("Beras", "Jagung", "Gandum")),
            Triple("Lengkapilah analogi ini: Nasi : Beras = Minyak Goreng : ... ?", "Kelapa sawit", listOf("Batu bara", "Gandum", "Air")),
            Triple("Lengkapilah analogi ini: Daun : Hijau = Darah Bersih : ... ?", "Merah", listOf("Kuning", "Biru", "Hitam")),
            Triple("Lengkapilah analogi ini: Langit Cerah : Biru = Awan Mendung : ... ?", "Abu-abu gelap", listOf("Merah muda", "Kuning terang", "Hijau")),
            Triple("Lengkapilah analogi ini: Baju : Lemari = Mobil : ... ?", "Garasi", listOf("Dapur", "Taman", "Kamar")),
            Triple("Lengkapilah analogi ini: Uang : Dompet = Buku Pelajaran : ... ?", "Tas ransel", listOf("Piring", "Gelas", "Kotak bekal")),
            Triple("Lengkapilah analogi ini: Makanan : Mulut = Suara Cerita : ... ?", "Telinga", listOf("Mata", "Hidung", "Tangan")),
            Triple("Lengkapilah analogi ini: Televisi : Mata dan Telinga = Radio : ... ?", "Telinga saja", listOf("Mata saja", "Hidung", "Lidah")),
            Triple("Lengkapilah analogi ini: Gitar : Dipetik = Drum : ... ?", "Dipukul", listOf("Ditiup", "Digesek", "Ditekan")),
            Triple("Lengkapilah analogi ini: Seruling : Ditiup = Biola : ... ?", "Digesek", listOf("Dipukul", "Dipetik", "Ditekan")),
            Triple("Lengkapilah analogi ini: Piano : Ditekan = Harmonika : ... ?", "Ditiup dan dihisap", listOf("Dipukul", "Dipetik", "Digesek")),
            Triple("Lengkapilah analogi ini: Kuda : Berlari Kencang = Kangguru : ... ?", "Melompat Jauh", listOf("Berenang", "Terbang", "Merayap")),
            Triple("Lengkapilah analogi ini: Hutan : Pohon = Lautan : ... ?", "Air asin", listOf("Padang pasir", "Batu karang saja", "Salju")),
            Triple("Lengkapilah analogi ini: Gurun : Pasir = Kutub : ... ?", "Es dan salju", listOf("Hutan rimba", "Lumpur", "Lahar")),
            Triple("Lengkapilah analogi ini: Senang : Tersenyum = Sedih : ... ?", "Menangis", listOf("Tertawa", "Melompat", "Menyanyi")),
            Triple("Lengkapilah analogi ini: Takut : Gemetar = Marah : ... ?", "Cemberut atau geram", listOf("Tersenyum", "Tertidur", "Lapar")),
            Triple("Lengkapilah analogi ini: Menang : Bersorak = Kalah : ... ?", "Berlapang dada", listOf("Marah-marah", "Menyerah selamanya", "Sombong")),
            Triple("Lengkapilah analogi ini: Belajar : Pintar = Berlatih : ... ?", "Mahir dan terampil", listOf("Lelah saja", "Kalah", "Lupa")),
            Triple("Lengkapilah analogi ini: Merpati : Perdamaian = Garuda : ... ?", "Keagungan bangsa", listOf("Kelambatan", "Kelemahan", "Ketakutan")),
            Triple("Lengkapilah analogi ini: Padi : Kuning Emas = Kapas : ... ?", "Putih Bersih", listOf("Merah Terang", "Hitam", "Biru")),
            Triple("Lengkapilah analogi ini: Roda : Berputar = Bandul Jam : ... ?", "Berayun ke kiri dan kanan", listOf("Diam kaku", "Meleleh", "Menguap")),
            Triple("Lengkapilah analogi ini: Pagi : Terbit = Sore : ... ?", "Terbenam", listOf("Siang", "Menyala", "Malam"))
        )
        for (item in analogies50) {
            val wrongs = item.third.take(3)
            val options = makeOptions(item.second, wrongs[0], wrongs.getOrElse(1) { "LAIN" }, wrongs.getOrElse(2) { "BEDA" }, count = 4)

            questions.add(
                Question(
                    id = "logika_78_$qId",
                    category = QuizCategory.LOGIKA,
                    ageBracket = AgeBracket.AGE_7_8,
                    questionText = item.first,
                    visualEmoji = "⚖️ Hubungan Analogi",
                    options = options,
                    correctIndex = 0,
                    explanation = "Hubungan analogi yang setara dan tepat adalah '${item.second}'.",
                    hint = "Analisis hubungan antara pasangan kata pertama dengan pasangan kata kedua.",
                    difficulty = "Sedang"
                )
            )
            qId++
        } // 100 questions done

        // 3. Sebab Akibat & Deduksi Logika Cilik (50 pertanyaan unik alami)
        val causeEffect50 = listOf(
            Triple("Jika langit siang hari tertutup awan hitam tebal dan petir berbunyi, kemungkinan besar akan terjadi apa?", "Hujan lebat disertai angin", listOf("Panas terik yang menyengat", "Salju tebal turun", "Pelangi di malam hari")),
            Triple("Jika tanaman bunga di dalam pot tidak disiram air selama dua minggu di tempat panas, apa yang terjadi?", "Tanaman akan layu dan mengering", listOf("Tanaman bertambah subur berbunga", "Tanaman berubah warna menjadi biru", "Tanaman menghasilkan buah manis")),
            Triple("Jika sebuah balok es batu diletakkan di piring terbuka di bawah sinar matahari terik, apa yang terjadi?", "Es akan mencair menjadi air", listOf("Es akan membeku semakin keras", "Es akan terbakar mengeluarkan api", "Es berubah menjadi batu")),
            Triple("Jika kita lupa menggosok gigi secara teratur setelah makan makanan manis dan sebelum tidur, apa akibatnya?", "Gigi dapat berlubang dan sakit", listOf("Gigi menjadi semakin putih berkilau", "Gigi bertambah kuat seperti baja", "Napas menjadi sangat harum")),
            Triple("Jika kita menabur garam dapur ke dalam segelas air hangat lalu mengaduknya perlahan, apa yang terjadi?", "Garam akan larut menyatu dengan air", listOf("Garam akan mengapung menjadi batu", "Garam berubah warna menjadi hijau", "Air akan membeku seketika")),
            Triple("Jika kita rajin menyiram dan memberi pupuk pada tanaman hias di taman, apa akibat baiknya?", "Tanaman tumbuh subur dan berbunga indah", listOf("Tanaman cepat membusuk", "Daun tanaman rontok habis", "Akar tanaman mengering")),
            Triple("Jika lampu di kamar tidur dimatikan pada malam hari dan gorden jendela ditutup rapat, ruangan menjadi bagaimana?", "Gelap gulita tanpa cahaya", listOf("Terang benderang seperti siang", "Sangat panas membakar", "Penuh dengan asap tebal")),
            Triple("Jika sebuah bola karet ditiup udara hingga melebihi batas elastisitas karetnya, apa yang akan terjadi?", "Balon karet akan meletus", listOf("Balon akan mencair menjadi air", "Balon berubah bentuk menjadi kotak", "Balon membeku kaku")),
            Triple("Jika kita melempar bola kasti lurus ke atas langit, bola tersebut pada akhirnya akan bergerak ke mana?", "Jatuh kembali ke bawah ke bumi", listOf("Terbang selamanya di angkasa", "Berhenti melayang di awan", "Berubah menjadi burung")),
            Triple("Jika seseorang selalu berkata jujur dalam setiap perkataannya, apa dampak positif bagi dirinya?", "Ia dipercaya dan disayangi banyak orang", listOf("Ia dijauhi oleh kawan-kawannya", "Ia mendapat hukuman dari guru", "Ia merasa takut sepanjang hari")),
            Triple("Jika kita tidur larut malam hingga larut pagi, apa yang kita rasakan saat bangun di pagi hari?", "Badan terasa lelah dan mengantuk di kelas", listOf("Badan terasa sangat segar dan bugar", "Nilai ulangan langsung sempurna", "Tidak perlu sarapan lagi")),
            Triple("Jika air bersih di dalam panci dipanaskan terus-menerus di atas kompor menyala, air akan mengalami apa?", "Mendidih dan menguap menjadi uap air", listOf("Membeku menjadi balok es", "Berubah menjadi minyak goreng", "Mengeras menjadi batu")),
            Triple("Jika kita berolahraga lari keliling lapangan di pagi hari, respons wajar apa yang dikeluarkan tubuh?", "Tubuh mengeluarkan keringat dan napas lebih cepat", listOf("Tubuh membeku kedinginan", "Tubuh tidak membutuhkan air minum", "Mata langsung tertutup rapat")),
            Triple("Jika sakelar lampu dinding ditekan ke posisi ON, apa yang terjadi pada bola lampu kamar?", "Lampu akan menyala terang", listOf("Lampu akan padam gelap", "Lampu akan pecah seketika", "Lampu akan mengeluarkan air")),
            Triple("Jika selembar kertas tisu diletakkan di atas tumpahan air teh di meja, apa yang dilakukan kertas tisu?", "Menyerap air teh hingga meja kering", listOf("Memantulkan air teh ke udara", "Membekukan air teh menjadi es", "Membakar air teh")),
            Triple("Jika minyak goreng dituangkan ke dalam segelas air dingin, apa posisi minyak goreng tersebut?", "Minyak mengapung di lapisan atas air", listOf("Minyak tenggelam di dasar gelas", "Minyak larut sempurna menyatu", "Minyak lenyap menghilang")),
            Triple("Jika batu kerikil padat dijatuhkan ke dalam ember berisi air penuh, apa yang terjadi pada batu?", "Batu langsung tenggelam ke dasar ember", listOf("Batu mengapung melayang di permukaan", "Batu larut seketika seperti gula", "Batu terbang ke udara")),
            Triple("Jika magnet batang didekatkan pada sekumpulan klip kertas dari besi, apa yang akan terjadi?", "Klip kertas besi akan menempel ditarik magnet", listOf("Klip kertas besi akan tertolak menjauh", "Klip kertas besi akan mencair", "Klip kertas besi akan terbakar")),
            Triple("Jika magnet batang didekatkan pada sebuah penghapus karet anak, apa yang terjadi?", "Penghapus karet tidak tertarik oleh magnet", listOf("Penghapus karet menempel sangat erat", "Penghapus karet mengeluarkan percikan api", "Penghapus karet berubah menjadi besi")),
            Triple("Jika kita berjalan di bawah terik matahari siang, di manakah letak bayangan tubuh kita terbentuk?", "Di sisi berlawanan dari posisi matahari", listOf("Tepat di atas kepala kita melayang", "Menghadap langsung ke matahari", "Bayangan tubuh tidak terbentuk")),
            Triple("Jika kita menyalakan lilin di ruangan tertutup tanpa oksigen sama sekali, apa yang terjadi pada nyala lilin?", "Nyala lilin akan padam", listOf("Nyala lilin bertambah besar membubung", "Nyala lilin berubah menjadi es", "Nyala lilin berbunyi nyaring")),
            Triple("Jika kita mencampur cat warna biru dengan cat warna kuning secara merata, warna baru apa yang terbentuk?", "Warna hijau segar", listOf("Warna merah marun", "Warna ungu gelap", "Warna hitam pekat")),
            Triple("Jika kita mencampur cat warna merah dengan cat warna putih, warna lembut apa yang akan dihasilkan?", "Warna merah muda (pink)", listOf("Warna kuning cerah", "Warna abu-abu", "Warna cokelat tua")),
            Triple("Jika dua buah perahu dayung bergerak saling mendekat di sungai sempit, apa yang harus dilakukan pendayung?", "Menepi perlahan agar tidak bertabrakan", listOf("Mendayung semakin kencang lurus", "Melompat ke dalam air", "Menutup mata rapat-rapat")),
            Triple("Jika kamu ingin menyeberang jalan raya yang ramai kendaraan, tindakan cerdas apa yang wajib dilakukan?", "Menyeberang di zebra cross dan menengok kanan-kiri", listOf("Langsung berlari kencang tanpa menoleh", "Bermain bola di tengah jalan raya", "Menyeberang sambil membaca buku")),
            Triple("Jika sebutir telur mentah jatuh dari meja tinggi ke lantai keramik keras, apa yang terjadi?", "Kulit cangkang telur pecah dan isinya tumpah", listOf("Telur memantul tinggi seperti bola", "Telur langsung matang siap disantap", "Lantai keramik berlubang")),
            Triple("Jika kita menaruh sebotol air putih ke dalam freezer kulkas pembeku selama semalam, apa yang terjadi?", "Air putih membeku menjadi es padat", listOf("Air putih menguap habis tak bersisa", "Air putih mendidih mengeluarkan gelembung", "Air putih berubah menjadi sirup manis")),
            Triple("Jika kamu meminjam buku cerita dari perpustakaan sekolah, kewajiban apa yang harus kamu penuhi?", "Menjaga buku tetap rapi dan mengembalikannya tepat waktu", listOf("Menulis nama pribadi dengan spidol di halaman", "Menyimpan buku selamanya di rumah", "Merobek gambar yang bagus")),
            Triple("Jika terjadi antrean panjang di loket wahana bermain, sikap bijak apa yang harus ditunjukkan?", "Tertib mengantre menunggu giliran", listOf("Menerobos barisan ke depan", "Menangis keras di depan loket", "Mendorong teman di depan")),
            Triple("Jika seorang teman terpeleset jatuh di halaman sekolah saat bermain kejar-kejaran, apa yang harus kita lakukan?", "Segera menolongnya berdiri dan membantunya", listOf("Menertawakannya bersama kawan", "Meninggalkannya sendirian", "Pura-pura tidak melihat")),
            Triple("Jika kita merapikan tempat tidur sendiri setiap pagi sehabis bangun tidur, apa manfaat yang dirasakan?", "Kamar menjadi bersih, rapi, dan nyaman ditinggali", listOf("Kamar menjadi berdebu dan kotor", "Tempat tidur cepat rusak", "Tubuh menjadi mudah sakit")),
            Triple("Jika kita membuang sampah sembarangan di saluran selokan air hujan, apa bahaya yang bisa timbul?", "Saluran air tersumbat dan memicu banjir saat hujan", listOf("Air selokan menjadi sangat jernih", "Banyak ikan hias berenang riang", "Lingkungan menjadi sangat wangi")),
            Triple("Jika kita rajin menyikat gigi dua kali sehari pagi dan sebelum tidur, apa manfaat kesehatan yang didapat?", "Gigi menjadi bersih, sehat, dan terhindar dari kuman", listOf("Gigi cepat copot semua", "Gigi berubah warna menjadi hitam", "Gusi sering berdarah")),
            Triple("Jika kita mematikan keran air setelah selesai mencuci tangan, apa manfaat tindakan hemat tersebut?", "Menghemat persediaan air bersih bagi lingkungan", listOf("Air bersih terbuang percuma", "Membayar tagihan air lebih mahal", "Wastafel menjadi cepat rusak")),
            Triple("Jika kita mematikan lampu kamar saat siang hari yang terang, apa keuntungan yang kita peroleh?", "Menghemat penggunaan energi listrik rumah", listOf("Kamar menjadi gelap gulita", "Lampu kamar cepat terbakar", "Tagihan listrik meningkat drastis")),
            Triple("Jika sebuah benda terapung di air ditekan ke bawah lalu dilepaskan, apa yang terjadi pada benda tersebut?", "Benda akan terdorong naik kembali ke permukaan", listOf("Benda akan tenggelam selamanya di dasar", "Benda akan hancur lebur", "Benda akan lenyap seketika")),
            Triple("Jika kita menaruh kelereng kaca di atas papan miring yang licin, kelereng akan bergerak bagaimana?", "Kelereng menggelinding cepat ke arah bawah", listOf("Kelereng menggelinding naik ke atas", "Kelereng melayang ke udara", "Kelereng berhenti kaku")),
            Triple("Jika kita menabur remah-remah roti manis di dekat lubang semut, apa yang akan segera terjadi?", "Semut-semut akan bergotong royong mengangkut remah roti", listOf("Semut-semut akan lari ketakutan", "Remah roti berubah menjadi batu", "Semut-semut mengubur dirinya")),
            Triple("Jika kita bertepuk tangan di dekat burung liar yang sedang hinggap di tanah, apa reaksi burung tersebut?", "Burung akan terkejut lalu terbang menjauh", listOf("Burung akan tidur nyenyak", "Burung akan bertepuk tangan juga", "Burung berubah warna")),
            Triple("Jika kita meneteskan air jeruk nipis asam ke lidah, ekspresi wajar apa yang biasanya tampak di wajah?", "Mata memejam dan mulut mengkerut karena rasa asam", listOf("Tersenyum lebar tertidur pulas", "Wajah pucat ketakutan", "Menguap karena lapar")),
            Triple("Jika suatu wadah baskom dipenuhi air hingga tumpah, apa tanda yang dapat kita amati?", "Air mengalir meluber keluar melewati tepi baskom", listOf("Air menyusut ke dasar baskom", "Baskom menjadi melayang", "Air membeku seketika")),
            Triple("Jika sebuah mobil kehabisan bahan bakar bensin saat melaju di jalan datar, apa yang terjadi pada mobil?", "Mobil akan melambat bertahap hingga berhenti total", listOf("Mobil melaju semakin kencang terbang", "Mobil langsung berputar ke belakang", "Mobil melompat tinggi")),
            Triple("Jika kamu ingin tahu berapa berat badanmu, alat ukur apa yang tepat kamu gunakan?", "Timbangan badan digital atau jarum", listOf("Penggaris kayu panjang", "Termometer suhu tubuh", "Gelas ukur air")),
            Triple("Jika kamu ingin mengetahui apakah badanmu sedang demam tinggi atau tidak, alat apa yang digunakan dokter?", "Termometer pengukur suhu tubuh", listOf("Stetoskop dada", "Timbangan berat badan", "Meteran pita kain")),
            Triple("Jika kamu ingin melihat benda-benda renik kuman yang sangat kecil sekali, alat sains apa yang dibutuhkan?", "Mikroskop pembesar optik", listOf("Teropong bintang malam", "Kacamata renang", "Kaca spion mobil")),
            Triple("Jika kamu ingin mengamati kawah bulan dan bintang-bintang di langit malam secara jelas, gunakan apa?", "Teleskop bintang astronomi", listOf("Mikroskop laboratorium", "Kamera saku biasa", "Lup pembesar tangan")),
            Triple("Jika sebuah lilin dinyalakan di dalam toples kaca lalu toples ditutup rapat dengan tutup kedap udara, apa yang terjadi?", "Api lilin padam perlahan karena kehabisan oksigen", listOf("Api lilin menyala semakin besar membubung", "Lilin meledak menghancurkan toples", "Lilin membeku menjadi batu es")),
            Triple("Jika sebuah spons mandi kering dicelupkan ke dalam mangkuk berisi air penuh, apa yang terjadi pada spons?", "Spons menyerap air dan menjadi berat basah", listOf("Spons mengapung kering tanpa air", "Spons mencair dan hilang", "Air mangkuk terbakar")),
            Triple("Jika dua orang anak yang berat badannya sama bermain jungkat-jungkit di jarak yang sama dari titik tumpu, apa yang terjadi?", "Papan jungkat-jungkit berada dalam posisi seimbang datar", listOf("Salah satu anak terlempar ke udara", "Papan jungkat-jungkit miring tajam ke satu sisi", "Papan jungkat-jungkit patah")),
            Triple("Jika kita menanam biji kacang hijau di atas kapas basah yang terkena sinar matahari, apa yang terjadi setelah beberapa hari?", "Biji akan berkecambah mengeluarkan akar dan tunas hijau", listOf("Biji kacang hijau berubah menjadi butir pasir", "Biji kacang hijau lenyap tanpa bekas", "Kapas basah berubah menjadi batu"))
        )
        for (item in causeEffect50) {
            val wrongs = item.third.take(3)
            val options = makeOptions(item.second, wrongs[0], wrongs.getOrElse(1) { "LAIN" }, wrongs.getOrElse(2) { "BEDA" }, count = 4)

            questions.add(
                Question(
                    id = "logika_78_$qId",
                    category = QuizCategory.LOGIKA,
                    ageBracket = AgeBracket.AGE_7_8,
                    questionText = item.first,
                    visualEmoji = "💡 Sebab Akibat",
                    options = options,
                    correctIndex = 0,
                    explanation = "Jawaban yang logis dan sesuai hukum sebab akibat adalah '${item.second}'.",
                    hint = "Pikirkan apa yang terjadi sebagai dampak alami dari peristiwa tersebut.",
                    difficulty = "Sedang"
                )
            )
            qId++
        } // Exactly 150 questions for Age 7-8!

        return questions
    }

    // =========================================================================
    // USIA 9-10 TAHUN (150 PERTANYAAN LOGIKA ALAMI)
    // =========================================================================
    private fun generateAge910(): List<Question> {
        val questions = ArrayList<Question>(150)
        var qId = 1

        // 1. Deret Angka Matematika & Pola Tingkat Lanjut (50 pola unik berbeda)
        val mathPatterns50 = listOf(
            Triple("Perhatikan barisan bilangan geometri: 2, 4, 8, 16, 32, ... bilangan berikutnya adalah?", "64", listOf("48", "56", "60")),
            Triple("Perhatikan barisan bilangan kelipatan tiga: 3, 6, 12, 24, 48, ... bilangan berikutnya adalah?", "96", listOf("72", "84", "90")),
            Triple("Perhatikan barisan bilangan Fibonacci: 1, 1, 2, 3, 5, 8, 13, ... bilangan berikutnya adalah?", "21", listOf("18", "19", "20")),
            Triple("Perhatikan barisan bilangan Fibonacci lanjutan: 2, 3, 5, 8, 13, 21, ... bilangan berikutnya adalah?", "34", listOf("29", "31", "33")),
            Triple("Perhatikan barisan bilangan kuadrat: 1, 4, 9, 16, 25, 36, ... bilangan berikutnya adalah?", "49", listOf("42", "45", "48")),
            Triple("Perhatikan barisan bilangan kuadrat lanjutan: 16, 25, 36, 49, 64, ... bilangan berikutnya adalah?", "81", listOf("72", "75", "100")),
            Triple("Perhatikan barisan bilangan bertingkat: 2, 5, 10, 17, 26 (+3, +5, +7, +9), ... bilangan berikutnya adalah?", "37 (+11)", listOf("35", "36", "38")),
            Triple("Perhatikan barisan bilangan pangkat tiga (kubik): 1, 8, 27, 64, ... bilangan berikutnya adalah?", "125", listOf("100", "110", "120")),
            Triple("Perhatikan barisan bilangan pengurangan bertingkat: 100, 95, 85, 70, 50 (-5, -10, -15, -20), ... angka berikutnya adalah?", "25 (-25)", listOf("30", "35", "20")),
            Triple("Perhatikan barisan bilangan selang-seling operasi (+2, -1): 5, 7, 6, 8, 7, 9, 8, ... angka berikutnya adalah?", "10", listOf("9", "11", "7")),
            Triple("Perhatikan barisan bilangan berselang kali dua dan kurang satu: 2, 4, 3, 6, 5, 10, ... angka berikutnya adalah?", "9", listOf("8", "11", "12")),
            Triple("Perhatikan barisan bilangan lompat 15: 15, 30, 45, 60, 75, ... bilangan berikutnya adalah?", "90", listOf("80", "85", "105")),
            Triple("Perhatikan barisan bilangan lompat 25: 25, 50, 75, 100, 125, ... bilangan berikutnya adalah?", "150", listOf("135", "140", "175")),
            Triple("Perhatikan barisan bilangan lompat 50: 50, 100, 150, 200, 250, ... bilangan berikutnya adalah?", "300", listOf("275", "350", "400")),
            Triple("Perhatikan barisan bilangan lompat 12: 12, 24, 36, 48, 60, ... bilangan berikutnya adalah?", "72", listOf("68", "70", "84")),
            Triple("Perhatikan deret bilangan prima dasar: 2, 3, 5, 7, 11, 13, 17, ... bilangan prima berikutnya adalah?", "19", listOf("18", "21", "23")),
            Triple("Perhatikan deret bilangan prima lanjutan: 11, 13, 17, 19, 23, ... bilangan prima berikutnya adalah?", "29", listOf("25", "27", "31")),
            Triple("Perhatikan deret bilangan kelipatan sembilan: 9, 18, 27, 36, 45, ... bilangan berikutnya adalah?", "54", listOf("50", "52", "63")),
            Triple("Perhatikan deret pengurangan 13: 100, 87, 74, 61, 48, ... bilangan berikutnya adalah?", "35", listOf("32", "34", "38")),
            Triple("Perhatikan deret pembagian dua: 128, 64, 32, 16, 8, ... bilangan berikutnya adalah?", "4", listOf("2", "6", "1")),
            Triple("Perhatikan deret pembagian empat: 256, 64, 16, ... bilangan berikutnya adalah?", "4", listOf("2", "8", "1")),
            Triple("Perhatikan deret selang-seling (+3, +5, +3, +5): 2, 5, 10, 13, 18, 21, ... bilangan berikutnya adalah?", "26", listOf("24", "25", "27")),
            Triple("Perhatikan deret bertingkat (+2, +4, +6, +8): 1, 3, 7, 13, 21, ... bilangan berikutnya adalah?", "31 (+10)", listOf("29", "30", "33")),
            Triple("Perhatikan deret bilangan: 4, 9, 16, 25, 36, 49, ... bilangan berikutnya adalah?", "64", listOf("56", "60", "81")),
            Triple("Perhatikan deret segitiga bilangan: 1, 3, 6, 10, 15, 21, ... bilangan berikutnya adalah?", "28", listOf("25", "26", "27")),
            Triple("Perhatikan deret pecahan desimal: 0.125, 0.25, 0.5, 1, 2, ... bilangan berikutnya adalah?", "4", listOf("3", "2.5", "5")),
            Triple("Perhatikan deret persentase: 10%, 20%, 40%, 80%, ... persentase berikutnya adalah?", "160%", listOf("100%", "120%", "150%")),
            Triple("Perhatikan deret angka romawi: I, V, X, L, ... angka romawi ratusan berikutnya adalah?", "C (100)", listOf("D", "M", "V")),
            Triple("Perhatikan deret angka romawi besar: X, L, C, D, ... angka romawi ribuan berikutnya adalah?", "M (1000)", listOf("C", "K", "Z")),
            Triple("Perhatikan deret hitung mundur: 500, 425, 350, 275, ... bilangan berikutnya adalah?", "200 (-75)", listOf("175", "225", "250")),
            Triple("Perhatikan deret dua pola terjalin (posisi ganjil +2, posisi genap +10): 2, 10, 4, 20, 6, 30, ... angka berikutnya adalah?", "8", listOf("40", "10", "32")),
            Triple("Perhatikan deret dua pola terjalin lanjutan: 1, 100, 2, 90, 3, 80, 4, ... angka berikutnya adalah?", "70", listOf("5", "60", "75")),
            Triple("Perhatikan deret bilangan kubik: 8, 27, 64, 125, ... bilangan berikutnya adalah?", "216 (6³)", listOf("180", "200", "240")),
            Triple("Perhatikan deret bilangan: 1, 5, 14, 30, 55 (jumlah kuadrat), ... bilangan berikutnya adalah?", "91 (+36)", listOf("80", "85", "95")),
            Triple("Perhatikan deret bilangan negatif: -15, -12, -9, -6, ... bilangan berikutnya adalah?", "-3", listOf("-2", "-1", "0")),
            Triple("Perhatikan deret bilangan negatif menuju positif: -6, -4, -2, 0, ... bilangan berikutnya adalah?", "2", listOf("1", "3", "4")),
            Triple("Perhatikan deret pengurangan bertahap (-1, -2, -3, -4): 30, 29, 27, 24, 20, ... bilangan berikutnya adalah?", "15 (-5)", listOf("16", "17", "14")),
            Triple("Perhatikan deret perkalian berselang: 1, 2, 6, 24, 120 (faktorial), ... bilangan berikutnya adalah?", "720 (×6)", listOf("240", "600", "500")),
            Triple("Perhatikan deret bilangan kelipatan 16: 16, 32, 48, 64, 80, ... bilangan berikutnya adalah?", "96", listOf("90", "92", "100")),
            Triple("Perhatikan deret bilangan kelipatan 24: 24, 48, 72, 96, ... bilangan berikutnya adalah?", "120", listOf("110", "116", "124")),
            Triple("Perhatikan deret bilangan kelipatan 18: 18, 36, 54, 72, 90, ... bilangan berikutnya adalah?", "108", listOf("98", "100", "112")),
            Triple("Perhatikan deret bilangan: 3, 7, 15, 31, 63 (×2 + 1), ... bilangan berikutnya adalah?", "127", listOf("120", "125", "130")),
            Triple("Perhatikan deret bilangan: 2, 5, 11, 23, 47 (×2 + 1), ... bilangan berikutnya adalah?", "95", listOf("90", "92", "94")),
            Triple("Perhatikan deret bilangan selang-seling (+4, -2): 10, 14, 12, 16, 14, 18, ... bilangan berikutnya adalah?", "16", listOf("20", "22", "15")),
            Triple("Perhatikan deret bilangan desimal (+0.25): 0.5, 0.75, 1.0, 1.25, 1.5, ... bilangan berikutnya adalah?", "1.75", listOf("1.6", "2.0", "2.25")),
            Triple("Perhatikan deret pecahan: 1/2, 2/3, 3/4, 4/5, ... pecahan berikutnya adalah?", "5/6", listOf("5/5", "6/7", "4/6")),
            Triple("Perhatikan deret pecahan pangkat dua: 1/2, 1/4, 1/8, 1/16, ... pecahan berikutnya adalah?", "1/32", listOf("1/24", "1/64", "1/20")),
            Triple("Perhatikan deret kelipatan 14: 14, 28, 42, 56, 70, ... bilangan berikutnya adalah?", "84", listOf("78", "80", "88")),
            Triple("Perhatikan deret pembagian 5: 625, 125, 25, ... bilangan berikutnya adalah?", "5", listOf("1", "10", "15")),
            Triple("Perhatikan deret kelipatan 30: 30, 60, 90, 120, 150, ... bilangan berikutnya adalah?", "180", listOf("160", "170", "200"))
        )
        for (item in mathPatterns50) {
            val wrongs = item.third.take(3)
            val options = makeOptions(item.second, wrongs[0], wrongs.getOrElse(1) { "LAIN" }, wrongs.getOrElse(2) { "BEDA" }, count = 4)

            questions.add(
                Question(
                    id = "logika_910_$qId",
                    category = QuizCategory.LOGIKA,
                    ageBracket = AgeBracket.AGE_9_10,
                    questionText = item.first,
                    visualEmoji = "🔢 Deret Logis",
                    options = options,
                    correctIndex = 0,
                    explanation = "Jawaban yang benar menurut rumus deret adalah '${item.second}'.",
                    hint = "Analisis pola pertambahan, perkalian, atau keteraturan deret.",
                    difficulty = "Tantangan"
                )
            )
            qId++
        } // 50 questions done

        // 2. Silogisme & Logika Deduktif Formal (50 pertanyaan deduksi unik)
        val syllogisms50 = listOf(
            Triple("Premis 1: Semua mamalia bernapas dengan paru-paru. Premis 2: Paus adalah mamalia laut. Kesimpulannya adalah?", "Paus bernapas dengan paru-paru", listOf("Paus bernapas dengan insang", "Paus tidak memerlukan udara", "Semua ikan adalah mamalia")),
            Triple("Premis 1: Semua burung memiliki sayap dan berparuh. Premis 2: Elang adalah jenis burung. Kesimpulannya adalah?", "Elang memiliki sayap dan berparuh", listOf("Elang tidak memiliki paruh", "Semua yang bersayap adalah elang", "Elang adalah mamalia")),
            Triple("Premis 1: Semua tumbuhan hijau berfotosintesis dengan klorofil. Premis 2: Pohon beringin adalah tumbuhan hijau. Kesimpulannya adalah?", "Pohon beringin berfotosintesis dengan klorofil", listOf("Pohon beringin tidak membutuhkan cahaya", "Semua tumbuhan adalah pohon beringin", "Pohon beringin bernapas dengan insang")),
            Triple("Premis 1: Semua bilangan genap habis dibagi dua. Premis 2: Bilangan 48 adalah bilangan genap. Kesimpulannya adalah?", "Bilangan 48 habis dibagi dua", listOf("Bilangan 48 tidak habis dibagi dua", "Bilangan 48 adalah bilangan ganjil", "Semua bilangan adalah 48")),
            Triple("Premis 1: Semua sudut pada segitiga sama sisi besarnya sama. Premis 2: Segitiga ABC adalah segitiga sama sisi. Kesimpulannya adalah?", "Semua sudut pada segitiga ABC sama besar (60°)", listOf("Sudut-sudut segitiga ABC berbeda", "Segitiga ABC memiliki 4 sudut", "Segitiga ABC sudutnya siku-siku")),
            Triple("Premis 1: Semua benda yang ditarik kuat oleh magnet terbuat dari bahan feromagnetik seperti besi. Premis 2: Paku payung ditarik kuat oleh magnet. Kesimpulannya adalah?", "Paku payung terbuat dari bahan feromagnetik / besi", listOf("Paku payung terbuat dari kayu", "Magnet tidak memiliki gaya tarik", "Semua besi berbentuk paku payung")),
            Triple("Premis 1: Jika air dipanaskan hingga 100°C pada tekanan normal, air akan mendidih. Premis 2: Air di ketel mencapai suhu 100°C. Kesimpulannya adalah?", "Air di ketel tersebut mendidih", listOf("Air di ketel membeku menjadi es", "Air di ketel tidak berubah", "Suhu air turun")),
            Triple("Premis 1: Semua hewan karnivora memakan daging. Premis 2: Harimau adalah hewan karnivora. Kesimpulannya adalah?", "Harimau memakan daging", listOf("Harimau hanya memakan buah", "Semua pemakan daging adalah harimau", "Harimau hewan pemakan rumput")),
            Triple("Premis 1: Semua hewan herbivora memakan tumbuhan. Premis 2: Kelinci adalah hewan herbivora. Kesimpulannya adalah?", "Kelinci memakan bahan tumbuhan", listOf("Kelinci memakan daging ikan", "Kelinci adalah karnivora", "Semua pemakan rumput adalah kelinci")),
            Triple("Premis 1: Semua reptil berkembang biak dengan bertelur (ovipar) atau ovovivipar dan berdarah dingin. Premis 2: Buaya adalah reptil. Kesimpulannya adalah?", "Buaya berdarah dingin dan bertelur", listOf("Buaya berdarah panas seperti burung", "Buaya menyusui anaknya", "Semua hewan bertelur adalah buaya")),
            Triple("Premis 1: Semua warga negara yang mematuhi hukum berdisiplin tinggi. Premis 2: Siswa yang menyeberang di zebra cross mematuhi hukum. Kesimpulannya adalah?", "Siswa tersebut berdisiplin tinggi", listOf("Siswa tersebut melanggar hukum", "Semua pejalan kaki adalah siswa", "Zebra cross hanya untuk mobil")),
            Triple("Premis 1: Jika hari libur nasional, sekolah tidak menyelenggarakan kegiatan belajar di kelas. Premis 2: Hari ini adalah tanggal merah hari libur nasional. Kesimpulannya adalah?", "Sekolah tidak menyelenggarakan kegiatan belajar di kelas hari ini", listOf("Murid wajib hadir upacara di sekolah", "Hari ini bukan tanggal merah", "Semua hari adalah libur nasional")),
            Triple("Premis 1: Logam menghantarkan panas dan listrik dengan baik (konduktor). Premis 2: Tembaga adalah jenis logam. Kesimpulannya adalah?", "Tembaga menghantarkan panas dan listrik dengan baik", listOf("Tembaga adalah isolator panas", "Tembaga tidak dapat dialiri listrik", "Semua konduktor adalah tembaga")),
            Triple("Premis 1: Karet dan kayu kering tidak dapat menghantarkan arus listrik (isolator). Premis 2: Gagang obeng terbuat dari karet tebal. Kesimpulannya adalah?", "Gagang obeng merupakan isolator listrik yang aman", listOf("Gagang obeng dapat menghantarkan arus listrik", "Gagang obeng mudah dialiri listrik", "Karet adalah logam")),
            Triple("Premis 1: Setiap planet di tata surya mengorbit mengelilingi matahari. Premis 2: Bumi adalah salah satu planet di tata surya. Kesimpulannya adalah?", "Bumi mengorbit mengelilingi matahari", listOf("Matahari mengorbit mengelilingi bumi", "Bumi tidak bergerak sama sekali", "Bumi adalah pusat tata surya")),
            Triple("Premis 1: Semua segitiga memiliki tiga sisi dan tiga sudut. Premis 2: Bangun datar P adalah sebuah segitiga. Kesimpulannya adalah?", "Bangun datar P memiliki tiga sisi dan tiga sudut", listOf("Bangun P memiliki empat sisi", "Bangun P tidak memiliki sudut", "Bangun P berbentuk bundar")),
            Triple("Premis 1: Semua persegi memiliki empat sisi yang sama panjang dan empat sudut siku-siku. Premis 2: Bangun Q adalah sebuah persegi. Kesimpulannya adalah?", "Bangun Q memiliki empat sisi sama panjang dan empat sudut siku-siku", listOf("Sisi bangun Q tidak sama panjang", "Sudut bangun Q besarnya lancip", "Bangun Q memiliki tiga sisi")),
            Triple("Premis 1: Jika bilangan berakhiran angka 0 atau 5, maka bilangan tersebut habis dibagi 5. Premis 2: Bilangan 135 berakhiran angka 5. Kesimpulannya adalah?", "Bilangan 135 habis dibagi 5", listOf("Bilangan 135 tidak habis dibagi 5", "Bilangan 135 habis dibagi 10", "Semua angka berakhiran 5 adalah genap")),
            Triple("Premis 1: Setiap kelipatan 10 selalu berakhiran angka 0. Premis 2: Angka 270 adalah kelipatan 10. Kesimpulannya adalah?", "Angka 270 berakhiran angka 0", listOf("Angka 270 berakhiran angka 5", "Angka 270 bilangan ganjil", "Angka 270 tidak habis dibagi 10")),
            Triple("Premis 1: Semua primata memiliki ibu jari yang berlawanan arah dengan jari lainnya (opposing thumb). Premis 2: Orangutan adalah primata. Kesimpulannya adalah?", "Orangutan memiliki ibu jari opposing thumb", listOf("Orangutan tidak memiliki jari tangan", "Orangutan adalah hewan melata", "Semua hewan adalah primata")),
            Triple("Premis 1: Jika Doni bangun lebih pagi dari Budi, dan Budi bangun lebih pagi dari Candra. Siapakah yang bangun paling pagi?", "Doni", listOf("Budi", "Candra", "Keduanya sama")),
            Triple("Premis 1: Rumah Andi lebih tinggi dari rumah Bayu. Rumah Bayu lebih tinggi dari rumah Citra. Rumah siapakah yang paling rendah?", "Rumah Citra", listOf("Rumah Andi", "Rumah Bayu", "Semua sama")),
            Triple("Premis 1: Pohon mangga lebih tinggi dari pohon jeruk. Pohon kelapa lebih tinggi dari pohon mangga. Pohon manakah yang paling tinggi?", "Pohon kelapa", listOf("Pohon mangga", "Pohon jeruk", "Pohon pisang")),
            Triple("Premis 1: Tas Rina lebih berat dari tas Sinta. Tas Tiara lebih berat dari tas Rina. Tas siapakah yang paling berat di antara ketiganya?", "Tas Tiara", listOf("Tas Rina", "Tas Sinta", "Semua sama")),
            Triple("Premis 1: Nilai Matematika Kevin lebih tinggi dari nilai Fajar. Nilai Fajar lebih tinggi dari nilai Galih. Siapakah yang nilainya tertinggi?", "Kevin", listOf("Fajar", "Galih", "Semua sama")),
            Triple("Premis 1: Kota A terletak di sebelah barat kota B. Kota B terletak di sebelah barat kota C. Kota manakah yang berada paling barat?", "Kota A", listOf("Kota B", "Kota C", "Kota D")),
            Triple("Premis 1: Mobil merah melaju lebih cepat dari mobil biru. Mobil biru melaju lebih cepat dari mobil hijau. Mobil manakah yang paling lambat?", "Mobil hijau", listOf("Mobil merah", "Mobil biru", "Semua sama cepat")),
            Triple("Premis 1: Tali A lebih panjang dari tali B. Tali B lebih panjang dari tali C. Tali manakah yang paling pendek?", "Tali C", listOf("Tali A", "Tali B", "Semua sama panjang")),
            Triple("Premis 1: Kakek lebih tua dari Ayah. Ayah lebih tua dari Paman. Siapakah yang usianya paling tua?", "Kakek", listOf("Ayah", "Paman", "Semua sama")),
            Triple("Premis 1: Kotak X memuat lebih banyak buku dari kotak Y. Kotak Y memuat lebih banyak buku dari kotak Z. Kotak mana yang memuat paling sedikit?", "Kotak Z", listOf("Kotak X", "Kotak Y", "Semua sama")),
            Triple("Premis 1: Jika X > Y dan Y > Z, maka hubungan perbandingan yang pasti benar antara X dan Z adalah?", "X > Z", listOf("X < Z", "X = Z", "X + Z = 0")),
            Triple("Premis 1: Jika P = Q dan Q = R, maka hubungan antara P dan R adalah?", "P = R", listOf("P > R", "P < R", "P + R = 0")),
            Triple("Premis 1: Jika A + B = 10 dan A = 4, berapakah nilai dari B?", "6", listOf("4", "5", "14")),
            Triple("Premis 1: Jika 3 × M = 27, berapakah nilai dari M?", "9", listOf("7", "8", "10")),
            Triple("Premis 1: Jika K dibagi 4 menghasilkan nilai 8, berapakah nilai K?", "32", listOf("12", "16", "24")),
            Triple("Premis 1: Jika umur Kakak dua kali umur Adik, dan umur Adik 6 tahun, berapa umur Kakak?", "12 tahun", listOf("8 tahun", "10 tahun", "14 tahun")),
            Triple("Premis 1: Jika luas persegi panjang adalah Panjang × Lebar, dan Panjang = 8 cm, Lebar = 5 cm, berapa luasnya?", "40 cm²", listOf("13 cm²", "26 cm²", "35 cm²")),
            Triple("Premis 1: Jika keliling segitiga sama sisi adalah 3 × sisi, dan kelilingnya 24 cm, berapa panjang sisinya?", "8 cm", listOf("6 cm", "7 cm", "9 cm")),
            Triple("Premis 1: Hari ini bukan hari libur. Hari kerja adalah Senin sampai Jumat. Jika hari ini bukan Senin, Selasa, Kamis, atau Jumat, hari apakah ini?", "Hari Rabu", listOf("Hari Sabtu", "Hari Minggu", "Hari Libur")),
            Triple("Premis 1: Dalam sebuah lomba lari, Ali berada di depan Budi. Budi berada di depan Ciko. Siapakah yang menempati posisi paling depan?", "Ali", listOf("Budi", "Ciko", "Semua seri")),
            Triple("Premis 1: Semua unggas berbulu dan bertelur. Bebek adalah unggas air. Kesimpulan yang benar adalah?", "Bebek berbulu dan bertelur", listOf("Bebek menyusui anaknya", "Bebek berdarah dingin", "Semua unggas adalah bebek")),
            Triple("Premis 1: Tidak ada mamalia yang bernapas dengan insang. Lumba-lumba adalah mamalia. Kesimpulan yang tepat adalah?", "Lumba-lumba tidak bernapas dengan insang", listOf("Lumba-lumba bernapas dengan insang", "Lumba-lumba adalah ikan murni", "Semua hewan laut adalah mamalia")),
            Triple("Premis 1: Semua anak yang rajin membaca wawasannya luas. Dina adalah anak yang rajin membaca. Kesimpulannya adalah?", "Dina memiliki wawasan yang luas", listOf("Dina malas membaca", "Semua anak adalah Dina", "Wawasan luas hanya milik Dina")),
            Triple("Premis 1: Setiap segitiga siku-siku memiliki tepat satu sudut 90°. Segitiga KLM adalah segitiga siku-siku. Kesimpulannya adalah?", "Segitiga KLM memiliki tepat satu sudut 90°", listOf("Semua sudut segitiga KLM 90°", "Segitiga KLM tidak bersudut siku-siku", "Segitiga KLM adalah segitiga sama sisi")),
            Triple("Premis 1: Bahan isolator mencegah aliran listrik. Plastik pembungkus kabel adalah bahan isolator. Kesimpulannya adalah?", "Plastik pembungkus kabel mencegah aliran listrik", listOf("Plastik pembungkus kabel menghantarkan listrik", "Kabel tidak membutuhkan pembungkus", "Semua isolator adalah kabel")),
            Triple("Premis 1: Jika suhu udara turun di bawah 0°C di permukaan bumi, air murni akan membeku. Suhu tercatat -3°C. Kesimpulannya adalah?", "Air murni akan membeku menjadi es", listOf("Air murni akan mendidih", "Suhu udara sangat panas", "Air murni menguap seketika")),
            Triple("Premis 1: Semua hewan amfibi hidup di dua alam (air dan darat) selama siklus hidupnya. Katak adalah amfibi. Kesimpulannya?", "Katak hidup di dua alam (air dan darat)", listOf("Katak hanya hidup di udara", "Katak tidak pernah menyentuh air", "Semua hewan adalah katak")),
            Triple("Premis 1: Semua tumbuhan paku berkembang biak dengan spora. Suplir adalah jenis tumbuhan paku. Kesimpulannya adalah?", "Suplir berkembang biak dengan spora", listOf("Suplir berkembang biak dengan biji bunga", "Suplir adalah hewan amfibi", "Suplir tidak memiliki daun")),
            Triple("Premis 1: Jika dua kutub magnet senama didekatkan, keduanya akan saling tolak-menolak. Kutub Utara didekatkan ke Kutub Utara. Kesimpulannya?", "Kedua kutub magnet akan saling tolak-menolak", listOf("Kedua kutub akan saling tarik-menarik", "Kedua magnet akan melebur", "Gaya magnet menghilang")),
            Triple("Premis 1: Jika dua kutub magnet berlainan nama didekatkan, keduanya saling tarik-menarik. Kutub Utara didekatkan ke Kutub Selatan. Kesimpulannya?", "Kedua kutub magnet akan saling tarik-menarik", listOf("Kedua kutub magnet tolak-menolak", "Magnet kehilangan daya tariknya", "Kedua kutub membeku"))
        )
        for (item in syllogisms50) {
            val wrongs = item.third.take(3)
            val options = makeOptions(item.second, wrongs[0], wrongs.getOrElse(1) { "LAIN" }, wrongs.getOrElse(2) { "BEDA" }, count = 4)

            questions.add(
                Question(
                    id = "logika_910_$qId",
                    category = QuizCategory.LOGIKA,
                    ageBracket = AgeBracket.AGE_9_10,
                    questionText = item.first,
                    visualEmoji = "🧠 Penalaran Deduktif",
                    options = options,
                    correctIndex = 0,
                    explanation = "Berdasarkan prinsip silogisme deduktif, kesimpulan yang valid adalah '${item.second}'.",
                    hint = "Hubungkan premis umum dengan premis khusus secara logis.",
                    difficulty = "Tantangan"
                )
            )
            qId++
        } // 100 questions done

        // 3. Spasial, Sudut, Geometri & Teka-Teki Logis Cilik (50 pertanyaan unik)
        val spatialGeom50 = listOf(
            Triple("Berapa besar sudut siku-siku yang dibentuk oleh dua garis lurus yang saling berpotongan tegak lurus?", "90°", listOf("45°", "60°", "180°")),
            Triple("Berapakah jumlah derajat sudut lurus penuh pada sebuah garis lurus?", "180°", listOf("90°", "270°", "360°")),
            Triple("Berapa jumlah total sudut dalam pada semua jenis bangun segitiga datar?", "180°", listOf("90°", "270°", "360°")),
            Triple("Berapa jumlah total sudut dalam pada semua bangun segi empat datar (seperti persegi atau persegi panjang)?", "360°", listOf("180°", "270°", "400°")),
            Triple("Sebuah bangun kubus memiliki berapa banyak bidang sisi datar yang berbentuk persegi sama luas?", "6 sisi", listOf("4 sisi", "8 sisi", "12 sisi")),
            Triple("Sebuah bangun kubus memiliki berapa banyak rusuk garis tepi yang sama panjang?", "12 rusuk", listOf("6 rusuk", "8 rusuk", "10 rusuk")),
            Triple("Sebuah bangun kubus memiliki berapa banyak titik sudut pertemuan rusuk-rusuknya?", "8 titik sudut", listOf("6 titik sudut", "10 titik sudut", "12 titik sudut")),
            Triple("Sebuah bangun balok memiliki berapa banyak bidang sisi datar penutup ruangnya?", "6 sisi", listOf("4 sisi", "8 sisi", "12 sisi")),
            Triple("Sebuah limas dengan alas berbentuk segi empat memiliki berapa banyak bidang sisi seluruhnya?", "5 sisi (1 alas + 4 tegak)", listOf("4 sisi", "6 sisi", "8 sisi")),
            Triple("Sebuah prisma dengan alas segitiga memiliki berapa banyak bidang sisi seluruhnya?", "5 sisi (2 alas/tutup + 3 tegak)", listOf("4 sisi", "6 sisi", "8 sisi")),
            Triple("Bangun ruang tabung memiliki berapa banyak bidang sisi (alas, tutup, dan selimut melingkar)?", "3 sisi", listOf("2 sisi", "4 sisi", "5 sisi")),
            Triple("Bangun ruang kerucut memiliki berapa banyak bidang sisi (alas lingkaran dan selimut kerucut)?", "2 sisi", listOf("1 sisi", "3 sisi", "4 sisi")),
            Triple("Bangun ruang bola memiliki berapa banyak bidang sisi lengkung penutupnya?", "1 sisi lengkung", listOf("2 sisi", "3 sisi", "4 sisi")),
            Triple("Berapakah jumlah simetri lipat yang dimiliki oleh bangun persegi empat sama sisi?", "4 simetri lipat", listOf("2 simetri lipat", "3 simetri lipat", "8 simetri lipat")),
            Triple("Berapakah jumlah simetri lipat yang dimiliki oleh bangun persegi panjang biasa?", "2 simetri lipat", listOf("1 simetri lipat", "3 simetri lipat", "4 simetri lipat")),
            Triple("Berapakah jumlah simetri lipat yang dimiliki oleh bangun segitiga sama sisi?", "3 simetri lipat", listOf("1 simetri lipat", "2 simetri lipat", "4 simetri lipat")),
            Triple("Berapakah jumlah simetri lipat yang dimiliki oleh bangun segitiga sama kaki?", "1 simetri lipat", listOf("2 simetri lipat", "3 simetri lipat", "0 simetri lipat")),
            Triple("Berapakah jumlah simetri lipat yang dimiliki oleh bangun lingkaran bulat sempurna?", "Tak terhingga banyaknya", listOf("4 simetri lipat", "8 simetri lipat", "360 simetri lipat")),
            Triple("Sebuah jaring-jaring kubus terdiri dari berapa banyak persegi yang saling terhubung tepat?", "6 persegi", listOf("4 persegi", "5 persegi", "8 persegi")),
            Triple("Jika jarum jam menunjukkan tepat pukul 03.00, berapakah besar sudut terkecil yang terbentuk?", "90° (Sudut siku-siku)", listOf("45°", "60°", "120°")),
            Triple("Jika jarum jam menunjukkan tepat pukul 06.00, berapakah sudut lurus yang terbentuk oleh kedua jarum jam?", "180° (Sudut lurus)", listOf("90°", "120°", "270°")),
            Triple("Jika jarum jam menunjukkan tepat pukul 01.00, berapakah besar sudut terkecil antara jarum pendek dan jarum panjang?", "30°", listOf("15°", "45°", "60°")),
            Triple("Jika jarum jam menunjukkan tepat pukul 02.00, berapakah besar sudut terkecil antara kedua jarum jam?", "60°", listOf("45°", "75°", "90°")),
            Triple("Jika jarum jam menunjukkan tepat pukul 04.00, berapakah besar sudut terkecil antara kedua jarum jam?", "120°", listOf("90°", "100°", "150°")),
            Triple("Jika jarum jam menunjukkan tepat pukul 05.00, berapakah besar sudut terkecil antara kedua jarum jam?", "150°", listOf("120°", "135°", "160°")),
            Triple("Sudut yang besarnya kurang dari 90° dalam klasifikasi matematika disebut sebagai sudut apa?", "Sudut lancip", listOf("Sudut tumpul", "Sudut siku-siku", "Sudut refleks")),
            Triple("Sudut yang besarnya lebih dari 90° namun kurang dari 180° disebut sebagai sudut apa?", "Sudut tumpul", listOf("Sudut lancip", "Sudut siku-siku", "Sudut putaran")),
            Triple("Sudut yang besarnya tepat 90° disebut sebagai sudut apa?", "Sudut siku-siku", listOf("Sudut lancip", "Sudut tumpul", "Sudut lurus")),
            Triple("Sudut yang besarnya lebih dari 180° namun kurang dari 360° disebut sebagai sudut apa?", "Sudut refleks", listOf("Sudut tumpul", "Sudut lancip", "Sudut siku-siku")),
            Triple("Satu putaran penuh pada lingkaran memiliki total besar sudut berapa derajat?", "360°", listOf("180°", "270°", "400°")),
            Triple("Setengah putaran penuh lingkaran setara dengan sudut berapa derajat?", "180°", listOf("90°", "120°", "270°")),
            Triple("Seperempat putaran penuh lingkaran menghasilkan sudut sebesar berapa derajat?", "90°", listOf("45°", "60°", "180°")),
            Triple("Dua garis yang terletak pada satu bidang datar dan tidak akan pernah berpotongan meski diperpanjang disebut?", "Garis sejajar (paralel)", listOf("Garis berpotongan", "Garis berhimpit", "Garis tegak lurus")),
            Triple("Dua garis yang berpotongan dan membentuk sudut tepat 90° disebut sebagai garis apa?", "Garis tegak lurus (perpendikular)", listOf("Garis sejajar", "Garis berimpit", "Garis lengkung")),
            Triple("Sebuah dadu standar bermata 6 memiliki titik 1 sampai 6. Jumlah titik pada dua sisi yang berlawanan selalu berjumlah?", "7", listOf("6", "8", "10")),
            Triple("Jika pada sebuah dadu sisi atas menunjukkan angka 2, berapakah angka pada sisi dadu bagian bawah?", "5", listOf("3", "4", "6")),
            Triple("Jika pada sebuah dadu sisi atas menunjukkan angka 1, berapakah angka pada sisi dadu bagian bawah?", "6", listOf("2", "4", "5")),
            Triple("Jika pada sebuah dadu sisi atas menunjukkan angka 3, berapakah angka pada sisi dadu bagian bawah?", "4", listOf("2", "5", "6")),
            Triple("Sebuah lapangan berbentuk persegi panjang memiliki panjang 20 meter dan lebar 10 meter. Berapa kelilingnya?", "60 meter", listOf("30 meter", "50 meter", "200 meter")),
            Triple("Sebuah kolam ikan berbentuk bujur sangkar memiliki panjang sisi 7 meter. Berapa keliling kolam tersebut?", "28 meter", listOf("14 meter", "21 meter", "49 meter")),
            Triple("Sebuah persegi memiliki keliling 36 cm. Berapakah panjang masing-masing sisi persegi tersebut?", "9 cm", listOf("6 cm", "8 cm", "12 cm")),
            Triple("Sebuah segitiga sama sisi memiliki keliling 27 cm. Berapakah panjang satu sisinya?", "9 cm", listOf("6 cm", "7 cm", "8 cm")),
            Triple("Sebuah persegi panjang memiliki keliling 30 cm. Jika panjangnya 10 cm, berapakah lebarnya?", "5 cm", listOf("4 cm", "6 cm", "8 cm")),
            Triple("Sebuah kubus memiliki panjang rusuk 3 cm. Berapakah volume kubus tersebut?", "27 cm³", listOf("9 cm³", "18 cm³", "36 cm³")),
            Triple("Sebuah kubus memiliki panjang rusuk 4 cm. Berapakah volume kubus tersebut?", "64 cm³", listOf("16 cm³", "32 cm³", "48 cm³")),
            Triple("Sebuah kubus memiliki panjang rusuk 5 cm. Berapakah volume kubus tersebut?", "125 cm³", listOf("25 cm³", "50 cm³", "100 cm³")),
            Triple("Sebuah balok memiliki panjang 5 cm, lebar 3 cm, dan tinggi 2 cm. Berapakah volume balok tersebut?", "30 cm³", listOf("20 cm³", "25 cm³", "35 cm³")),
            Triple("Sebuah balok memiliki panjang 6 cm, lebar 4 cm, dan tinggi 2 cm. Berapakah volume balok tersebut?", "48 cm³", listOf("24 cm³", "36 cm³", "52 cm³")),
            Triple("Sebuah balok memiliki panjang 10 cm, lebar 5 cm, dan tinggi 4 cm. Berapakah volume balok tersebut?", "200 cm³", listOf("100 cm³", "150 cm³", "250 cm³")),
            Triple("Sebuah akuarium kaca berbentuk kubus terisi penuh air dengan volume 1.000 cm³. Berapa panjang rusuk bagian dalamnya?", "10 cm", listOf("8 cm", "12 cm", "100 cm"))
        )
        for (item in spatialGeom50) {
            val wrongs = item.third.take(3)
            val options = makeOptions(item.second, wrongs[0], wrongs.getOrElse(1) { "LAIN" }, wrongs.getOrElse(2) { "BEDA" }, count = 4)

            questions.add(
                Question(
                    id = "logika_910_$qId",
                    category = QuizCategory.LOGIKA,
                    ageBracket = AgeBracket.AGE_9_10,
                    questionText = item.first,
                    visualEmoji = "📐 Geometri & Spasial",
                    options = options,
                    correctIndex = 0,
                    explanation = "Jawaban yang benar menurut kaidah geometri dan spasial adalah '${item.second}'.",
                    hint = "Ingat sifat bangun ruang, sudut, simetri, dan rumus dimensi dasar.",
                    difficulty = "Tantangan"
                )
            )
            qId++
        } // Exactly 150 questions for Age 9-10!

        return questions
    }
}
