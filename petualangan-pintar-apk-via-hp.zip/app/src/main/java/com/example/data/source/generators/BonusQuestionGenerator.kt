package com.example.data.source.generators

import com.example.data.model.AgeBracket
import com.example.data.model.Question
import com.example.data.model.QuizCategory

object BonusQuestionGenerator {

    fun generateQuestions(): List<Question> {
        val list = ArrayList<Question>(50)
        list.addAll(generateAge56())
        list.addAll(generateAge78())
        list.addAll(generateAge910())
        return list
    }

    // 17 Pertanyaan untuk Usia 5-6
    private fun generateAge56(): List<Question> {
        val templates = listOf(
            Triple("Jika ada 3 apel merah ditambah 2 jeruk segar di keranjang, berapa jumlah semua buah?", "5 buah", listOf("4 buah", "6 buah")),
            Triple("Hewan loreng oranye hitam yang dijuluki raja rimba adalah?", "Harimau", listOf("Kucing", "Kelinci")),
            Triple("Hasil percampuran cat warna merah dan kuning menghasilkan warna?", "Oranye (Jingga)", listOf("Hijau", "Ungu")),
            Triple("Huruf terakhir dari kata 'GAJAH' adalah huruf?", "H", listOf("A", "J")),
            Triple("Benda apa yang kita gunakan untuk melindungi kepala saat berkendara sepeda?", "Helm", listOf("Topi koboi", "Kacamata")),
            Triple("Berapa jumlah roda pada dua buah sepeda anak beroda dua?", "4 roda", listOf("2 roda", "6 roda")),
            Triple("Air laut rasanya apa saat kita cicipi?", "Asin", listOf("Manis", "Pahit")),
            Triple("Lawan kata dari gembira dan tertawa ceria adalah?", "Sedih", listOf("Pintar", "Ramah")),
            Triple("Bentuk telur ayam menyerupai bangun ruang atau bangun datar apa?", "Lonjong (Oval)", listOf("Kotak", "Segitiga")),
            Triple("Jumlah jari pada kedua tangan kita jika digabungkan ada berapa?", "10 jari", listOf("8 jari", "12 jari")),
            Triple("Alas kaki yang kita pakai saat berolahraga lari di lapangan adalah?", "Sepatu olahraga", listOf("Sandal jepit", "Kaus kaki saja")),
            Triple("Sebelum menyantap makanan bersama keluarga, kita mencuci apa?", "Kedua tangan", listOf("Kaki saja", "Rambut saja")),
            Triple("Buah yang berkulit duri tajam tetapi memiliki aroma harum dan rasa manis adalah?", "Durian", listOf("Semangka", "Melon")),
            Triple("Sarapan dilakukan pada waktu kapan?", "Pagi hari", listOf("Malam hari", "Tengah malam")),
            Triple("Hewan mungil yang suka bekerjasama mengangkat remah gula adalah?", "Semut", listOf("Gajah", "Kucing")),
            Triple("Kata 'BOLA' diawali dengan huruf apa?", "B", listOf("O", "L")),
            Triple("Warna rumput segar di taman bermain yang terkena sinar mentari adalah?", "Hijau", listOf("Merah", "Biru"))
        )
        return templates.mapIndexed { index, t ->
            Question(
                id = "bonus_56_${index + 1}",
                category = QuizCategory.BONUS_CAMPURAN,
                ageBracket = AgeBracket.AGE_5_6,
                questionText = t.first,
                visualEmoji = "🎁 Ekspedisi Bintang",
                options = listOf(t.second) + t.third,
                correctIndex = 0,
                explanation = "Tepat sekali! Jawaban yang benar adalah '${t.second}'.",
                hint = "Gunakan pengamatan cermatmu sebagai penjelajah cilik.",
                difficulty = "Mudah"
            )
        }
    }

    // 17 Pertanyaan untuk Usia 7-8
    private fun generateAge78(): List<Question> {
        val templates = listOf(
            Triple("Jika 15 permen manis dibagikan rata kepada 3 anak, masing-masing anak mendapat berapa permen?", "5 permen", listOf("3 permen", "4 permen", "6 permen")),
            Triple("Lawan kata atau antonim dari kata 'BERSIH' adalah?", "KOTOR", listOf("RAPI", "INDAH", "WANGI")),
            Triple("Tumbuhan menyerap air dan sari makanan dari dalam tanah menggunakan bagian apa?", "Akar", listOf("Daun", "Batang", "Bunga")),
            Triple("Jika kemarin adalah hari Selasa, maka lusa adalah hari apa?", "Jumat", listOf("Kamis", "Sabtu", "Minggu")),
            Triple("Rumah adat tradisional dengan atap jerami khas Papua bernama rumah apa?", "Honai", listOf("Gadang", "Joglo", "Tongkonan")),
            Triple("Waktu 2 jam sama dengan berapa menit perjalanan?", "120 menit", listOf("60 menit", "100 menit", "180 menit")),
            Triple("Berapakah hasil perkalian dari 8 dikali 4?", "32", listOf("28", "30", "36")),
            Triple("Persamaan kata atau sinonim dari kata 'PANDAI' adalah?", "PINTAR", listOf("MALAS", "LEMAH", "LAMBAT")),
            Triple("Benda langit yang memiliki ekor gas menyala saat mendekati matahari disebut?", "Komet", listOf("Bintang", "Planet", "Bulan")),
            Triple("Mamalia laut bersahabat yang cerdas dan sering membantu manusia adalah?", "Lumba-lumba", listOf("Hiu putih", "Gurita raksasa", "Ubur-ubur")),
            Triple("Bangun datar yang memiliki 3 sisi dan 3 sudut adalah bangun apa?", "Segitiga", listOf("Persegi", "Trapesium", "Lingkaran")),
            Triple("Jika mobil diparkir di garasi, maka burung tinggal di mana?", "Sarang", listOf("Langit", "Pohon saja", "Kandang besi")),
            Triple("Warna pada perisai burung Garuda yang melambangkan keberanian bangsa adalah?", "Merah", listOf("Putih", "Kuning", "Hijau")),
            Triple("Jika kamu memiliki 2 lembar uang lima ribu rupiah, berapa total uangmu?", "Rp 10.000", listOf("Rp 7.000", "Rp 15.000", "Rp 20.000")),
            Triple("Tanda baca yang tepat untuk mengakhiri kalimat seruan kagum adalah?", "Tanda seru (!)", listOf("Tanda tanya (?)", "Tanda titik (.)", "Tanda koma (,)")),
            Triple("Katak saat masih kecil dan hidup di air berwujud sebagai apa?", "Kecebong (Berudu)", listOf("Ulat", "Jentik", "Pupa")),
            Triple("Gunung berapi di Selat Sunda yang letusannya terkenal di seluruh dunia adalah?", "Gunung Krakatau", listOf("Gunung Merapi", "Gunung Bromo", "Gunung Rinjani"))
        )
        return templates.mapIndexed { index, t ->
            Question(
                id = "bonus_78_${index + 1}",
                category = QuizCategory.BONUS_CAMPURAN,
                ageBracket = AgeBracket.AGE_7_8,
                questionText = t.first,
                visualEmoji = "🧭 Petualangan Plus",
                options = listOf(t.second) + t.third,
                correctIndex = 0,
                explanation = "Hebat! Jawaban yang tepat adalah '${t.second}'.",
                hint = "Gabungkan pengetahuan matematika, sains, dan bahasamu.",
                difficulty = "Sedang"
            )
        }
    }

    // 16 Pertanyaan untuk Usia 9-10
    private fun generateAge910(): List<Question> {
        val templates = listOf(
            Triple("Jika 4 dikalikan dengan N menghasilkan nilai 48, berapakah nilai N?", "12", listOf("10", "11", "14")),
            Triple("Kalimat 'Mentari tersenyum menyapa pagi' menggunakan gaya bahasa apa?", "Personifikasi", listOf("Metafora", "Hiperbola", "Litotes")),
            Triple("Gerhana matahari terjadi ketika bulan berada tepat di antara posisi apa?", "Bumi dan Matahari", listOf("Bumi dan Mars", "Matahari dan Yupiter", "Bumi dan Bintang")),
            Triple("Perhatikan deret bilangan: 3, 6, 12, 24, 48, ... bilangan berikutnya adalah?", "96", listOf("72", "84", "90")),
            Triple("Selat yang memisahkan antara Pulau Kalimantan dan Pulau Sulawesi bernama?", "Selat Makassar", listOf("Selat Sunda", "Selat Malaka", "Selat Bali")),
            Triple("Naskah Proklamasi Kemerdekaan Indonesia diketik rapi oleh siapa?", "Sayuti Melik", listOf("Sukarni", "B.M. Diah", "Chaerul Saleh")),
            Triple("Sebuah persegi memiliki luas 64 cm², berapakah keliling persegi tersebut?", "32 cm", listOf("24 cm", "28 cm", "36 cm")),
            Triple("Ungkapan 'panjang tangan' dalam bahasa Indonesia memiliki arti apa?", "Suka mencuri", listOf("Tangannya panjang", "Suka menolong", "Pandai melukis")),
            Triple("Perpindahan panas dari matahari hingga sampai ke permukaan bumi terjadi melalui cara apa?", "Radiasi", listOf("Konduksi", "Konveksi", "Evaporasi")),
            Triple("Makhluk hidup yang berperan sebagai produsen dalam rantai makanan adalah?", "Tumbuhan hijau", listOf("Herbivora", "Karnivora", "Bakteri pengurai")),
            Triple("Berapakah Kelipatan Persekutuan Terkecil (KPK) dari bilangan 6 dan 8?", "24", listOf("12", "18", "48")),
            Triple("Lawan kata atau antonim dari kata 'OPTIMIS' adalah?", "PESIMIS", listOf("REALISTIS", "KRITIS", "STATIS")),
            Triple("Sel darah yang berfungsi utama mengikat dan mengedarkan oksigen adalah?", "Sel darah merah (Eritrosit)", listOf("Sel darah putih", "Keping darah", "Plasma darah")),
            Triple("Satuan standar internasional yang digunakan untuk mengukur gaya adalah?", "Newton", listOf("Joule", "Watt", "Pascal")),
            Triple("Tari tradisional Piring yang memukau berasal dari daerah mana di Indonesia?", "Sumatera Barat (Minangkabau)", listOf("Aceh", "Jawa Barat", "Bali")),
            Triple("Berapa besar sudut terkecil yang terbentuk oleh kedua jarum jam pada pukul 09.00 tepat?", "90° (Siku-siku)", listOf("60°", "120°", "180°"))
        )
        return templates.mapIndexed { index, t ->
            Question(
                id = "bonus_910_${index + 1}",
                category = QuizCategory.BONUS_CAMPURAN,
                ageBracket = AgeBracket.AGE_9_10,
                questionText = t.first,
                visualEmoji = "👑 Master Penjelajah",
                options = listOf(t.second) + t.third,
                correctIndex = 0,
                explanation = "Luar biasa! Jawaban yang tepat adalah '${t.second}'.",
                hint = "Pikirkan integrasi konsep sains, matematika, dan wawasan nusantara.",
                difficulty = "Tantangan"
            )
        }
    }
}
