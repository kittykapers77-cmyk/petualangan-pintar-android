package com.example.data.source.generators

import com.example.data.model.AgeBracket
import com.example.data.model.Question
import com.example.data.model.QuizCategory

object UmumQuestionGenerator {

    fun generateQuestions(): List<Question> {
        val list = ArrayList<Question>(450)
        list.addAll(generateAge56())
        list.addAll(generateAge78())
        list.addAll(generateAge910())
        return list
    }

    private fun makeOptions(correct: String, vararg candidates: String, count: Int = 4): List<String> {
        val result = linkedSetOf(correct)
        for (c in candidates) {
            if (c != correct && c.isNotBlank()) {
                result.add(c)
                if (result.size == count) break
            }
        }
        var offset = 1
        while (result.size < count) {
            val fallback = "$correct (pilihan $offset)"
            offset++
            if (fallback != correct && !result.contains(fallback)) {
                result.add(fallback)
            }
        }
        return result.toList()
    }

    // =========================================================================
    // USIA 5-6 TAHUN (150 PERTANYAAN ALAMI)
    // =========================================================================
    private fun generateAge56(): List<Question> {
        val questions = ArrayList<Question>(150)
        var qId = 1

        // 1. Identitas Bangsa, Tubuh Kita & Kebiasaan Sehat (50 pertanyaan unik alami)
        val basics50 = listOf(
            Triple("Warna bendera kebanggaan negara Indonesia tercinta adalah?", "Merah dan Putih", listOf("Biru dan Kuning", "Hijau dan Putih")),
            Triple("Bagian tubuh mana yang kita gunakan untuk melihat indahnya warna pelangi?", "Mata", listOf("Telinga", "Hidung")),
            Triple("Bagian tubuh mana yang kita gunakan untuk mendengarkan alunan musik ceria?", "Telinga", listOf("Mata", "Mulut")),
            Triple("Bagian tubuh mana yang kita gunakan untuk mencium wangi semerbak bunga mawar?", "Hidung", listOf("Lidah", "Telinga")),
            Triple("Bagian tubuh mana yang kita gunakan untuk mengecap manisnya madu lebah?", "Lidah", listOf("Gigi", "Hidung")),
            Triple("Lambang negara Indonesia yang gagah perkasa adalah burung apa?", "Garuda Pancasila", listOf("Merpati putih", "Burung hantu")),
            Triple("Berapa jumlah jari pada satu telapak tangan anak sehat?", "5 jari", listOf("4 jari", "10 jari")),
            Triple("Gigi kita yang bersih putih berguna untuk apa saat makan?", "Mengunyah makanan", listOf("Mendengar suara", "Melihat makanan")),
            Triple("Kita wajib mencuci tangan bersih menggunakan sabun sebelum apa?", "Menyantap makanan", listOf("Tidur malam saja", "Bermain pasir")),
            Triple("Warna daun pohon yang masih segar di pekarangan rumah biasanya berwarna apa?", "Hijau", listOf("Ungu", "Merah muda")),
            Triple("Apa nama lagu kebangsaan negara kita Indonesia?", "Indonesia Raya", listOf("Pelangi-Pelangi", "Balonku Ada Lima")),
            Triple("Siapakah presiden pertama yang memproklamasikan kemerdekaan Indonesia?", "Ir. Soekarno", listOf("Jenderal Soedirman", "Pangeran Diponegoro")),
            Triple("Ibu kota negara Indonesia yang berada di Pulau Jawa adalah kota apa?", "Jakarta", listOf("Bandung", "Surabaya")),
            Triple("Bagian tubuh mana yang kita gunakan untuk berlari dan menendang bola?", "Kaki", listOf("Tangan", "Kepala")),
            Triple("Bagian tubuh mana yang kita gunakan untuk bersalaman dan melambaikan tangan?", "Tangan", listOf("Kaki", "Lutut")),
            Triple("Benda apa yang kita gunakan untuk menyikat gigi agar tidak berlubang?", "Sikat gigi dan odol", listOf("Sabun mandi", "Sampo rambut")),
            Triple("Cairan wangi apa yang kita gunakan untuk keramas membersihkan rambut kepala?", "Sampo rambut", listOf("Pasta gigi", "Minyak goreng")),
            Triple("Air apa yang paling sehat dan aman untuk diminum setiap hari?", "Air putih matang", listOf("Air selokan", "Air laut mentah")),
            Triple("Berapa kali sebaiknya kita mandi setiap hari agar badan segar dan bersih?", "Dua kali sehari", listOf("Seminggu sekali", "Sebulan sekali")),
            Triple("Kapan waktu yang paling tepat untuk menggosok gigi?", "Pagi setelah sarapan dan malam sebelum tidur", listOf("Hanya saat hari libur", "Saat sedang makan")),
            Triple("Makanan pokok masyarakat Indonesia yang berwarna putih dan pulen adalah apa?", "Nasi putih", listOf("Kue cokelat", "Permen")),
            Triple("Sayuran berwarna oranye yang sangat baik untuk kesehatan mata kita adalah apa?", "Wortel", listOf("Terung", "Bawang")),
            Triple("Minuman bernutrisi tinggi dari sapi yang membantu pertumbuhan tulang dan gigi adalah apa?", "Susu sapi segar", listOf("Air kopi hitam", "Susu kental manis saja")),
            Triple("Buah berkulit kuning panjang yang sangat disukai monyet dan kaya vitamin adalah apa?", "Pisang", listOf("Kelapa", "Semangka")),
            Triple("Benda apa yang kita pakai di kepala saat mengendarai sepeda motor?", "Helm pengaman", listOf("Topi koboi", "Kacamata renang")),
            Triple("Lampu lalu lintas yang berwarna merah menyala menandakan apa bagi kendaraan?", "Wajib berhenti", listOf("Boleh jalan cepat", "Hati-hati pelan")),
            Triple("Lampu lalu lintas yang berwarna hijau menyala menandakan apa bagi pengendara?", "Boleh berjalan", listOf("Wajib berhenti", "Mundur perlahan")),
            Triple("Lampu lalu lintas yang berwarna kuning menandakan apa?", "Hati-hati bersiap", listOf("Wajib berhenti", "Boleh melaju kencang")),
            Triple("Tempat penyeberangan jalan berpola garis putih-hitam di aspal disebut apa?", "Zebra cross", listOf("Jembatan gantung", "Rel kereta")),
            Triple("Saat hendak menyeberang jalan raya, ke arah mana kita harus menengok terlebih dahulu?", "Ke kanan dan ke kiri", listOf("Hanya memandang ke atas", "Menutup mata")),
            Triple("Apa yang harus kita lakukan pada sampah bungkus makanan yang kita pegang?", "Membuangnya ke tempat sampah", listOf("Melemparnya ke selokan", "Menaruhnya di lantai")),
            Triple("Benda apa yang melindungi kita dari rintik air hujan saat melangkah di luar?", "Payung", listOf("Buku tulis", "Bantal")),
            Triple("Alas kaki apa yang kita kenakan saat pergi belajar di sekolah?", "Sepatu sekolah", listOf("Sandal jepit", "Kaus kaki saja")),
            Triple("Benda apa yang kita gunakan untuk mengeringkan badan sehabis mandi segar?", "Handuk mandi", listOf("Selimut tidur", "Taplak meja")),
            Triple("Kapan kita beristirahat tidur malam yang baik untuk tubuh anak?", "Malam hari tidak larut", listOf("Tengah hari bolong", "Subuh pagi")),
            Triple("Alat apa yang kita gunakan untuk merapikan rambut yang berantakan?", "Sisir rambut", listOf("Sikat sepatu", "Gunting kertas")),
            Triple("Kuku tangan yang sudah panjang dan kotor sebaiknya diapakan?", "Dipotong rapi dengan gunting kuku", listOf("Digigit dengan gigi", "Dibiarkan saja")),
            Triple("Sebelum berangkat ke sekolah di pagi hari, kita sebaiknya melakukan apa agar bertenaga?", "Sarapan pagi yang sehat", listOf("Tidur kembali", "Bermain game saja")),
            Triple("Semboyan persatuan bangsa Indonesia yang bermakna berbeda-beda tetapi tetap satu adalah apa?", "Bhinneka Tunggal Ika", listOf("Tut Wuri Handayani", "Ing Ngarso Sung Tulodo")),
            Triple("Warna merah pada bendera Republik Indonesia melambangkan apa?", "Keberanian", listOf("Kesucian", "Kemakmuran")),
            Triple("Warna putih pada bendera Republik Indonesia melambangkan nilai apa?", "Kesucian hati", listOf("Keberanian", "Kegelapan")),
            Triple("Berapa jumlah sila yang terdapat di dalam dasar negara Pancasila?", "Lima sila", listOf("Tiga sila", "Tujuh sila")),
            Triple("Simbol bintang emas pada perisai burung Garuda melambangkan sila ke berapa?", "Sila pertama (Ketuhanan)", listOf("Sila kedua", "Sila ketiga")),
            Triple("Simbol rantai emas pada perisai burung Garuda melambangkan sila ke berapa?", "Sila kedua (Kemanusiaan)", listOf("Sila pertama", "Sila keempat")),
            Triple("Pohon beringin yang rindang pada lambang Pancasila melambangkan sila ke berapa?", "Sila ketiga (Persatuan)", listOf("Sila kedua", "Sila kelima")),
            Triple("Kepala banteng pada perisai Pancasila melambangkan sila ke berapa?", "Sila keempat (Kerakyatan)", listOf("Sila ketiga", "Sila pertama")),
            Triple("Padi dan kapas pada perisai burung Garuda melambangkan sila ke berapa?", "Sila kelima (Keadilan Sosial)", listOf("Sila keempat", "Sila kedua")),
            Triple("Siapakah wakil presiden pertama Republik Indonesia yang mendampingi Bung Karno?", "Drs. Mohammad Hatta", listOf("Ki Hajar Dewantara", "Adam Malik")),
            Triple("Monumen tinggi berkubah emas di pusat kota Jakarta bernama apa?", "Monas (Monumen Nasional)", listOf("Candi Borobudur", "Tugu Khatulistiwa")),
            Triple("Hari Kemerdekaan Republik Indonesia diperingati setiap tanggal berapa?", "17 Agustus", listOf("21 April", "2 Mei"))
        )
        for (item in basics50) {
            val wrongs = item.third.take(2)
            val options = makeOptions(item.second, wrongs[0], wrongs.getOrElse(1) { "LAIN" }, count = 3)
            questions.add(
                Question(
                    id = "umum_56_$qId",
                    category = QuizCategory.PENGETAHUAN_UMUM,
                    ageBracket = AgeBracket.AGE_5_6,
                    questionText = item.first,
                    visualEmoji = "🇮🇩 Sahabat Cilik",
                    options = options,
                    correctIndex = 0,
                    explanation = "Benar sekali! Jawaban yang tepat adalah '${item.second}'.",
                    hint = "Ingat pengetahuan dasar tentang bangsa dan kesehatan diri.",
                    difficulty = "Mudah"
                )
            )
            qId++
        } // 50 questions done

        // 2. Dunia Hewan & Satwa Nusantara (50 pertanyaan unik alami)
        val animals50 = listOf(
            Triple("Hewan mamalia berbadan sangat besar yang memiliki belalai panjang dan gading putih adalah apa?", "Gajah", listOf("Jerapah", "Kuda")),
            Triple("Hewan leher panjang yang suka memakan dedaunan di pucuk pohon tinggi adalah apa?", "Jerapah", listOf("Gajah", "Badak")),
            Triple("Hewan buas loreng oranye-hitam yang dijuluki raja hutan rimba Sumatera adalah apa?", "Harimau", listOf("Kucing", "Serigala")),
            Triple("Kucing besar yang memiliki surai lebat di kepalanya dan dijuluki raja rimba Afrika adalah apa?", "Singa", listOf("Harimau", "Citah")),
            Triple("Kadal raksasa purba asli yang hidup dilindungi di pulau Nusa Tenggara Timur adalah apa?", "Komodo", listOf("Buaya", "Iguana")),
            Triple("Burung berbulu sangat indah dengan ekor warna-warni khas dari Papua adalah burung apa?", "Cenderawasih", listOf("Merpati", "Kutilang")),
            Triple("Kera besar berbulu kemerahan yang hidup berayun di pepohonan Kalimantan dan Sumatera adalah apa?", "Orangutan", listOf("Monyet ekor panjang", "Gorila")),
            Triple("Hewan bertubuh loreng hitam-putih seperti kuda yang hidup di padang sabana adalah apa?", "Zebra", listOf("Kuda poni", "Sapi")),
            Triple("Hewan berkantung khas yang melompat tinggi dan membawa anaknya di kantung perut adalah apa?", "Kangguru", listOf("Koala", "Kelinci")),
            Triple("Hewan pemalas menggemaskan dari Australia yang suka memeluk pohon kayu putih dan makan daun eukaliptus adalah apa?", "Koala", listOf("Kukang", "Panda")),
            Triple("Hewan bertubuh gemuk hitam-putih dari negeri bambu Cina yang gemar makan rebung bambu adalah apa?", "Panda", listOf("Beruang madu", "Zebra")),
            Triple("Mamalia terbesar di planet bumi yang hidup berenang di samudra luas adalah apa?", "Paus biru", listOf("Hiu putih", "Gajah afrika")),
            Triple("Ikan mamalia laut yang sangat cerdas, ramah, dan suka menolong manusia di laut adalah apa?", "Lumba-lumba", listOf("Hiu macan", "Ikan pari")),
            Triple("Ikan pemangsa berdarah dingin yang memiliki sirip punggung tajam dan deretan gigi tajam adalah apa?", "Ikan hiu", listOf("Lumba-lumba", "Ikan koki")),
            Triple("Hewan laut berkulit duri yang memiliki bentuk menyerupai bintang adalah apa?", "Bintang laut", listOf("Ubur-ubur", "Kuda laut")),
            Triple("Hewan bertubuh kenyal transparan di laut yang bisa menyengat jika tersentuh adalah apa?", "Ubur-ubur", listOf("Terumbu karang", "Rumput laut")),
            Triple("Hewan kecil penghuni terumbu karang yang kepalanya menyerupai kepala kuda kecil adalah apa?", "Kuda laut", listOf("Ikan badut", "Udang rebon")),
            Triple("Hewan amfibi bersuara krok-krok yang pandai berenang dan melompat lincah adalah apa?", "Katak hijau", listOf("Kadal", "Bunglon")),
            Triple("Hewan reptil yang berjalan sangat lambat dan memiliki cangkang rumah keras pelindung di punggungnya adalah apa?", "Kura-kura", listOf("Katak", "Kadal")),
            Triple("Reptil yang pandai mengubah warna kulitnya agar sama dengan lingkungan sekitar untuk berkamuflase adalah apa?", "Bunglon", listOf("Cicak dinding", "Tokek")),
            Triple("Hewan kecil yang merayap di dinding rumah dan bisa memutuskan ekornya saat bahaya adalah apa?", "Cicak", listOf("Ular", "Katak")),
            Triple("Burung nokturnal yang aktif terbang berburu di malam hari dan matanya bulat besar adalah burung apa?", "Burung hantu", listOf("Burung elang", "Burung merak")),
            Triple("Burung pemangsa yang memiliki penglihatan sangat tajam dan paruh bengkok kuat untuk berburu ikan adalah apa?", "Burung elang", listOf("Burung dara", "Burung gereja")),
            Triple("Burung yang tidak bisa terbang tetapi sangat pandai berenang di perairan es kutub yang dingin adalah apa?", "Penguin", listOf("Bebek", "Pelikan")),
            Triple("Burung bertubuh paling besar di dunia yang memiliki kaki panjang kuat dan bisa berlari sangat cepat adalah apa?", "Burung unta", listOf("Burung kasuari", "Burung merak")),
            Triple("Unggas air berleher panjang anggun berbulu putih bersih yang berenang di danau taman adalah apa?", "Angsa putih", listOf("Ayam kalkun", "Burung pipit")),
            Triple("Serangga cantik bersayap aneka warna yang berasal dari ulat kepompong adalah apa?", "Kupu-kupu", listOf("Capung", "Kepik")),
            Triple("Serangga kecil pekerja keras yang memproduksi madu manis di dalam sarang heksagonal adalah apa?", "Lebah madu", listOf("Lalat", "Nyamuk")),
            Triple("Serangga kecil yang hidup berkoloni bekerjasama mengangkat beban berkali-kali lipat berat tubuhnya adalah apa?", "Semut", listOf("Kumbang", "Jangkrik")),
            Triple("Serangga malam yang ekornya dapat memancarkan cahaya kerlap-kerlip indah di kegelapan adalah apa?", "Kunang-kunang", listOf("Nyamuk", "Kecoa")),
            Triple("Hewan pengerat mungil bertelinga panjang yang sangat suka mengunyah wortel segar adalah apa?", "Kelinci", listOf("Tupai", "Hamster")),
            Triple("Hewan lincah berbulu lebat berekor mengembang yang suka melompat di dahan pohon memakan biji kenari adalah apa?", "Tupai", listOf("Tikus", "Musang")),
            Triple("Hewan yang memiliki duri-duri tajam di sekujur punggungnya untuk melindungi diri dari musuh adalah apa?", "Landak", listOf("Trenggiling", "Kucing")),
            Triple("Hewan bersisik keras yang menggulung tubuhnya menjadi bola saat merasa terancam adalah apa?", "Trenggiling", listOf("Landak", "Biawak")),
            Triple("Hewan berkaki empat yang memiliki punuk di punggungnya untuk menyimpan cadangan energi di gurun pasir adalah apa?", "Unta", listOf("Kuda", "Keledai")),
            Triple("Hewan ternak bertanduk melengkung yang menghasilkan wol hangat dari bulu tebalnya adalah apa?", "Domba", listOf("Kambing", "Sapi")),
            Triple("Hewan ternak berkaki empat pemakan rumput yang menghasilkan daging dan susu sapi segar adalah apa?", "Sapi perah", listOf("Kuda balap", "Babi")),
            Triple("Hewan tangguh berkaki empat yang sejak zaman dahulu membantu manusia menarik kereta delman adalah apa?", "Kuda", listOf("Gajah", "Rusa")),
            Triple("Hewan bertanduk cabang indah di kepalanya yang lincah berlari di hutan lindung adalah apa?", "Rusa", listOf("Banteng", "Kambing")),
            Triple("Hewan liar bercula satu yang langka dan dilindungi di Taman Nasional Ujung Kulon adalah apa?", "Badak jawa", listOf("Banteng", "Kuda nil")),
            Triple("Mamalia air berkulit tebal berbadan bulat besar yang suka berendam di air sungai Afrika adalah apa?", "Kuda nil", listOf("Buaya", "Badak")),
            Triple("Reptil pemangsa bergigi runcing yang hidup di rawa-rawa dan memiliki moncong panjang adalah apa?", "Buaya", listOf("Kura-kura", "Komodo")),
            Triple("Hewan laut bercangkang keras yang berjalan miring ke samping dan memiliki sepasang capit adalah apa?", "Kepiting", listOf("Ikan lele", "Cumi-cumi")),
            Triple("Hewan laut bertubuh kenyal yang menyemprotkan tinta hitam pekat dan memiliki tentakel adalah apa?", "Cumi-cumi", listOf("Ikan tongkol", "Bintang laut")),
            Triple("Ikan air tawar berkumis panjang yang sering dibudidayakan di kolam terpal adalah ikan apa?", "Ikan lele", listOf("Ikan mas koki", "Ikan koi")),
            Triple("Ikan hias bertubuh bulat oranye cerah berekor rumbai indah yang dipelihara di akuarium adalah apa?", "Ikan mas koki", listOf("Ikan gabus", "Ikan bawal")),
            Triple("Hewan kecil berkaki seribu yang menggulung tubuhnya jika disentuh adalah apa?", "Kaki seribu (Keluwing)", listOf("Cacing tanah", "Ulat bulu")),
            Triple("Hewan tidak bertulang belakang yang hidup di dalam tanah basah dan membantu menggemburkan tanah adalah apa?", "Cacing tanah", listOf("Kutu daun", "Kecoa")),
            Triple("Hewan yang berkicau merdu menyambut terbitnya matahari fajar di pedesaan adalah apa?", "Ayam jantan", listOf("Bebek", "Burung bangau")),
            Triple("Hewan amfibi yang bertelur di air dan menetas menjadi kecebong atau berudu adalah apa?", "Katak", listOf("Cicak", "Ular"))
        )
        for (item in animals50) {
            val wrongs = item.third.take(2)
            val options = makeOptions(item.second, wrongs[0], wrongs.getOrElse(1) { "LAIN" }, count = 3)
            questions.add(
                Question(
                    id = "umum_56_$qId",
                    category = QuizCategory.PENGETAHUAN_UMUM,
                    ageBracket = AgeBracket.AGE_5_6,
                    questionText = item.first,
                    visualEmoji = "🦁 Dunia Satwa",
                    options = options,
                    correctIndex = 0,
                    explanation = "Jawaban yang benar adalah '${item.second}'.",
                    hint = "Perhatikan ciri khas fisik dan habitat hewan tersebut.",
                    difficulty = "Mudah"
                )
            )
            qId++
        } // 100 questions done

        // 3. Alam Sekitar, Tanaman & Cuaca (50 pertanyaan unik alami)
        val nature50 = listOf(
            Triple("Benda langit menyala yang memancarkan cahaya dan panas alami terbesar bagi bumi di siang hari adalah apa?", "Matahari", listOf("Bulan", "Bintang fajar")),
            Triple("Benda langit yang tampak bersinar lembut pada malam hari dan bentuknya dapat berubah sabit atau purnama adalah apa?", "Bulan", listOf("Matahari", "Awan mendung")),
            Triple("Titik-titik cahaya yang berkelap-kelip indah menghiasi angkasa pada malam hari yang cerah adalah apa?", "Bintang-bintang", listOf("Matahari", "Pelangi")),
            Triple("Lengkungan indah beraneka warna (merah, jingga, kuning, hijau, biru, nila, ungu) setelah hujan reda adalah apa?", "Pelangi", listOf("Awan mendung", "Petir kilat")),
            Triple("Tetesan air bersih yang turun dari awan di langit membasahi tanah dan tanaman disebut apa?", "Hujan", listOf("Angin sepoi", "Embun pagi")),
            Triple("Udara sejuk yang bergerak dan dapat menerbangkan layang-layang di lapangan disebut apa?", "Angin", listOf("Air", "Api")),
            Triple("Kilatan cahaya terang menyilaukan di langit yang disertai suara gemuruh menggelegar disebut apa?", "Petir dan guruh", listOf("Pelangi", "Kabut")),
            Triple("Gumpalan putih menyerupai kapas raksasa yang melayang-layang di langit biru disebut apa?", "Awan", listOf("Bulan", "Bintang")),
            Triple("Bagian tanaman yang berada di dalam tanah berfungsi menyerap air dan mengokohkan pohon adalah apa?", "Akar tanaman", listOf("Daun", "Bunga")),
            Triple("Bagian tanaman yang biasanya berwarna hijau dan bertugas memasak makanan dengan bantuan sinar matahari adalah apa?", "Daun tanaman", listOf("Akar", "Batang")),
            Triple("Bagian tanaman yang berwarna-warni indah dan berbau harum untuk menarik perhatian lebah adalah apa?", "Bunga", listOf("Akar", "Biji")),
            Triple("Bagian tanaman yang manis lezat dan sering kita petik untuk dimakan bersama keluarga adalah apa?", "Buah", listOf("Kulit batang", "Duri")),
            Triple("Biji tanaman yang ditanam di dalam tanah subur dan disiram air akan tumbuh menjadi apa?", "Tunas tanaman baru", listOf("Batu kali", "Air tanah")),
            Triple("Pohon khas pantai yang buahnya berkulit keras dan airnya sangat segar diminum adalah pohon apa?", "Pohon kelapa", listOf("Pohon beringin", "Pohon mangga")),
            Triple("Pohon berduri yang mampu bertahan hidup di padang pasir kering tanpa banyak air adalah apa?", "Kaktus", listOf("Padi", "Teratai")),
            Triple("Tanaman air berdaun bundar lebar yang bunganya mengapung cantik di atas kolam adalah apa?", "Bunga teratai", listOf("Kaktus", "Mawar")),
            Triple("Bunga berwarna merah berduri tajam di batangnya yang memiliki wangi harum semerbak adalah bunga apa?", "Bunga mawar", listOf("Bunga matahari", "Bunga kamboja")),
            Triple("Bunga berwarna putih mungil beraroma sangat harum yang sering dijadikan hiasan pengantin tradisional adalah apa?", "Bunga melati", listOf("Bunga mawar merah", "Bunga kaktus")),
            Triple("Bunga besar berwarna kuning terang yang selalu mekar menghadap ke arah datangnya sinar matahari adalah apa?", "Bunga matahari", listOf("Bunga melati", "Bunga tulip")),
            Triple("Tanaman pangan yang ditanam para petani di sawah dan menghasilkan butir beras adalah tanaman apa?", "Padi", listOf("Jagung manis", "Kedelai")),
            Triple("Tanaman umbi berduri daun yang buahnya berbulu manis dan banyak ditanam di pegunungan adalah apa?", "Salak", listOf("Semangka", "Melon")),
            Triple("Buah berkulit hijau tebal yang bagian dalamnya berwarna merah manis berair banyak adalah apa?", "Semangka", listOf("Pepaya", "Alpukat")),
            Triple("Buah berkulit oranye manis yang kaya vitamin C dan mudah dikupas dengan jari adalah apa?", "Jeruk manis", listOf("Salak", "Kelapa")),
            Triple("Buah berkulit duri tebal dengan aroma harum khas menyengat dan rasa legit manis adalah buah apa?", "Durian", listOf("Apel", "Anggur")),
            Triple("Buah lonjong berkulit hijau-kuning dengan daging oranye berbiji hitam kecil-kecil yang melancarkan pencernaan adalah apa?", "Pepaya", listOf("Nanas", "Manggis")),
            Triple("Buah tropis berkulit ungu tebal dengan mahkota hijau di atasnya yang dijuluki ratu buah adalah apa?", "Manggis", listOf("Rambutan", "Duku")),
            Triple("Buah berkulit merah berambut lentur dengan daging buah putih manis kenyal adalah buah apa?", "Rambutan", listOf("Kelengkeng", "Salak")),
            Triple("Tanaman menjalar yang menghasilkan buah labu besar berwarna oranye manis adalah apa?", "Labu kuning", listOf("Singkong", "Kacang tanah")),
            Triple("Bagian pohon yang berkayu keras dan menopang dahan serta ranting daun ke atas adalah apa?", "Batang pohon", listOf("Akar", "Bunga")),
            Triple("Hutan lebat yang banyak ditumbuhi pohon-pohon mangrove pencegah abrasi di tepi pantai adalah hutan apa?", "Hutan bakau (mangrove)", listOf("Hutan pinus", "Hutan jati")),
            Triple("Air jernih alami yang mengalir dari pegunungan melintasi bebatuan menuju ke laut disebut apa?", "Sungai", listOf("Danau", "Kolam buatan")),
            Triple("Hamparan air yang sangat luas dan dalam yang terasa asin karena mengandung garam alami adalah apa?", "Laut atau samudra", listOf("Danau air tawar", "Sungai pegunungan")),
            Triple("Genangan air luas yang dikelilingi oleh daratan di sekitarnya disebut apa?", "Danau", listOf("Samudra", "Selat")),
            Triple("Daratan tinggi yang menjulang gagah dan memiliki puncak serta lereng disebut apa?", "Gunung", listOf("Lembah", "Pantai pasir")),
            Triple("Wilayah daratan rendah berpasir yang berbatasan langsung dengan perairan laut disebut apa?", "Pantai", listOf("Puncak gunung", "Hutan rimba")),
            Triple("Gunung yang dapat mengeluarkan asap, abu vulkanik, dan lelehan lahar panas disebut gunung apa?", "Gunung berapi", listOf("Gunung kapur biasa", "Bukit buatan")),
            Triple("Getaran atau guncangan pada permukaan bumi yang disebabkan oleh pergeseran lempeng bumi disebut apa?", "Gempa bumi", listOf("Banjir bandang", "Angin puyuh")),
            Triple("Peristiwa meluapnya air sungai atau laut hingga merendam daratan dan perumahan warga disebut apa?", "Banjir", listOf("Kemarau panjang", "Gunung meletus")),
            Triple("Musim di Indonesia yang ditandai dengan jarangnya turun hujan dan sinar matahari terasa sangat terik disebut apa?", "Musim kemarau", listOf("Musim hujan", "Musim salju")),
            Triple("Musim di Indonesia yang ditandai dengan seringnya turun hujan hampir setiap hari disebut apa?", "Musim hujan", listOf("Musim kemarau", "Musim semi")),
            Triple("Indonesia merupakan negara beriklim apa karena dilintasi oleh garis khatulistiwa bumi?", "Iklim tropis", listOf("Iklim kutub", "Iklim subtropis empat musim")),
            Triple("Berapa jumlah musim alami yang ada di negara Indonesia sepanjang tahun?", "Dua musim (Hujan dan Kemarau)", listOf("Empat musim", "Satu musim saja")),
            Triple("Butiran air kecil yang menempel di ujung dedaunan pada pagi hari yang sejuk disebut apa?", "Embun pagi", listOf("Hujan es", "Air sumur")),
            Triple("Kumpulan uap air tipis melayang di dekat permukaan tanah yang membuat pandangan mata berkabut disebut apa?", "Kabut", listOf("Asap kebakaran", "Awan badai")),
            Triple("Bahan alami yang kita pijak sehari-hari tempat tumbuhnya tanaman dan pohon-pohon adalah apa?", "Tanah", listOf("Batu kali", "Aspal")),
            Triple("Gas tak terlihat di sekeliling kita yang sangat kita butuhkan untuk bernapas setiap detik adalah gas apa?", "Oksigen (udara bersih)", listOf("Asap kendaraan", "Uap belerang")),
            Triple("Alat penampung air bersih alami di bawah tanah yang digali manusia untuk mengambil air adalah apa?", "Sumur air", listOf("Bak sampah", "Parit kering")),
            Triple("Batu bara, minyak bumi, dan emas yang tersimpan di dalam perut bumi merupakan contoh sumber daya apa?", "Bahan tambang bumi", listOf("Sampah plastik", "Air hujan")),
            Triple("Hutan yang selalu hijau dan lebat sepanjang tahun karena curah hujan tinggi di Indonesia disebut apa?", "Hutan hujan tropis", listOf("Hutan gurun", "Padang rumput kering")),
            Triple("Tindakan menanam kembali pohon-pohon di lahan hutan yang gundul agar lestari disebut apa?", "Penghijauan (Reboisasi)", listOf("Penebangan liar", "Pembakaran sampah"))
        )
        for (item in nature50) {
            val wrongs = item.third.take(2)
            val options = makeOptions(item.second, wrongs[0], wrongs.getOrElse(1) { "LAIN" }, count = 3)
            questions.add(
                Question(
                    id = "umum_56_$qId",
                    category = QuizCategory.PENGETAHUAN_UMUM,
                    ageBracket = AgeBracket.AGE_5_6,
                    questionText = item.first,
                    visualEmoji = "🌱 Alam Semesta",
                    options = options,
                    correctIndex = 0,
                    explanation = "Jawaban yang benar adalah '${item.second}'.",
                    hint = "Perhatikan fenomena alam dan lingkungan di sekitar kita.",
                    difficulty = "Mudah"
                )
            )
            qId++
        } // Exactly 150 questions for Age 5-6!

        return questions
    }

    // =========================================================================
    // USIA 7-8 TAHUN (150 PERTANYAAN ALAMI)
    // =========================================================================
    private fun generateAge78(): List<Question> {
        val questions = ArrayList<Question>(150)
        var qId = 1

        // 1. Flora, Fauna & Geografi Indonesia (50 pertanyaan unik alami)
        val geoFloraFauna50 = listOf(
            Triple("Bunga raksasa tanpa daun dan batang yang berbau bangkai menyengat khas Bengkulu bernama apa?", "Rafflesia arnoldii", listOf("Bunga Melati", "Bunga Mawar", "Bunga Anggrek Bulan")),
            Triple("Pohon kayu beraroma wangi sangat harum khas dari Nusa Tenggara Timur adalah pohon apa?", "Pohon Cendana", listOf("Pohon Jati", "Pohon Pinus", "Pohon Karet")),
            Triple("Hewan mamalia berkantong khas Papua yang berbulu lebat dan memanjat pohon adalah apa?", "Kangguru Pohon", listOf("Orangutan", "Harimau", "Bekantan")),
            Triple("Monyet berhidung panjang dan besar yang hidup di hutan bakau pulau Kalimantan bernama apa?", "Bekantan", listOf("Kera ekor panjang", "Lutung Jawa", "Owa Jawa")),
            Triple("Burung endemik Pulau Sulawesi yang bertelur di dalam pasir hangat bersuhu geotermal adalah burung apa?", "Burung Maleo", listOf("Burung Jalak", "Burung Merpati", "Burung Pipit")),
            Triple("Burung berbulu putih bersih dengan lingkaran biru di sekitar matanya yang berasal dari Pulau Dewata adalah apa?", "Jalak Bali", listOf("Burung Cenderawasih", "Burung Maleo", "Burung Gagak")),
            Triple("Sapi liar khas pulau Jawa yang bertubuh kekar dan dilindungi di Taman Nasional Baluran adalah apa?", "Banteng Jawa", listOf("Kerbau liar", "Kuda liar", "Babi hutan")),
            Triple("Pulau manakah di Indonesia yang terkenal memiliki jumlah penduduk paling padat?", "Pulau Jawa", listOf("Pulau Kalimantan", "Pulau Papua", "Pulau Sulawesi")),
            Triple("Pulau terbesar di wilayah negara Indonesia yang sebagian wilayah hutannya dijuluki paru-paru dunia adalah?", "Pulau Kalimantan", listOf("Pulau Jawa", "Pulau Bali", "Pulau Lombok")),
            Triple("Danau vulkanik terbesar di Asia Tenggara yang memiliki pulau Samosir di tengahnya adalah danau apa?", "Danau Toba", listOf("Danau Maninjau", "Danau Singkarak", "Danau Poso")),
            Triple("Selat sempit yang memisahkan antara Pulau Jawa dan Pulau Sumatera adalah selat apa?", "Selat Sunda", listOf("Selat Malaka", "Selat Bali", "Selat Lombok")),
            Triple("Selat yang memisahkan antara Pulau Jawa dan Pulau Bali adalah selat apa?", "Selat Bali", listOf("Selat Sunda", "Selat Makassar", "Selat Madura")),
            Triple("Jembatan megah yang menghubungkan Kota Surabaya di Jawa Timur dengan Pulau Madura bernama jembatan apa?", "Jembatan Suramadu", listOf("Jembatan Ampera", "Jembatan Barelang", "Jembatan Barito")),
            Triple("Jembatan bersejarah di atas Sungai Musi yang menjadi ikon kebanggaan Kota Palembang adalah jembatan apa?", "Jembatan Ampera", listOf("Jembatan Suramadu", "Jembatan Kutai", "Jembatan Kahayan")),
            Triple("Sungai terpanjang di Indonesia yang mengalir melintasi Provinsi Kalimantan Barat adalah sungai apa?", "Sungai Kapuas", listOf("Sungai Mahakam", "Sungai Barito", "Sungai Musi")),
            Triple("Sungai terpanjang di Pulau Jawa yang melegenda dalam lagu gubahan Gesang adalah sungai apa?", "Bengawan Solo", listOf("Sungai Citarum", "Sungai Brantas", "Sungai Ciliwung")),
            Triple("Puncak gunung tertinggi di Indonesia yang diselimuti salju abadi di Papua bernama apa?", "Puncak Jaya (Carstensz Pyramid)", listOf("Gunung Rinjani", "Gunung Semeru", "Gunung Kerinci")),
            Triple("Gunung berapi tertinggi di Indonesia yang terletak di Provinsi Jambi adalah gunung apa?", "Gunung Kerinci", listOf("Gunung Merapi", "Gunung Bromo", "Gunung Slamet")),
            Triple("Taman Nasional laut di Sulawesi Utara yang terkenal keindahan terumbu karangnya di dunia bernama apa?", "Taman Nasional Bunaken", listOf("Raja Ampat", "Wakatobi", "Karimunjawa")),
            Triple("Kepulauan di Papua Barat yang terkenal sebagai surga penyelaman bawah laut terkaya di dunia adalah apa?", "Raja Ampat", listOf("Kepulauan Seribu", "Kepulauan Derawan", "Kepulauan Mentawai")),
            Triple("Kota di Kalimantan Barat yang tepat dilewati oleh garis lintang nol derajat khatulistiwa adalah kota apa?", "Kota Pontianak", listOf("Kota Banjarmasin", "Kota Samarinda", "Kota Balikpapan")),
            Triple("Provinsi manakah di Indonesia yang dijuluki Serambi Mekkah?", "Aceh (Nanggroe Aceh Darussalam)", listOf("Sumatera Barat", "Riau", "Banten")),
            Triple("Candi Buddha terbesar di dunia yang terletak di Magelang, Jawa Tengah bernama candi apa?", "Candi Borobudur", listOf("Candi Prambanan", "Candi Mendut", "Candi Penataran")),
            Triple("Candi Hindu terindah dan tertinggi di Indonesia yang terletak di perbatasan Yogyakarta dan Jawa Tengah adalah?", "Candi Prambanan", listOf("Candi Borobudur", "Candi Sukuh", "Candi Dieng")),
            Triple("Istana tempat kediaman resmi Sultan di Daerah Istimewa Yogyakarta disebut apa?", "Kraton Yogyakarta", listOf("Pura Mangkunegaran", "Istana Maimun", "Gedung Sate")),
            Triple("Gedung bersejarah dengan ornamen tusuk sate di puncaknya yang menjadi ikon Kota Bandung adalah gedung apa?", "Gedung Sate", listOf("Lawang Sewu", "Benteng Vredeburg", "Gedung Merdeka")),
            Triple("Bangunan peninggalan bersejarah di Kota Semarang yang terkenal memiliki banyak pintu bernama apa?", "Lawang Sewu", listOf("Gedung Sate", "Benteng Fort de Kock", "Kelenteng Sam Poo Kong")),
            Triple("Tanaman penghasil rempah cengkih dan pala yang membuat bangsa Eropa datang ke Maluku adalah tanaman apa?", "Cengkih dan Pala", listOf("Kelapa sawit", "Karet", "Teh")),
            Triple("Tanaman perkebunan yang daun pucuknya diolah menjadi minuman aromatik hangat yang menenangkan adalah apa?", "Tanaman teh", listOf("Tanaman kopi", "Tanaman tembakau", "Tanaman tebu")),
            Triple("Tanaman perkebunan yang bijinya disangrai dan ditumbuk menjadi bubuk minuman hitam berkafein adalah apa?", "Tanaman kopi", listOf("Tanaman cokelat", "Tanaman teh", "Tanaman vanili")),
            Triple("Tanaman yang menghasilkan biji kakao bahan utama pembuat cokelat batangan manis adalah tanaman apa?", "Tanaman kakao (cokelat)", listOf("Tanaman kopi", "Tanaman jarak", "Tanaman kedelai")),
            Triple("Tanaman perkebunan yang disadap getah putihnya untuk bahan baku ban kendaraan adalah tanaman apa?", "Pohon karet", listOf("Pohon pinus", "Pohon damar", "Pohon jati")),
            Triple("Tanaman yang batangnya menghasilkan cairan manis bahan utama pembuat gula pasir adalah tanaman apa?", "Tebu", listOf("Singkong", "Jagung", "Kelapa")),
            Triple("Tanaman pangan pokok sumber karbohidrat kedua setelah beras di Indonesia bagian timur adalah apa?", "Sagu", listOf("Gandum", "Kentang", "Ubi jalar")),
            Triple("Makanan tradisional khas Papua dan Maluku yang terbuat dari olahan bubur tepung sagu kenyal adalah apa?", "Papeda", listOf("Gudeg", "Rendang", "Pempek")),
            Triple("Masakan daging sapi kaya rempah asal Sumatera Barat yang dinobatkan sebagai salah satu makanan terlezat di dunia adalah?", "Rendang", listOf("Rawon", "Soto", "Gulai")),
            Triple("Makanan khas Yogyakarta yang terbuat dari nangka muda yang dimasak manis dengan santan kental adalah apa?", "Gudeg", listOf("Rendang", "Kerak telor", "Lumpia")),
            Triple("Makanan khas Kota Palembang yang terbuat dari olahan daging ikan dan sagu disajikan dengan kuah cuko asam pedas adalah?", "Pempek", listOf("Tekwan", "Otak-otak", "Batagor")),
            Triple("Sup daging berkuah hitam pekat khas Jawa Timur yang menggunakan bumbu kluwek adalah sup apa?", "Rawon", listOf("Soto Lamongan", "Bakso Malang", "Gule")),
            Triple("Kudapan tradisional khas Semarang yang berisi rebung, telur, dan daging ayam atau udang dibungkus kulit dadar adalah?", "Lumpia Semarang", listOf("Bakpia Pathok", "Bika Ambon", "Dodol Garut")),
            Triple("Kue manis berisi kacang hijau khas Yogyakarta yang sangat populer sebagai oleh-oleh adalah kue apa?", "Bakpia Pathok", listOf("Lumpia", "Wingko Babat", "Brem")),
            Triple("Makanan tradisional khas Betawi yang terbuat dari beras ketan, telur bebek, dan serundeng gurih adalah apa?", "Kerak Telor", listOf("Nasi Uduk", "Ketoprak", "Gado-gado")),
            Triple("Kain bergambar khas Indonesia yang dibuat dengan teknik canting dan malam lilin panas telah diakui UNESCO adalah apa?", "Batik Indonesia", listOf("Kain Songket", "Kain Tenun Ikat", "Kain Sutra")),
            Triple("Kota di Jawa Tengah yang terkenal dengan julukan Kota Batik dan memiliki Keraton Kasunanan adalah kota apa?", "Kota Solo (Surakarta)", listOf("Kota Semarang", "Kota Tegal", "Kota Magelang")),
            Triple("Alat musik petik tradisional khas masyarakat Pulau Rote, Nusa Tenggara Timur yang terbuat dari daun lontar adalah apa?", "Sasando", listOf("Angklung", "Kolintang", "Gamelan")),
            Triple("Alat musik tradisional Jawa Barat yang terbuat dari bambu dan dimainkan dengan cara digoyangkan adalah apa?", "Angklung", listOf("Saluang", "Sasando", "Kendang")),
            Triple("Alat musik pukul tradisional Minahasa, Sulawesi Utara yang terbuat dari bilah-bilah kayu bernada adalah apa?", "Kolintang", listOf("Gamelan", "Tifa", "Talempong")),
            Triple("Alat musik perkusi pukul berbentuk tabung kayu berselaput kulit rusa khas Papua dan Maluku adalah apa?", "Tifa", listOf("Rebana", "Bedug", "Kendang")),
            Triple("Ansambel musik tradisional Jawa, Sunda, dan Bali yang terdiri atas gong, kenong, dan saron disebut apa?", "Gamelan", listOf("Keroncong", "Orkes melayu", "Tanjidor")),
            Triple("Seni pertunjukan bayangan boneka kulit kerbau yang membawakan kisah Mahabharata dan Ramayana disebut apa?", "Wayang Kulit", listOf("Wayang Golek", "Lenong", "Ketoprak"))
        )
        for (item in geoFloraFauna50) {
            val wrongs = item.third.take(3)
            val options = makeOptions(item.second, wrongs[0], wrongs.getOrElse(1) { "LAIN" }, wrongs.getOrElse(2) { "BEDA" }, count = 4)
            questions.add(
                Question(
                    id = "umum_78_$qId",
                    category = QuizCategory.PENGETAHUAN_UMUM,
                    ageBracket = AgeBracket.AGE_7_8,
                    questionText = item.first,
                    visualEmoji = "🗺️ Nusantara Megah",
                    options = options,
                    correctIndex = 0,
                    explanation = "Jawaban yang benar adalah '${item.second}'.",
                    hint = "Ingat kekayaan alam, geografi, dan kebudayaan nusantara kita.",
                    difficulty = "Sedang"
                )
            )
            qId++
        } // 50 questions done

        // 2. Sains Dasar, Tata Surya & Bumi (50 pertanyaan unik alami)
        val scienceSpace50 = listOf(
            Triple("Bintang raksasa di pusat sistem tata surya kita yang memancarkan energi cahaya dan panas adalah apa?", "Matahari", listOf("Bumi", "Yupiter", "Bulan")),
            Triple("Planet terdekat dari matahari dalam susunan tata surya kita adalah planet apa?", "Merkurius", listOf("Venus", "Bumi", "Mars")),
            Triple("Planet kedua dari matahari yang memiliki atmosfer sangat panas dan sering dijuluki Bintang Fajar adalah apa?", "Venus", listOf("Merkurius", "Mars", "Yupiter")),
            Triple("Planet ketiga dari matahari tempat manusia dan semua makhluk hidup tinggal adalah planet apa?", "Bumi", listOf("Mars", "Venus", "Saturnus")),
            Triple("Planet keempat dari matahari yang memiliki julukan Planet Merah karena tanahnya berkarat besi adalah apa?", "Mars", listOf("Yupiter", "Merkurius", "Saturnus")),
            Triple("Planet terbesar di dalam sistem tata surya kita yang memiliki bintik merah raksasa adalah apa?", "Yupiter", listOf("Saturnus", "Uranus", "Neptunus")),
            Triple("Planet terindah yang memiliki cincin es dan debu raksasa melingkari tubuhnya adalah planet apa?", "Saturnus", listOf("Yupiter", "Uranus", "Bumi")),
            Triple("Planet dingin berwarna biru kehijauan yang berotasi menggelinding miring adalah planet apa?", "Uranus", listOf("Neptunus", "Saturnus", "Bumi")),
            Triple("Planet terjauh dan terdingin dalam susunan delapan planet tata surya saat ini adalah planet apa?", "Neptunus", listOf("Uranus", "Saturnus", "Pluto")),
            Triple("Satelit alami yang setia mengelilingi planet bumi setiap 29,5 hari sekali adalah apa?", "Bulan", listOf("Matahari", "Komet Halley", "Satelit Palapa")),
            Triple("Benda langit bongkahan es dan debu yang memiliki ekor gas menyala panjang saat mendekati matahari disebut apa?", "Komet (Bintang berekor)", listOf("Asteroid", "Meteorit", "Bintang fajar")),
            Triple("Batuan antariksa yang terbakar terang di atmosfer bumi dan sering disebut bintang jatuh adalah apa?", "Meteor", listOf("Meteorit", "Komet", "Planetoid")),
            Triple("Sisa pecahan batu antariksa yang berhasil menembus atmosfer dan mendarat jatuh di permukaan tanah bumi disebut apa?", "Meteorit", listOf("Meteor", "Asteroid", "Komet")),
            Triple("Sabuk batuan langit yang terletak di antara orbit Planet Mars dan Planet Yupiter disebut sabuk apa?", "Sabuk Asteroid", listOf("Sabuk Kuiper", "Cincin Saturnus", "Awan Oort")),
            Triple("Gerakan perputaran bumi pada poros atau sumbunya sendiri disebut gerakan apa?", "Rotasi bumi", listOf("Revolusi bumi", "Presesi", "Gravitasi")),
            Triple("Waktu yang dibutuhkan bumi untuk berotasi satu putaran penuh adalah berapa lama?", "24 jam (1 hari)", listOf("12 jam", "365 hari", "30 hari")),
            Triple("Akibat nyata yang ditimbulkan oleh gerakan rotasi bumi setiap hari adalah terjadinya peristiwa apa?", "Pergantian siang dan malam", listOf("Pergantian musim tahunan", "Pasang surut air laut", "Gerhana bulan")),
            Triple("Gerakan bumi beredar mengelilingi matahari pada garis orbitnya disebut gerakan apa?", "Revolusi bumi", listOf("Rotasi bumi", "Evolusi bumi", "Rotasi bulan")),
            Triple("Waktu yang dibutuhkan bumi untuk mengelilingi matahari satu putaran penuh adalah berapa lama?", "365 ¼ hari (1 tahun)", listOf("24 jam", "30 hari", "100 hari")),
            Triple("Tahun di mana jumlah hari dalam setahun adalah 366 hari dan bulan Februari bertambah menjadi 29 hari disebut apa?", "Tahun Kabisat", listOf("Tahun Hijriah", "Tahun Surya", "Tahun Milenium")),
            Triple("Tahun kabisat terjadi secara berulang setiap berapa tahun sekali?", "Setiap 4 tahun sekali", listOf("Setiap 2 tahun", "Setiap 5 tahun", "Setiap 10 tahun")),
            Triple("Gaya tarik bumi yang menyebabkan semua benda jatuh ke bawah ke permukaan tanah disebut gaya apa?", "Gaya gravitasi bumi", listOf("Gaya magnet", "Gaya pegas", "Gaya gesek")),
            Triple("Ilmuwan penemu teori gaya gravitasi saat mengamati buah apel jatuh dari pohon adalah siapa?", "Sir Isaac Newton", listOf("Albert Einstein", "Galileo Galilei", "Thomas Edison")),
            Triple("Ilmuwan penemu lampu pijar listrik yang menerangi rumah-rumah di seluruh dunia adalah siapa?", "Thomas Alva Edison", listOf("Alexander Graham Bell", "Nikola Tesla", "James Watt")),
            Triple("Ilmuwan penemu alat komunikasi pesawat telepon kabel pertama kali adalah siapa?", "Alexander Graham Bell", listOf("Thomas Edison", "Guglielmo Marconi", "Samuel Morse")),
            Triple("Benda yang dapat menarik benda-benda lain yang terbuat dari besi dan baja disebut apa?", "Magnet", listOf("Kayu", "Plastik", "Karet")),
            Triple("Setiap batang magnet selalu memiliki dua kutub magnet yang berlawanan yaitu kutub apa saja?", "Kutub Utara dan Kutub Selatan", listOf("Kutub Barat dan Timur", "Kutub Positif dan Negatif", "Kutub Panas dan Dingin")),
            Triple("Jika dua buah kutub magnet yang senama (misalnya Utara dengan Utara) didekatkan, keduanya akan bagaimana?", "Saling tolak-menolak", listOf("Saling tarik-menarik", "Melekat erat", "Mengeluarkan api")),
            Triple("Jika dua buah kutub magnet yang berlainan nama (Utara dengan Selatan) didekatkan, keduanya akan bagaimana?", "Saling tarik-menarik erat", listOf("Saling tolak-menolak", "Diam saja", "Patah")),
            Triple("Alat penunjuk arah mata angin yang menggunakan jarum magnetik selalu mengarah ke utara-selatan bernama apa?", "Kompas penunjuk arah", listOf("Termometer", "Barometer", "Speedometer")),
            Triple("Perubahan wujud benda dari zat cair menjadi zat padat saat suhu mendingin disebut peristiwa apa?", "Membeku", listOf("Mencair", "Menguap", "Menyublim")),
            Triple("Perubahan wujud benda dari zat padat menjadi zat cair saat dipanaskan disebut peristiwa apa?", "Mencair (Melebur)", listOf("Membeku", "Mengembun", "Mengkristal")),
            Triple("Perubahan wujud benda dari zat cair menjadi zat gas saat dipanaskan hingga mendidih disebut apa?", "Menguap", listOf("Mengembun", "Mencair", "Membeku")),
            Triple("Perubahan wujud zat gas menjadi butiran zat cair seperti uap napas pada kaca dingin disebut apa?", "Mengembun", listOf("Menguap", "Menyublim", "Membeku")),
            Triple("Perubahan wujud zat padat langsung menjadi gas tanpa mencair terlebih dahulu seperti kapur barus disebut apa?", "Menyublim", listOf("Mengkristal", "Mengembun", "Mencair")),
            Triple("Alat yang digunakan untuk mengukur derajat panas atau dinginnya suatu benda secara akurat adalah apa?", "Termometer", listOf("Barometer", "Higrometer", "Altimeter")),
            Triple("Satuan suhu yang paling umum digunakan dalam kehidupan sehari-hari di Indonesia adalah derajat apa?", "Derajat Celcius (°C)", listOf("Derajat Fahrenheit", "Kelvin", "Reamur")),
            Triple("Pada suhu berapa derajat Celcius air murni mendidih di permukaan laut pada tekanan normal?", "100° Celcius", listOf("0° Celcius", "50° Celcius", "200° Celcius")),
            Triple("Pada suhu berapa derajat Celcius air murni membeku menjadi es padat?", "0° Celcius", listOf("100° Celcius", "10° Celcius", "-50° Celcius")),
            Triple("Bahan yang mampu menghantarkan panas atau aliran listrik dengan sangat baik disebut bahan apa?", "Konduktor", listOf("Isolator", "Semikonduktor", "Radiator")),
            Triple("Bahan yang tidak dapat menghantarkan panas atau aliran listrik dengan baik disebut bahan apa?", "Isolator", listOf("Konduktor", "Transduktor", "Kolektor")),
            Triple("Manakah bahan berikut ini yang tergolong sebagai konduktor panas dan listrik yang sangat baik?", "Tembaga dan besi", listOf("Plastik dan karet", "Kayu kering dan kaca", "Kertas dan kain")),
            Triple("Manakah bahan berikut ini yang tergolong sebagai isolator listrik yang aman digunakan melapisi kabel?", "Karet dan plastik", listOf("Besi dan baja", "Tembaga dan perak", "Aluminium dan seng")),
            Triple("Gas hasil pernapasan manusia dan hewan yang diserap oleh tumbuhan hijau untuk fotosintesis adalah apa?", "Karbon dioksida (CO₂)", listOf("Oksigen (O₂)", "Nitrogen", "Helium")),
            Triple("Zat warna hijau pada daun tanaman yang berfungsi menyerap cahaya matahari saat fotosintesis disebut apa?", "Klorofil", listOf("Karotenoid", "Melanin", "Sitoplasma")),
            Triple("Proses pembuatan makanan sendiri oleh tumbuhan hijau dengan bantuan sinar matahari dan klorofil disebut apa?", "Fotosintesis", listOf("Respirasi", "Transpirasi", "Metamorfosis")),
            Triple("Hewan yang memakan tumbuhan dan biji-bijian sebagai sumber energi makanannya disebut hewan apa?", "Herbivora", listOf("Karnivora", "Omnivora", "Insektivora")),
            Triple("Hewan yang memakan daging hewan lain sebagai sumber makanan pokoknya disebut hewan apa?", "Karnivora", listOf("Herbivora", "Omnivora", "Frugivora")),
            Triple("Hewan atau manusia yang memakan segala jenis makanan baik tumbuhan maupun daging disebut apa?", "Omnivora", listOf("Herbivora", "Karnivora", "Insektivora")),
            Triple("Hewan pemakan serangga seperti cecak dan bunglon disebut hewan jenis apa?", "Insektivora", listOf("Herbivora", "Karnivora", "Frugivora"))
        )
        for (item in scienceSpace50) {
            val wrongs = item.third.take(3)
            val options = makeOptions(item.second, wrongs[0], wrongs.getOrElse(1) { "LAIN" }, wrongs.getOrElse(2) { "BEDA" }, count = 4)
            questions.add(
                Question(
                    id = "umum_78_$qId",
                    category = QuizCategory.PENGETAHUAN_UMUM,
                    ageBracket = AgeBracket.AGE_7_8,
                    questionText = item.first,
                    visualEmoji = "🚀 Sains & Angkasa",
                    options = options,
                    correctIndex = 0,
                    explanation = "Tepat! Jawaban sains yang benar adalah '${item.second}'.",
                    hint = "Ingat konsep sains dasar, tata surya, dan hukum alam.",
                    difficulty = "Sedang"
                )
            )
            qId++
        } // 100 questions done

        // 3. Nilai Kebangsaan, Pancasila & Rumah Adat Nusantara (50 pertanyaan unik alami)
        val civicsCulture50 = listOf(
            Triple("Rumah adat tradisional khas masyarakat Minangkabau Sumatera Barat dengan atap runcing seperti tanduk kerbau bernama?", "Rumah Gadang", listOf("Rumah Honai", "Rumah Joglo", "Rumah Tongkonan")),
            Triple("Rumah adat tradisional suku Toraja Sulawesi Selatan dengan atap melengkung menyerupai perahu terbalik adalah apa?", "Rumah Tongkonan", listOf("Rumah Gadang", "Rumah Joglo", "Rumah Sasak")),
            Triple("Rumah adat tradisional masyarakat Jawa yang memiliki pendapa luas dan atap bertingkat tajug bernama apa?", "Rumah Joglo", listOf("Rumah Honai", "Rumah Gadang", "Rumah Bolon")),
            Triple("Rumah adat tradisional masyarakat suku Dani di pedalaman Papua yang beratap jerami bundar adalah apa?", "Rumah Honai", listOf("Rumah Gadang", "Rumah Tongkonan", "Rumah Joglo")),
            Triple("Rumah panggung tradisional khas masyarakat suku Batak di Sumatera Utara bernama rumah apa?", "Rumah Bolon", listOf("Rumah Gadang", "Rumah Joglo", "Rumah Sasak")),
            Triple("Rumah panggung panjang khas suku Dayak di Kalimantan yang dihuni puluhan keluarga bersama-sama adalah apa?", "Rumah Betang (Panjang)", listOf("Rumah Honai", "Rumah Gadang", "Rumah Joglo")),
            Triple("Rumah adat tradisional khas masyarakat Melayu Riau yang memiliki ukiran selembayung adalah apa?", "Rumah Selaso Jatuh Kembar", listOf("Rumah Gadang", "Rumah Honai", "Rumah Joglo")),
            Triple("Pakaian adat tradisional kaum wanita Jawa dan Sunda yang terbuat dari bahan brokat renda anggun adalah apa?", "Kebaya", listOf("Baju Bodo", "Ulos", "Baju Kurung")),
            Triple("Pakaian adat tradisional khas wanita suku Bugis-Makassar di Sulawesi Selatan yang berbentuk segi empat longgar adalah?", "Baju Bodo", listOf("Kebaya", "Baju Kurung", "Ulos")),
            Triple("Kain tenun khas suku Batak Sumatera Utara yang diselempangkan di bahu pada upacara adat bernama apa?", "Kain Ulos", listOf("Kain Songket", "Kain Batik", "Kain Tapis")),
            Triple("Kain tenun mewah bersulamkan benang emas dan perak khas Palembang dan Minangkabau bernama apa?", "Kain Songket", listOf("Kain Ulos", "Kain Batik", "Kain Blacu")),
            Triple("Kain tenun tradisional Lampung yang bersulamkan benang emas bermotif kapal dan pohon hayat adalah apa?", "Kain Tapis", listOf("Kain Songket", "Kain Ulos", "Kain Lurik")),
            Triple("Kain tenun bermotif garis-garis sederhana khas masyarakat Yogyakarta dan Solo adalah kain apa?", "Kain Lurik", listOf("Kain Songket", "Kain Ulos", "Kain Sutra")),
            Triple("Senjata tradisional khas Jawa yang memiliki lekukan berbilah pamor dan dianggap pusaka leluhur adalah apa?", "Keris", listOf("Rencong", "Mandau", "Kujang")),
            Triple("Senjata tradisional khas suku Sunda Jawa Barat yang berbentuk menyerupai pulau Jawa adalah apa?", "Kujang", listOf("Keris", "Rencong", "Badik")),
            Triple("Senjata tradisional khas masyarakat Aceh yang memiliki gagang berbentuk huruf L melengkung adalah apa?", "Rencong", listOf("Keris", "Mandau", "Golok")),
            Triple("Senjata tradisional berupa pedang parang berhias bulu burung enggang khas suku Dayak Kalimantan adalah apa?", "Mandau", listOf("Keris", "Kujang", "Rencong")),
            Triple("Senjata tradisional khas masyarakat Madura yang berbentuk melengkung seperti bulan sabit adalah apa?", "Celurit", listOf("Keris", "Golok", "Kujang")),
            Triple("Tari tradisional asal Aceh yang ditarikan oleh belasan penari duduk berlutut bertepuk dada secara serempak cepat adalah?", "Tari Saman", listOf("Tari Piring", "Tari Pendet", "Tari Jaipong")),
            Triple("Tari tradisional penyambutan tamu dari Bali yang penarinya membawa cawan berisi taburan bunga semerbak adalah apa?", "Tari Pendet", listOf("Tari Kecak", "Tari Barong", "Tari Legong")),
            Triple("Tari drama tari sakral dari Bali yang dibawakan puluhan pria duduk melingkar sambil menyerukan 'cak-cak-cak' adalah apa?", "Tari Kecak", listOf("Tari Pendet", "Tari Saman", "Tari Piring")),
            Triple("Tari tradisional dari Sumatera Barat di mana penarinya memegang piring di kedua telapak tangannya tanpa jatuh adalah?", "Tari Piring", listOf("Tari Payung", "Tari Saman", "Tari Tor-tor")),
            Triple("Tari pergaulan yang lincah, dinamis, dan energik khas masyarakat Jawa Barat ciptaan Gugum Gumbira adalah apa?", "Tari Jaipong", listOf("Tari Merak", "Tari Topeng", "Tari Bedhaya")),
            Triple("Tari persembahan khas suku Batak Sumatera Utara yang ditarikan menggerakkan telapak tangan diiringi gondang adalah?", "Tari Tor-tor", listOf("Tari Piring", "Tari Saman", "Tari Zapin")),
            Triple("Kesenian tari topeng raksasa berkepala singa bermahkotakan bulu merak dari Ponorogo, Jawa Timur adalah apa?", "Reog Ponorogo", listOf("Kuda Lumping", "Barongsai", "Ondel-ondel")),
            Triple("Boneka raksasa khas masyarakat Betawi Jakarta yang diarak berpasangan di jalanan festival adalah apa?", "Ondel-ondel", listOf("Reog Ponorogo", "Wayang Golek", "Barongan")),
            Triple("Lagu daerah terkenal asal Sumatera Barat yang menceritakan tentang kerinduan pada kampung halaman adalah lagu apa?", "Kampuang Nan Jauh Di Mato", listOf("Ayam Den Lapeh", "Gundhul Pacul", "Ampar-ampar Pisang")),
            Triple("Lagu daerah jenaka berbahasa Jawa yang mengajarkan tentang sikap tidak boleh sombong saat memegang amanah adalah apa?", "Gundhul-Gundhul Pacul", listOf("Lir-ilir", "Suwe Ora Jamu", "Cublak-cublak Suweng")),
            Triple("Lagu daerah asal Kalimantan Selatan yang menceritakan tentang pisang matang yang dihurung binatang kecil adalah apa?", "Ampar-ampar Pisang", listOf("Yamko Rambe Yamko", "Apuse", "Bungong Jeumpa")),
            Triple("Lagu daerah asal Aceh yang memuji keindahan bunga cempaka kuning yang semerbak wangi adalah apa?", "Bungong Jeumpa", listOf("Ampar-ampar Pisang", "Manuk Dadali", "Soleram")),
            Triple("Lagu daerah Sunda Jawa Barat yang memuji kegagahan burung garuda lambang negara Indonesia adalah apa?", "Manuk Dadali", listOf("Bubuy Bulan", "Tokecang", "Es Lilin")),
            Triple("Lagu daerah asal Papua yang menceritakan perpisahan cucu yang berpamitan kepada kakek dan neneknya ke Teluk Doreri adalah?", "Apuse", listOf("Yamko Rambe Yamko", "Sajojo", "O Ina Ni Keke")),
            Triple("Lagu daerah ceria bertempo gembira asal Maluku yang dinyanyikan saat berlayar mengarungi lautan adalah apa?", "Rasa Sayange", listOf("Burung Kakatua", "Kole-kole", "Ayo Mama")),
            Triple("Sila pertama Pancasila mengajarkan kepada seluruh rakyat Indonesia untuk memiliki sikap apa?", "Percaya dan bertakwa kepada Tuhan Yang Maha Esa", listOf("Sombong pada orang lain", "Memaksakan kehendak", "Menolak beribadah")),
            Triple("Sikap saling menghormati antarumat beragama yang sedang menjalankan ibadah keagamaannya disebut sikap apa?", "Toleransi beragama", listOf("Diskriminasi", "Egoisme", "Fanatisme")),
            Triple("Sila kedua Pancasila yang berlambangkan rantai emas mengajarkan nilai luhur apa?", "Kemanusiaan yang adil dan beradab", listOf("Ketuhanan", "Persatuan", "Keadilan sosial")),
            Triple("Sikap suka menolong kawan yang sedang tertimpa kesusahan merupakan wujud pengamalan Pancasila sila ke berapa?", "Sila kedua", listOf("Sila pertama", "Sila keempat", "Sila kelima")),
            Triple("Sila ketiga Pancasila yang berlambangkan pohon beringin memiliki bunyi rumusan apa?", "Persatuan Indonesia", listOf("Ketuhanan Yang Maha Esa", "Keadilan Sosial", "Kemanusiaan")),
            Triple("Mengutamakan kepentingan bangsa dan negara di atas kepentingan pribadi dan golongan mencerminkan sila ke berapa?", "Sila ketiga", listOf("Sila kedua", "Sila pertama", "Sila kelima")),
            Triple("Sila keempat Pancasila yang berlambangkan kepala banteng mengajarkan cara mengambil keputusan bersama melalui apa?", "Musyawarah untuk mufakat", listOf("Pemaksaan suara terbanyak", "Kekerasan fisik", "Menang sendiri")),
            Triple("Sikap lapang dada menerima hasil keputusan bersama dalam musyawarah kelas mencerminkan sila ke berapa?", "Sila keempat", listOf("Sila ketiga", "Sila kedua", "Sila pertama")),
            Triple("Sila kelima Pancasila yang berlambangkan padi dan kapas memiliki bunyi rumusan apa?", "Keadilan sosial bagi seluruh rakyat Indonesia", listOf("Persatuan Indonesia", "Ketuhanan Yang Maha Esa", "Kemanusiaan")),
            Triple("Sikap hidup hemat tidak boros dan suka berbagi secara adil kepada sesama mencerminkan sila ke berapa?", "Sila kelima", listOf("Sila pertama", "Sila ketiga", "Sila keempat")),
            Triple("Kegiatan bekerja bersama-sama secara sukarela demi kepentingan bersama di lingkungan rukun tetangga disebut apa?", "Gotong royong", listOf("Jual beli pasar", "Lomba individu", "Pamer kekayaan")),
            Triple("Sumpah pemuda yang diikrarkan oleh para pemuda nusantara pada tanggal 28 Oktober 1928 menegaskan persatuan apa?", "Satu nusa, satu bangsa, dan satu bahasa Indonesia", listOf("Satu partai politik", "Satu agama", "Satu pulau")),
            Triple("Pahlawan nasional pelopor emansipasi kebangkitan kaum wanita Indonesia kelahiran Jepara adalah siapa?", "R.A. Kartini", listOf("Cut Nyak Dien", "Dewi Sartika", "Martha Christina Tiahahu")),
            Triple("Pahlawan pendidikan nasional yang mendirikan perguruan Taman Siswa dan mencetuskan 'Tut Wuri Handayani' adalah siapa?", "Ki Hajar Dewantara", listOf("Dr. Soetomo", "Bung Tomo", "K.H. Ahmad Dahlan")),
            Triple("Hari Pendidikan Nasional di Indonesia diperingati setiap tanggal berapa untuk menghormati Ki Hajar Dewantara?", "2 Mei", listOf("21 April", "10 November", "28 Oktober")),
            Triple("Hari Pahlawan di Indonesia diperingati setiap tanggal berapa untuk mengenang pertempuran Surabaya 1945?", "10 November", listOf("17 Agustus", "1 Juni", "5 Oktober")),
            Triple("Hari lahirnya Pancasila dasar negara Indonesia diperingati secara nasional setiap tanggal berapa?", "1 Juni", listOf("17 Agustus", "18 Agustus", "1 Oktober"))
        )
        for (item in civicsCulture50) {
            val wrongs = item.third.take(3)
            val options = makeOptions(item.second, wrongs[0], wrongs.getOrElse(1) { "LAIN" }, wrongs.getOrElse(2) { "BEDA" }, count = 4)
            questions.add(
                Question(
                    id = "umum_78_$qId",
                    category = QuizCategory.PENGETAHUAN_UMUM,
                    ageBracket = AgeBracket.AGE_7_8,
                    questionText = item.first,
                    visualEmoji = "🦅 Nilai Kebangsaan",
                    options = options,
                    correctIndex = 0,
                    explanation = "Jawaban yang benar adalah '${item.second}'.",
                    hint = "Ingat nilai-nilai Pancasila, kebudayaan daerah, dan sejarah nasional.",
                    difficulty = "Sedang"
                )
            )
            qId++
        } // Exactly 150 questions for Age 7-8!

        return questions
    }

    // =========================================================================
    // USIA 9-10 TAHUN (150 PERTANYAAN ALAMI)
    // =========================================================================
    private fun generateAge910(): List<Question> {
        val questions = ArrayList<Question>(150)
        var qId = 1

        // 1. Sains Alam, Ekosistem, Bumi & Fisika Lanjut (50 pertanyaan unik alami)
        val scienceAdvanced50 = listOf(
            Triple("Lapisan udara yang menyelimuti dan melindungi bumi dari radiasi berbahaya matahari dan meteor disebut apa?", "Atmosfer bumi", listOf("Litosfer", "Hidrosfer", "Biosfer")),
            Triple("Lapisan atmosfer terbawah tempat terjadinya fenomena cuaca seperti hujan, awan, dan angin adalah lapisan apa?", "Troposfer", listOf("Stratosfer", "Mesosfer", "Termosfer")),
            Triple("Lapisan atmosfer yang mengandung lapisan gas ozon (O₃) penyerap sinar ultraviolet matahari adalah lapisan apa?", "Stratosfer", listOf("Troposfer", "Mesosfer", "Eksosfer")),
            Triple("Lapisan atmosfer bersuhu sangat dingin tempat sebagian besar meteor terbakar habis adalah lapisan apa?", "Mesosfer", listOf("Troposfer", "Stratosfer", "Termosfer")),
            Triple("Lapisan atmosfer terluar yang berbatasan langsung dengan ruang hampa antariksa adalah lapisan apa?", "Eksosfer", listOf("Mesosfer", "Troposfer", "Stratosfer")),
            Triple("Peristiwa gerhana matahari terjadi ketika posisi benda langit berada dalam satu garis lurus dengan susunan apa?", "Matahari - Bulan - Bumi", listOf("Matahari - Bumi - Bulan", "Bulan - Matahari - Bumi", "Bumi - Mars - Matahari")),
            Triple("Peristiwa gerhana bulan terjadi ketika posisi benda langit berada dalam satu garis lurus dengan susunan apa?", "Matahari - Bumi - Bulan", listOf("Matahari - Bulan - Bumi", "Bulan - Matahari - Bumi", "Bumi - Matahari - Venus")),
            Triple("Gerhana matahari total hanya terjadi pada fase bulan apa dalam penanggalan lunar?", "Bulan baru (Bulan mati)", listOf("Bulan purnama", "Bulan sabit", "Bulan separuh")),
            Triple("Gerhana bulan total hanya dapat terjadi pada saat fase bulan apa?", "Bulan purnama penuh", listOf("Bulan mati", "Bulan sabit", "Bulan baru")),
            Triple("Peristiwa naik turunnya permukaan air laut secara periodik terutama dipengaruhi oleh gaya gravitasi apa?", "Gravitasi bulan dan matahari", listOf("Gravitasi planet mars", "Angin badai saja", "Rotasi bumi saja")),
            Triple("Peristiwa pasang air laut tertinggi yang terjadi saat bulan purnama atau bulan baru disebut pasang apa?", "Pasang purnama (spring tide)", listOf("Pasang perbani (neap tide)", "Pasang surut biasa", "Pasang tsunami")),
            Triple("Peristiwa pasang air laut terendah yang terjadi saat posisi bulan membentuk sudut siku-siku terhadap bumi disebut apa?", "Pasang perbani (neap tide)", listOf("Pasang purnama", "Pasang surut ekstrem", "Pasang badai")),
            Triple("Perambatan panas yang terjadi melalui zat padat tanpa disertai perpindahan partikel zatnya disebut apa?", "Konduksi panas", listOf("Konveksi", "Radiasi", "Evaporasi")),
            Triple("Perambatan panas yang disertai dengan perpindahan partikel zat perantaranya (seperti merebus air) disebut apa?", "Konveksi panas", listOf("Konduksi", "Radiasi", "Kondensasi")),
            Triple("Perambatan panas yang terjadi secara langsung melalui gelombang elektromagnetik tanpa zat perantara disebut apa?", "Radiasi panas", listOf("Konduksi", "Konveksi", "Sublimasi")),
            Triple("Pancaran panas matahari yang sampai dan menghangatkan permukaan planet bumi merambat melalui cara apa?", "Radiasi", listOf("Konduksi", "Konveksi", "Transpirasi")),
            Triple("Sendok logam yang terasa panas saat digunakan mengaduk teh manis panas merupakan contoh perambatan panas secara apa?", "Konduksi", listOf("Konveksi", "Radiasi", "Kondensasi")),
            Triple("Terjadinya angin darat dan angin laut di kawasan pesisir pantai merupakan contoh perpindahan panas secara apa?", "Konveksi alami", listOf("Konduksi", "Radiasi", "Kondensasi")),
            Triple("Angin yang bertiup dari daratan menuju ke lautan pada malam hari dan dimanfaatkan nelayan berangkat melaut adalah apa?", "Angin darat", listOf("Angin laut", "Angin gunung", "Angin lembah")),
            Triple("Angin yang bertiup dari lautan menuju ke daratan pada siang hari dan dimanfaatkan nelayan pulang melaut adalah apa?", "Angin laut", listOf("Angin darat", "Angin fohn", "Angin siklon")),
            Triple("Organ pernapasan utama pada manusia tempat terjadinya pertukaran gas oksigen dan karbon dioksida adalah apa?", "Paru-paru (Alveolus)", listOf("Jantung", "Hati", "Lambung")),
            Triple("Kantong udara mikroskopis di ujung bronkiolus paru-paru tempat difusi gas berlangsung disebut apa?", "Alveolus", listOf("Bronkus", "Trakea", "Faring")),
            Triple("Organ tubuh berotot seukuran kepalan tangan yang berfungsi memompa darah ke seluruh tubuh manusia adalah apa?", "Jantung", listOf("Paru-paru", "Ginjal", "Hati")),
            Triple("Jantung manusia terdiri dari empat ruangan utama yaitu dua serambi dan dua apa?", "Dua bilik (Ventrikel)", listOf("Dua katup", "Dua pembuluh", "Dua arteri")),
            Triple("Pembuluh darah yang mengalirkan darah keluar dari jantung kaya oksigen menuju seluruh tubuh disebut pembuluh apa?", "Pembuluh nadi (Arteri)", listOf("Pembuluh balik (Vena)", "Pembuluh kapiler", "Aorta saja")),
            Triple("Pembuluh darah yang membawa darah kotor kaya karbon dioksida kembali menuju ke jantung disebut pembuluh apa?", "Pembuluh balik (Vena)", listOf("Pembuluh nadi (Arteri)", "Pembuluh kapiler", "Aorta")),
            Triple("Sel darah dalam tubuh manusia yang bertugas mengikat dan mengedarkan gas oksigen dengan bantuan hemoglobin adalah apa?", "Sel darah merah (Eritrosit)", listOf("Sel darah putih (Leukosit)", "Keping darah (Trombosit)", "Plasma darah")),
            Triple("Sel darah yang berfungsi sebagai sistem pertahanan tubuh membasmi kuman, bakteri, dan virus penyakit adalah apa?", "Sel darah putih (Leukosit)", listOf("Sel darah merah", "Trombosit", "Hemoglobin")),
            Triple("Komponen darah yang berperan penting dalam proses pembekuan darah dan menutup luka saat tergores adalah apa?", "Keping darah (Trombosit)", listOf("Eritrosit", "Leukosit", "Plasma")),
            Triple("Organ pencernaan manusia yang menghasilkan asam klorida (HCl) untuk membunuh kuman pada makanan adalah apa?", "Lambung", listOf("Usus halus", "Mulut", "Kerongkongan")),
            Triple("Bagian saluran pencernaan terpanjang tempat penyerapan sari-sari makanan ke dalam aliran darah adalah apa?", "Usus halus (Intestinum)", listOf("Usus besar", "Lambung", "Kerongkongan")),
            Triple("Bagian usus yang bertugas menyerap air dari sisa makanan dan membentuk tinja dibantu bakteri E. coli adalah apa?", "Usus besar (Kolon)", listOf("Usus halus", "Lambung", "Pankreas")),
            Triple("Organ ekskresi penyaring darah yang membuang sisa metabolisme tubuh dalam bentuk cairan urine adalah apa?", "Ginjal", listOf("Hati", "Paru-paru", "Jantung")),
            Triple("Organ tubuh terbesar manusia yang mengeluarkan sisa keringat dan mengatur suhu tubuh adalah apa?", "Kulit tubuh", listOf("Paru-paru", "Hati", "Ginjal")),
            Triple("Organ dalam tubuh yang menetralkan racun dan menghasilkan cairan empedu untuk mencerna lemak adalah apa?", "Hati (Hepar)", listOf("Lambung", "Pankreas", "Limpa")),
            Triple("Tingkatan trofik pertama dalam rantai makanan yang mampu menghasilkan makanannya sendiri disebut apa?", "Produsen (Tumbuhan hijau)", listOf("Konsumen tingkat I", "Konsumen tingkat II", "Pengurai (Dekomposer)")),
            Triple("Hewan herbivora yang memakan produsen secara langsung dalam rantai makanan menduduki tingkat apa?", "Konsumen tingkat I (Primer)", listOf("Produsen", "Konsumen sekunder", "Konsumen puncak")),
            Triple("Organisme seperti bakteri pembusuk dan jamur yang menguraikan sisa bangkai makhluk hidup menjadi zat hara tanah disebut apa?", "Pengurai (Dekomposer)", listOf("Produsen", "Konsumen tersier", "Parasit")),
            Triple("Hubungan timbal balik antara dua makhluk hidup berbeda di mana kedua belah pihak sama-sama diuntungkan disebut simbiosis apa?", "Simbiosis Mutualisme", listOf("Simbiosis Komensalisme", "Simbiosis Parasitisme", "Simbiosis Netralisme")),
            Triple("Hubungan antara lebah madu dengan bunga yang mekar di taman merupakan contoh dari simbiosis apa?", "Simbiosis Mutualisme", listOf("Simbiosis Komensalisme", "Simbiosis Parasitisme", "Simbiosis Predasi")),
            Triple("Hubungan antara tanaman anggrek yang menempel di dahan pohon mangga tanpa merugikan pohon disebut simbiosis apa?", "Simbiosis Komensalisme", listOf("Simbiosis Mutualisme", "Simbiosis Parasitisme", "Simbiosis Kompetisi")),
            Triple("Hubungan antara benalu yang menyerap sari makanan dari pohon inangnya hingga pohon merana disebut simbiosis apa?", "Simbiosis Parasitisme", listOf("Simbiosis Mutualisme", "Simbiosis Komensalisme", "Simbiosis Netralisme")),
            Triple("Hubungan antara kutu yang menghisap darah kucing peliharaan merupakan contoh simbiosis apa?", "Simbiosis Parasitisme", listOf("Simbiosis Mutualisme", "Simbiosis Komensalisme", "Simbiosis Amensalisme")),
            Triple("Energi yang tersimpan pada benda karena posisi atau ketinggiannya di atas tanah disebut energi apa?", "Energi potensial gravitasi", listOf("Energi kinetik", "Energi kimia", "Energi panas")),
            Triple("Energi yang dimiliki oleh benda yang sedang bergerak dengan kecepatan tertentu disebut energi apa?", "Energi kinetik (Gerak)", listOf("Energi potensial", "Energi nuklir", "Energi listrik")),
            Triple("Hukum kekekalan energi menyatakan bahwa energi tidak dapat diciptakan dan tidak dapat dimusnahkan, melainkan hanya dapat apa?", "Diubah dari satu bentuk ke bentuk lain", listOf("Dihilangkan selamanya", "Dibuat dari ketiadaan", "Dibekukan")),
            Triple("Perubahan energi yang terjadi pada setrika listrik saat dicolokkan ke sumber listrik adalah apa?", "Energi listrik menjadi energi panas", listOf("Energi listrik menjadi cahaya saja", "Energi kimia menjadi gerak", "Energi panas menjadi bunyi")),
            Triple("Perubahan energi yang terjadi pada kipas angin listrik saat dinyalakan adalah apa?", "Energi listrik menjadi energi gerak", listOf("Energi listrik menjadi kimia", "Energi gerak menjadi listrik", "Energi panas menjadi cahaya")),
            Triple("Alat panel surya (solar cell) mengubah energi cahaya matahari menjadi energi apa?", "Energi listrik", listOf("Energi gerak", "Energi bunyi", "Energi nuklir")),
            Triple("Pembangkit Listrik Tenaga Air (PLTA) memanfaatkan aliran air bendungan yang deras untuk memutar apa?", "Turbin generator listrik", listOf("Kompresor angin", "Pemanas air", "Termometer raksasa"))
        )
        for (item in scienceAdvanced50) {
            val wrongs = item.third.take(3)
            val options = makeOptions(item.second, wrongs[0], wrongs.getOrElse(1) { "LAIN" }, wrongs.getOrElse(2) { "BEDA" }, count = 4)
            questions.add(
                Question(
                    id = "umum_910_$qId",
                    category = QuizCategory.PENGETAHUAN_UMUM,
                    ageBracket = AgeBracket.AGE_9_10,
                    questionText = item.first,
                    visualEmoji = "🔬 Sains Terpadu",
                    options = options,
                    correctIndex = 0,
                    explanation = "Jawaban sains yang benar adalah '${item.second}'.",
                    hint = "Pikirkan konsep biologi, fisika, tata surya, dan ekologi.",
                    difficulty = "Tantangan"
                )
            )
            qId++
        } // 50 questions done

        // 2. Sejarah Indonesia, Perjuangan Kemerdekaan & Tokoh Bangsa (50 pertanyaan unik alami)
        val historyIndonesia50 = listOf(
            Triple("Kerajaan Hindu tertua di nusantara yang dibuktikan dengan penemuan prasasti Yupa di Muara Kaman Kalimantan Timur adalah?", "Kerajaan Kutai Martapura", listOf("Kerajaan Tarumanegara", "Kerajaan Majapahit", "Kerajaan Sriwijaya")),
            Triple("Raja terkenal Kerajaan Kutai yang menyedekahkan 20.000 ekor sapi kepada para brahmana adalah siapa?", "Raja Mulawarman", listOf("Raja Kudungga", "Raja Aswawarman", "Raja Purnawarman")),
            Triple("Kerajaan Hindu tertua di Pulau Jawa yang berpusat di wilayah Jawa Barat dan dipimpin Raja Purnawarman adalah apa?", "Kerajaan Tarumanegara", listOf("Kerajaan Pajajaran", "Kerajaan Mataram Kuno", "Kerajaan Kediri")),
            Triple("Kerajaan Buddha maritim terbesar di nusantara yang berpusat di Palembang dan menguasai jalur Selat Malaka adalah apa?", "Kerajaan Sriwijaya", listOf("Kerajaan Majapahit", "Kerajaan Singasari", "Kerajaan Samudera Pasai")),
            Triple("Kerajaan maritim Hindu-Buddha terbesar di nusantara yang berhasil menyatukan kepulauan nusantara di bawah Hayam Wuruk adalah?", "Kerajaan Majapahit", listOf("Kerajaan Sriwijaya", "Kerajaan Demak", "Kerajaan Pajang")),
            Triple("Mahapatih Kerajaan Majapahit yang mengucapkan Sumpah Palapa untuk menyatukan seluruh wilayah nusantara adalah siapa?", "Gajah Mada", listOf("Hayam Wuruk", "Kertanegara", "Raden Wijaya")),
            Triple("Raja pendiri Kerajaan Majapahit yang membuka hutan Tarik berbuah maja pahit pada tahun 1293 adalah siapa?", "Raden Wijaya (Kertarajasa)", listOf("Gajah Mada", "Hayam Wuruk", "Ken Arok")),
            Triple("Kitab sastra kuno karangan Mpu Tantular yang memuat semboyan persatuan 'Bhinneka Tunggal Ika' adalah kitab apa?", "Kitab Sutasoma", listOf("Kitab Negarakertagama", "Kitab Bharatayuddha", "Kitab Pararaton")),
            Triple("Kitab sejarah Kerajaan Majapahit karangan Mpu Prapanca yang menceritakan masa kejayaan Raja Hayam Wuruk adalah apa?", "Kitab Negarakertagama", listOf("Kitab Sutasoma", "Kitab Smaradahana", "Kitab Arjuna Wiwaha")),
            Triple("Kerajaan Islam pertama di Indonesia yang terletak di wilayah pesisir utara Aceh pada abad ke-13 adalah apa?", "Kerajaan Samudera Pasai", listOf("Kesultanan Aceh", "Kesultanan Demak", "Kesultanan Banten")),
            Triple("Raja pendiri sekaligus sultan pertama dari Kerajaan Samudera Pasai yang makam nisannya bertarikh 1297 adalah siapa?", "Sultan Malik as-Saleh (Marah Silu)", listOf("Sultan Iskandar Muda", "Raden Patah", "Sultan Hasanuddin")),
            Triple("Kerajaan Islam pertama di Pulau Jawa yang didirikan oleh Raden Patah dengan bantuan Wali Songo adalah kerajaan apa?", "Kesultanan Demak", listOf("Kesultanan Mataram Islam", "Kesultanan Cirebon", "Kesultanan Banten")),
            Triple("Masjid kuno beratap tumpang tiga yang didirikan oleh Wali Songo di Demak Jawa Tengah bernama masjid apa?", "Masjid Agung Demak", listOf("Masjid Menara Kudus", "Masjid Baiturrahman", "Masjid Istiqlal")),
            Triple("Sultan terbesar dari Kesultanan Aceh Darussalam yang membawa Aceh mencapai puncak kejayaan maritim adalah siapa?", "Sultan Iskandar Muda", listOf("Sultan Ali Mughayat Syah", "Sultan Hasanuddin", "Sultan Baabullah")),
            Triple("Raja dari Kesultanan Gowa-Tallo di Sulawesi Selatan yang dijuluki 'Ayam Jantan dari Timur' karena gigih melawan VOC adalah?", "Sultan Hasanuddin", listOf("Sultan Baabullah", "Pangeran Antasari", "Pattimura")),
            Triple("Pahlawan nasional dari Maluku yang memimpin perlawanan rakyat melawan monopoli Belanda di Benteng Duurstede Saparua adalah?", "Kapitan Pattimura (Thomas Matulessy)", listOf("Sultan Nuku", "Sultan Baabullah", "Silas Papare")),
            Triple("Pangeran bangsawan dari Yogyakarta yang memimpin Perang Jawa (1825–1830) dengan taktik perang gerilya melawan Belanda adalah?", "Pangeran Diponegoro", listOf("Pangeran Antasari", "Tuanku Imam Bonjol", "Sultan Agung")),
            Triple("Pemimpin perjuangan kaum Padri dalam Perang Padri di Sumatera Barat melawan penjajah Belanda adalah siapa?", "Tuanku Imam Bonjol", listOf("Teuku Umar", "Pangeran Diponegoro", "Cut Nyak Dien")),
            Triple("Srikandi pejuang wanita perkasa dari tanah rencong Aceh yang terus bergerilya melawan Belanda meski telah lanjut usia adalah?", "Cut Nyak Dien", listOf("R.A. Kartini", "Cut Meutia", "Dewi Sartika")),
            Triple("Pahlawan wanita asal Maluku yang gugur berjuang di atas kapal perang Belanda saat berusia masih belia 17 tahun adalah siapa?", "Martha Christina Tiahahu", listOf("Cut Nyak Dien", "Maria Walanda Maramis", "Nyi Ageng Serang")),
            Triple("Organisasi pergerakan pemuda modern pertama di Indonesia yang didirikan pada tanggal 20 Mei 1908 oleh dr. Soetomo adalah?", "Budi Utomo", listOf("Sarekat Islam", "Indische Partij", "Perhimpunan Indonesia")),
            Triple("Tanggal berdirinya Budi Utomo pada 20 Mei 1908 kini diperingati secara nasional di Indonesia sebagai hari apa?", "Hari Kebangkitan Nasional", listOf("Hari Pahlawan", "Hari Sumpah Pemuda", "Hari Lahir Pancasila")),
            Triple("Kongres Pemuda II pada tanggal 27–28 Oktober 1928 di Jakarta melahirkan ikrar bersejarah bangsa yang dikenal sebagai apa?", "Sumpah Pemuda", listOf("Proklamasi Kemerdekaan", "Piagam Jakarta", "Dekrit Presiden")),
            Triple("Lagu kebangsaan 'Indonesia Raya' ciptaan W.R. Soepratman pertama kali dikumandangkan di depan umum pada peristiwa apa?", "Kongres Pemuda II (Sumpah Pemuda 1928)", listOf("Proklamasi 17 Agustus 1945", "Sidang BPUPKI", "Dekrit Presiden 1959")),
            Triple("Organisasi yang dibentuk Jepang untuk menyelidiki persiapan kemerdekaan Indonesia (BPUPKI) dipimpin oleh siapa?", "Dr. K.R.T. Radjiman Wedyodiningrat", listOf("Ir. Soekarno", "Drs. Mohammad Hatta", "Mr. Soepomo")),
            Triple("Peristiwa pengamanan Soekarno dan Hatta ke sebuah kota kecil di Jawa Barat oleh golongan pemuda menjelang proklamasi disebut apa?", "Peristiwa Rengasdengklok", listOf("Peristiwa Bandung Lautan Api", "Peristiwa 10 November", "Serangan Umum 1 Maret")),
            Triple("Di rumah siapakah naskah teks Proklamasi Kemerdekaan Indonesia dirumuskan pada dini hari tanggal 17 Agustus 1945?", "Laksamana Tadashi Maeda", listOf("Jenderal Terauchi", "Soekarno", "Mohammad Hatta")),
            Triple("Siapakah tokoh pemuda yang mengetik naskah proklamasi kemerdekaan setelah disetujui bersama?", "Sayuti Melik", listOf("Sukarni", "B.M. Diah", "Chaerul Saleh")),
            Triple("Siapakah tokoh yang menjahit Bendera Pusaka Sang Saka Merah Putih yang dikibarkan saat proklamasi 17 Agustus 1945?", "Ibu Fatmawati Soekarno", listOf("R.A. Kartini", "Ibu Tien Soeharto", "Cut Nyak Dien")),
            Triple("Di manakah naskah proklamasi kemerdekaan Indonesia dibacakan oleh Bung Karno pada tanggal 17 Agustus 1945 pukul 10.00 pagi?", "Jalan Pegangsaan Timur No. 56 Jakarta", listOf("Lapangan Ikada Jakarta", "Istana Merdeka", "Gedung BPUPKI")),
            Triple("Lembaga yang dibentuk setelah proklamasi untuk mengesahkan UUD 1945 dan memilih Presiden serta Wakil Presiden pertama adalah?", "PPKI (Panitia Persiapan Kemerdekaan Indonesia)", listOf("BPUPKI", "KNIP", "MPRS")),
            Triple("Panglima Besar Tentara Nasional Indonesia pertama yang memimpin perang gerilya melawan agresi militer Belanda sambil ditandu adalah?", "Jenderal Soedirman", listOf("Jenderal Ahmad Yani", "Jenderal Soeharto", "Jenderal A.H. Nasution")),
            Triple("Tokoh pemuda yang membakar semangat arek-arek Suroboyo melalui siaran radio dalam pertempuran 10 November 1945 adalah siapa?", "Bung Tomo (Sutomo)", listOf("Gubernur Suryo", "Moestopo", "Supriyadi")),
            Triple("Peristiwa pembumihangusan kota oleh para pejuang Bandung agar fasilitas kota tidak digunakan tentara Sekutu dikenal sebagai?", "Bandung Lautan Api", listOf("Palagan Ambarawa", "Medan Area", "Puputan Margarana")),
            Triple("Pahlawan muda yang gugur meledakkan gudang mesiu Sekutu di Dayeuhkolot dalam peristiwa Bandung Lautan Api adalah siapa?", "Mohammad Toha", listOf("Bung Tomo", "Halim Perdanakusuma", "Robert Wolter Mongisidi")),
            Triple("Pertempuran sengit di Bali yang dipimpin I Gusti Ngurah Rai melawan Belanda hingga titik darah penghabisan dikenal sebagai?", "Puputan Margarana", listOf("Perang Puputan Klungkung", "Perang Kusamba", "Perang Jagaraga")),
            Triple("Konferensi tingkat tinggi internasional yang diselenggarakan di Bandung pada tahun 1955 dihadiri pemimpin Asia dan Afrika adalah?", "Konferensi Asia Afrika (KAA)", listOf("KTT Non-Blok", "KTT ASEAN", "KTT G20")),
            Triple("Perjanjian internasional di Den Haag Belanda tahun 1949 di mana Belanda akhirnya mengakui kedaulatan Indonesia adalah apa?", "Konferensi Meja Bundar (KMB)", listOf("Perjanjian Linggarjati", "Perjanjian Renville", "Perjanjian Roem-Royen")),
            Triple("Organisasi persatuan kerja sama regional negara-negara di kawasan Asia Tenggara yang didirikan pada 8 Agustus 1967 adalah apa?", "ASEAN", listOf("PBB", "APEC", "OPEC")),
            Triple("Salah satu tokoh pendiri ASEAN yang mewakili negara Indonesia menandatangani Deklarasi Bangkok 1967 adalah siapa?", "Adam Malik", listOf("Ali Alatas", "Mochtar Kusumaatmadja", "Soeharto")),
            Triple("Organisasi perdamaian antarbangsa terbesar di dunia yang didirikan pada tahun 1945 setelah Perang Dunia II berakhir adalah apa?", "PBB (Perserikatan Bangsa-Bangsa)", listOf("NATO", "UNESCO", "WHO")),
            Triple("Badan khusus PBB yang mengurusi bidang pendidikan, keilmuan, dan kebudayaan internasional bermarkas di Paris bernama apa?", "UNESCO", listOf("UNICEF", "WHO", "UNHCR")),
            Triple("Badan khusus PBB yang mengurusi dana bantuan darurat dan kesejahteraan anak-anak sedunia adalah apa?", "UNICEF", listOf("UNESCO", "WHO", "FAO")),
            Triple("Organisasi kesehatan dunia di bawah PBB yang bermarkas di Jenewa Swiss adalah apa?", "WHO (World Health Organization)", listOf("ILO", "WTO", "IMF")),
            Triple("Badan PBB yang menangani urusan pangan dan pertanian dunia yang bermarkas di Roma Italia adalah apa?", "FAO (Food and Agriculture Organization)", listOf("UNIDO", "WFP", "UNDP")),
            Triple("Presiden Republik Indonesia ketiga yang dikenal sebagai teknokrat jenius penerbangan pembuat pesawat N-250 Gatotkaca adalah?", "B.J. Habibie", listOf("Abdurrahman Wahid", "Megawati Soekarnoputri", "Susilo Bambang Yudhoyono")),
            Triple("Presiden wanita pertama di Republik Indonesia yang menjabat sebagai Presiden RI kelima adalah siapa?", "Megawati Soekarnoputri", listOf("Fatmawati", "Kartini", "Sri Mulyani")),
            Triple("Masa pemerintahan demokrasi di Indonesia sejak bergulirnya reformasi nasional tahun 1998 disebut sebagai era apa?", "Era Reformasi", listOf("Era Orde Baru", "Era Orde Lama", "Era Kolonial")),
            Triple("Pemilihan umum langsung oleh rakyat untuk memilih Presiden dan Wakil Presiden pertama kali di Indonesia berlangsung pada tahun?", "Tahun 2004", listOf("Tahun 1999", "Tahun 1997", "Tahun 2009")),
            Triple("Lembaga tinggi negara di Indonesia yang berwenang mengubah dan menetapkan Undang-Undang Dasar adalah lembaga apa?", "MPR (Majelis Permusyawaratan Rakyat)", listOf("DPR", "Mahkamah Agung", "Presiden"))
        )
        for (item in historyIndonesia50) {
            val wrongs = item.third.take(3)
            val options = makeOptions(item.second, wrongs[0], wrongs.getOrElse(1) { "LAIN" }, wrongs.getOrElse(2) { "BEDA" }, count = 4)
            questions.add(
                Question(
                    id = "umum_910_$qId",
                    category = QuizCategory.PENGETAHUAN_UMUM,
                    ageBracket = AgeBracket.AGE_9_10,
                    questionText = item.first,
                    visualEmoji = "🏛️ Sejarah Bangsa",
                    options = options,
                    correctIndex = 0,
                    explanation = "Jawaban sejarah yang tepat adalah '${item.second}'.",
                    hint = "Ingat peristiwa, kronologi, dan peran pahlawan perjuangan bangsa.",
                    difficulty = "Tantangan"
                )
            )
            qId++
        } // 100 questions done

        // 3. Wawasan Geografi Dunia, Benua & Budaya Global (50 pertanyaan unik alami)
        val worldGeoCulture50 = listOf(
            Triple("Berapa jumlah benua utama yang diakui secara geografis di permukaan bumi?", "7 Benua", listOf("5 Benua", "6 Benua", "8 Benua")),
            Triple("Benua terluas di dunia yang juga memiliki jumlah penduduk terbanyak di planet bumi adalah benua apa?", "Benua Asia", listOf("Benua Afrika", "Benua Amerika", "Benua Eropa")),
            Triple("Benua yang dijuluki Benua Hitam dan dilewati oleh garis khatulistiwa di bagian tengahnya adalah benua apa?", "Benua Afrika", listOf("Benua Asia", "Benua Australia", "Benua Eropa")),
            Triple("Benua terkecil di dunia yang seluruh wilayah daratannya hanya terdiri atas satu negara persemakmuran adalah apa?", "Benua Australia", listOf("Benua Eropa", "Benua Antartika", "Benua Amerika Selatan")),
            Triple("Benua paling selatan di bumi yang hampir seluruh daratannya tertutup lapisan es abadi dan tanpa penduduk tetap adalah apa?", "Benua Antartika", listOf("Benua Artik", "Benua Australia", "Benua Eropa")),
            Triple("Samudra terluas dan terdalam di planet bumi yang memisahkan Benua Asia dan Benua Amerika adalah samudra apa?", "Samudra Pasifik", listOf("Samudra Atlantik", "Samudra Hindia", "Samudra Arktik")),
            Triple("Samudra terluas kedua di bumi yang membentang di antara Benua Amerika dan Benua Eropa-Afrika berbentuk huruf S adalah apa?", "Samudra Atlantik", listOf("Samudra Pasifik", "Samudra Hindia", "Samudra Arktik")),
            Triple("Samudra yang membentang di sebelah selatan Benua Asia dan barat daya kepulauan Indonesia adalah samudra apa?", "Samudra Hindia", listOf("Samudra Pasifik", "Samudra Atlantik", "Samudra Arktik")),
            Triple("Palung laut terdalam di dunia yang terletak di dasar barat Samudra Pasifik dengan kedalaman hampir 11.000 meter adalah apa?", "Palung Mariana", listOf("Palung Jawa", "Palung Puerto Riko", "Palung Tonga")),
            Triple("Puncak gunung tertinggi di permukaan bumi yang berada di rangkaian Pegunungan Himalaya di perbatasan Nepal dan Tibet adalah?", "Gunung Everest (Sagarmatha)", listOf("Gunung Kilimanjaro", "Gunung Elbrus", "Gunung Aconcagua")),
            Triple("Sungai terpanjang di dunia yang mengalir melintasi benua Afrika bagian timur laut menuju Laut Mediterania adalah apa?", "Sungai Nil", listOf("Sungai Amazon", "Sungai Yangtze", "Sungai Mississippi")),
            Triple("Sungai dengan debit aliran air terbesar di dunia yang mengalir melintasi hutan hujan tropis terbesar di Amerika Selatan adalah?", "Sungai Amazon", listOf("Sungai Nil", "Sungai Kongo", "Sungai Gangga")),
            Triple("Gurun pasir panas terluas di dunia yang membentang di bagian utara Benua Afrika adalah gurun apa?", "Gurun Sahara", listOf("Gurun Gobi", "Gurun Kalahari", "Gurun Arab")),
            Triple("Gurun dingin berbatu pasir yang membentang di perbatasan antara negara Tiongkok dan Mongolia adalah gurun apa?", "Gurun Gobi", listOf("Gurun Sahara", "Gurun Atacama", "Gurun Victoria")),
            Triple("Gurun terkering di planet bumi yang terletak di pesisir barat Amerika Selatan di negara Chili adalah gurun apa?", "Gurun Atacama", listOf("Gurun Sahara", "Gurun Mojave", "Gurun Sonora")),
            Triple("Negara kepulauan tetangga di utara Indonesia yang memiliki ibu kota di Manila adalah negara apa?", "Filipina", listOf("Vietnam", "Thailand", "Malaysia")),
            Triple("Negara tetangga serumpun di utara pulau Kalimantan dan Sumatera yang beribu kota di Kuala Lumpur adalah apa?", "Malaysia", listOf("Singapura", "Brunei Darussalam", "Thailand")),
            Triple("Negara kota pulau modern terkecil di Asia Tenggara yang terletak tepat di selatan Semenanjung Malaya adalah negara apa?", "Singapura", listOf("Brunei", "Timor Leste", "Maladewa")),
            Triple("Satu-satunya negara di Asia Tenggara yang tidak pernah dijajah oleh bangsa asing Eropa adalah negara apa?", "Thailand (Siam)", listOf("Myanmar", "Kamboja", "Laos")),
            Triple("Negara di Asia Tenggara yang tidak memiliki wilayah laut sama sekali (landlocked country) adalah negara apa?", "Laos", listOf("Kamboja", "Vietnam", "Myanmar")),
            Triple("Negara dengan jumlah penduduk terpadat pertama di dunia saat ini yang beribu kota di New Delhi adalah apa?", "India", listOf("Tiongkok", "Amerika Serikat", "Indonesia")),
            Triple("Negara kepulauan di Asia Timur yang dijuluki Negeri Matahari Terbit dan beribu kota di Tokyo adalah apa?", "Jepang", listOf("Korea Selatan", "Tiongkok", "Taiwan")),
            Triple("Negara di Asia Timur yang terkenal dengan julukan Negeri Ginseng dan beribu kota di Seoul adalah negara apa?", "Korea Selatan", listOf("Jepang", "Tiongkok", "Mongolia")),
            Triple("Bangunan benteng pertahanan terpanjang di dunia yang dibangun ribuan tahun lalu di Tiongkok adalah apa?", "Tembok Besar Tiongkok", listOf("Kota Terlarang", "Kuil Shaolin", "Kuil Langit")),
            Triple("Monumen makam pualam putih megah yang dibangun oleh Kaisar Shah Jahan sebagai lambang cinta di Agra India adalah apa?", "Taj Mahal", listOf("Kuil Emas", "Benteng Merah", "Hawa Mahal")),
            Triple("Bangunan piramida batu raksasa peninggalan peradaban Mesir Kuno yang dijaga patung berkepala manusia berbadan singa adalah apa?", "Piramida Giza dan Sphinx", listOf("Kuil Luxor", "Karnak", "Abu Simbel")),
            Triple("Menara besi setinggi 300 meter yang menjadi ikon terkenal Kota Paris di negara Perancis adalah menara apa?", "Menara Eiffel", listOf("Menara Pisa", "Big Ben", "Menara Berlin")),
            Triple("Menara lonceng miring marmer putih yang terkenal di negara Italia adalah menara apa?", "Menara Miring Pisa", listOf("Menara Eiffel", "Colosseum", "Katedral Milan")),
            Triple("Amfiteater kuno tempat pertarungan gladiator pada zaman Kekaisaran Romawi Kuno di Roma Italia adalah apa?", "Colosseum", listOf("Pantheon", "Forum Romanum", "Circus Maximus")),
            Triple("Menara jam raksasa terkenal yang terletak di Gedung Parlemen Westminster di Kota London Inggris adalah apa?", "Big Ben (Elizabeth Tower)", listOf("Tower Bridge", "London Eye", "Katedral St. Paul")),
            Triple("Kanal terusan kapal yang menghubungkan antara Laut Mediterania dan Laut Merah di wilayah negara Mesir adalah apa?", "Terusan Suez", listOf("Terusan Panama", "Terusan Kiel", "Terusan Korintus")),
            Triple("Kanal terusan kapal yang menghubungkan Samudra Atlantik dan Samudra Pasifik membelah daratan Amerika Tengah adalah apa?", "Terusan Panama", listOf("Terusan Suez", "Terusan Erie", "Selat Magelhaens")),
            Triple("Garis bujur nol derajat standar internasional pembagian waktu dunia (GMT) melintasi kota apa di Inggris?", "Kota Greenwich (London)", listOf("Kota Paris", "Kota Roma", "Kota Berlin")),
            Triple("Berapa selisih waktu antara Waktu Indonesia Barat (WIB) dengan Waktu Greenwich Internasional (GMT / UTC)?", "GMT + 7 jam", listOf("GMT + 8 jam", "GMT + 9 jam", "GMT + 5 jam")),
            Triple("Berapa selisih waktu antara Waktu Indonesia Tengah (WITA) dengan Waktu Greenwich Internasional (GMT / UTC)?", "GMT + 8 jam", listOf("GMT + 7 jam", "GMT + 9 jam", "GMT + 6 jam")),
            Triple("Berapa selisih waktu antara Waktu Indonesia Timur (WIT) dengan Waktu Greenwich Internasional (GMT / UTC)?", "GMT + 9 jam", listOf("GMT + 7 jam", "GMT + 8 jam", "GMT + 10 jam")),
            Triple("Provinsi Bali dan Nusa Tenggara Barat termasuk ke dalam zona waktu wilayah Indonesia mana?", "WITA (Waktu Indonesia Tengah)", listOf("WIB", "WIT", "WIB dan WIT")),
            Triple("Provinsi Papua, Papua Barat, dan Maluku termasuk ke dalam zona waktu wilayah Indonesia mana?", "WIT (Waktu Indonesia Timur)", listOf("WIB", "WITA", "GMT")),
            Triple("Pulau Sumatera, Jawa, dan Kalimantan Barat termasuk ke dalam zona waktu wilayah Indonesia mana?", "WIB (Waktu Indonesia Barat)", listOf("WITA", "WIT", "UTC")),
            Triple("Patung raksasa berkulit tembaga Dewi Kemerdekaan yang memegang obor di Pelabuhan New York Amerika Serikat adalah apa?", "Patung Liberty", listOf("Patung Kristus Penebus", "Gunung Rushmore", "Patung Kolosus")),
            Triple("Patung Yesus Kristus raksasa yang berdiri merentangkan tangan di atas bukit Corcovado Rio de Janeiro Brasil adalah apa?", "Christ the Redeemer (Kristus Penebus)", listOf("Patung Liberty", "Patung Bunda Maria", "Patung Santo Petrus")),
            Triple("Situs reruntuhan kota kuno bangsa Inka yang terletak di pegunungan tinggi Andes negara Peru adalah apa?", "Machu Picchu", listOf("Chichen Itza", "Tikal", "Teotihuacan")),
            Triple("Piramida bertingkat bangsa Maya kuno yang terkenal di Semenanjung Yukatan negara Meksiko adalah apa?", "Chichen Itza", listOf("Machu Picchu", "Piramida Giza", "El Castillo")),
            Triple("Gedung pencakar langit tertinggi di dunia saat ini yang menjulang lebih dari 828 meter di Kota Dubai Uni Emirat Arab adalah?", "Burj Khalifa", listOf("Menara Shanghai", "Menara Petronas", "Taipei 101")),
            Triple("Menara kembar megah yang menjadi ikon Kota Kuala Lumpur di negara Malaysia adalah menara apa?", "Menara Kembar Petronas", listOf("Menara KL", "Menara Baiyoke", "Menara Marina")),
            Triple("Pegunungan salju tertinggi dan terpanjang di benua Eropa yang melintasi Swiss, Perancis, dan Italia adalah pegunungan apa?", "Pegunungan Alpen", listOf("Pegunungan Andes", "Pegunungan Rocky", "Pegunungan Ural")),
            Triple("Pegunungan lipatan terpanjang di dunia yang membentang di sepanjang pesisir barat Benua Amerika Selatan adalah apa?", "Pegunungan Andes", listOf("Pegunungan Rocky", "Pegunungan Alpen", "Pegunungan Kaukasus")),
            Triple("Pegunungan yang menjadi batas alami pemisah antara Benua Eropa dan Benua Asia di wilayah negara Rusia adalah apa?", "Pegunungan Ural", listOf("Pegunungan Kaukasus", "Pegunungan Carpathia", "Pegunungan Altai")),
            Triple("Negara terluas di dunia berdasarkan luas daratan total yang membentang di Eropa Timur dan Asia Utara adalah negara apa?", "Rusia", listOf("Kanada", "Amerika Serikat", "Tiongkok")),
            Triple("Negara terkecil di dunia yang berada di dalam Kota Roma Italia dan menjadi pusat Gereja Katolik sedunia adalah apa?", "Vatikan", listOf("Monako", "San Marino", "Liechtenstein"))
        )
        for (item in worldGeoCulture50) {
            val wrongs = item.third.take(3)
            val options = makeOptions(item.second, wrongs[0], wrongs.getOrElse(1) { "LAIN" }, wrongs.getOrElse(2) { "BEDA" }, count = 4)
            questions.add(
                Question(
                    id = "umum_910_$qId",
                    category = QuizCategory.PENGETAHUAN_UMUM,
                    ageBracket = AgeBracket.AGE_9_10,
                    questionText = item.first,
                    visualEmoji = "🌍 Wawasan Global",
                    options = options,
                    correctIndex = 0,
                    explanation = "Tepat sekali! Jawaban geografi dunia yang benar adalah '${item.second}'.",
                    hint = "Ingat peta dunia, bentang alam, benua, dan keajaiban peradaban manusia.",
                    difficulty = "Tantangan"
                )
            )
            qId++
        } // Exactly 150 questions for Age 9-10!

        return questions
    }
}
