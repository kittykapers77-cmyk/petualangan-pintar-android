package com.example.data.source.generators

import com.example.data.model.AgeBracket
import com.example.data.model.Question
import com.example.data.model.QuizCategory

object BahasaQuestionGenerator {

    fun generateQuestions(): List<Question> {
        val list = ArrayList<Question>(450)
        list.addAll(generateAge56())
        list.addAll(generateAge78())
        list.addAll(generateAge910())
        return list
    }

    private fun makeOptions(correct: String, vararg candidates: String, count: Int = 4): List<String> {
        val result = linkedSetOf(correct)
        for (c in candidates) {
            if (c != correct && c.isNotBlank()) {
                result.add(c)
                if (result.size == count) break
            }
        }
        var offset = 1
        while (result.size < count) {
            val fallback = "$correct (pilihan $offset)"
            offset++
            if (fallback != correct && !result.contains(fallback)) {
                result.add(fallback)
            }
        }
        return result.toList()
    }

    // =========================================================================
    // USIA 5-6 TAHUN (150 PERTANYAAN ALAMI)
    // =========================================================================
    private fun generateAge56(): List<Question> {
        val questions = ArrayList<Question>(150)
        var qId = 1

        // 1. Pengenalan Huruf Pertama (50 kata unik berbeda)
        val wordList50 = listOf(
            Triple("APEL", "A", "🍎"), Triple("BUKU", "B", "📚"), Triple("CERI", "C", "🍒"),
            Triple("DOMBA", "D", "🐑"), Triple("ELANG", "E", "🦅"), Triple("FLAMINGO", "F", "🦩"),
            Triple("GAJAH", "G", "🐘"), Triple("HARIMAU", "H", "🐯"), Triple("IKAN", "I", "🐟"),
            Triple("JERUK", "J", "🍊"), Triple("KUCING", "K", "🐱"), Triple("LEBAH", "L", "🐝"),
            Triple("MONYET", "M", "🐵"), Triple("NANAS", "N", "🍍"), Triple("ONTA", "O", "🐪"),
            Triple("PISANG", "P", "🍌"), Triple("RUSA", "R", "🦌"), Triple("SAPI", "S", "🐮"),
            Triple("TIKUS", "T", "🐭"), Triple("UDANG", "U", "🦐"), Triple("ZEBRA", "Z", "🦓"),
            Triple("AYAM", "A", "🐔"), Triple("BEBEK", "B", "🦆"), Triple("CICAK", "C", "🦎"),
            Triple("DAUN", "D", "🍃"), Triple("EMBER", "E", "🪣"), Triple("GURITA", "G", "🐙"),
            Triple("HELM", "H", "🪖"), Triple("IGUANA", "I", "🦎"), Triple("JAGUNG", "J", "🌽"),
            Triple("KELINCI", "K", "🐰"), Triple("LUMBA-LUMBA", "L", "🐬"), Triple("MANGGA", "M", "🥭"),
            Triple("NYAMUK", "N", "🦟"), Triple("ORANGUTAN", "O", "🦧"), Triple("PAUS", "P", "🐋"),
            Triple("RAMBUTAN", "R", "🍇"), Triple("SEMUT", "S", "🐜"), Triple("TUPAI", "T", "🐿️"),
            Triple("ULAR", "U", "🐍"), Triple("WORTEL", "W", "🥕"), Triple("YOYO", "Y", "🪀"),
            Triple("BINTANG", "B", "⭐"), Triple("CITAH", "C", "🐆"), Triple("CAPUNG", "C", "🦗"),
            Triple("BURUNG", "B", "🐦"), Triple("KUPU-KUPU", "K", "🦋"), Triple("LANDAK", "L", "🦔"),
            Triple("MUSANG", "M", "🦝"), Triple("PENGUIN", "P", "🐧")
        )
        val allLetters = listOf("A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "R", "S", "T", "U", "W", "Y", "Z")
        for (item in wordList50) {
            val letter = item.second
            val wrongs = allLetters.filter { it != letter }.shuffled().take(2)
            val options = makeOptions(letter, wrongs[0], wrongs[1], count = 3)

            questions.add(
                Question(
                    id = "bahasa_56_$qId",
                    category = QuizCategory.BAHASA_INDONESIA,
                    ageBracket = AgeBracket.AGE_5_6,
                    questionText = "Huruf pertama dari kata '${item.first}' adalah huruf apa?",
                    visualEmoji = item.third,
                    options = options,
                    correctIndex = 0,
                    explanation = "Kata '${item.first}' diawali dengan huruf '$letter'.",
                    hint = "Dengarkan bunyi huruf yang berada di posisi paling depan.",
                    difficulty = "Mudah"
                )
            )
            qId++
        } // 50 questions done

        // 2. Lawan Kata Konkret (50 pasangan unik berbeda)
        val antonyms50 = listOf(
            Triple("BESAR", "KECIL", "🐘 vs 🐭"), Triple("PANAS", "DINGIN", "🔥 vs 🧊"),
            Triple("TERANG", "GELAP", "☀️ vs 🌑"), Triple("TINGGI", "PENDEK", "🦒 vs 🐢"),
            Triple("PANJANG", "PENDEK", "📏 vs ✏️"), Triple("BERSIH", "KOTOR", "🧼 vs 🧦"),
            Triple("SENANG", "SEDIH", "😄 vs 😢"), Triple("CEPAT", "LAMBAT", "🐆 vs 🐌"),
            Triple("NAIK", "TURUN", "🪜 vs 🛝"), Triple("BUKA", "TUTUP", "🚪 vs 🔒"),
            Triple("MAJU", "MUNDUR", "🚶 vs 🔙"), Triple("TEBAL", "TIPIS", "📖 vs 📄"),
            Triple("BERAT", "RINGAN", "🏋️ vs 🪶"), Triple("BASAH", "KERING", "🌧️ vs ☀️"),
            Triple("GEMUK", "KURUS", "🐼 vs 🦩"), Triple("KASAR", "HALUS", "🧱 vs 🪞"),
            Triple("KERAS", "LEMBUT", "🪨 vs 🧸"), Triple("SIANG", "MALAM", "🌞 vs 🌜"),
            Triple("JAUH", "DEKAT", "✈️ vs 🚲"), Triple("KAYA", "MISKIN", "🏰 vs ⛺"),
            Triple("TAJAM", "TUMPUL", "🔪 vs 🪵"), Triple("RAMAI", "SEPI", "🎪 vs 🏕️"),
            Triple("WANGI", "BAU", "🌸 vs 🦨"), Triple("KUAT", "LEMAH", "🦁 vs 🐣"),
            Triple("MUDAH", "SUSAH", "✅ vs 🧩"), Triple("MANIS", "PAHIT", "🍯 vs ☕"),
            Triple("PENUH", "KOSONG", "🥛 vs 🫙"), Triple("RAJIN", "MALAS", "📚 vs 💤"),
            Triple("KELUAR", "MASUK", "🚪 vs 🏠"), Triple("HIDUP", "MATI", "🌱 vs 🍂"),
            Triple("KIRI", "KANAN", "⬅️ vs ➡️"), Triple("ATAS", "BAWAH", "⬆️ vs ⬇️"),
            Triple("DEPAN", "BELAKANG", "👦 vs 🎒"), Triple("DALAM", "LUAR", "📦 vs 🏞️"),
            Triple("BARU", "LAMA", "👟 vs 👞"), Triple("MAHAL", "MURAH", "💎 vs 🪙"),
            Triple("BAIK", "BURUK", "😇 vs 👿"), Triple("GELAP", "TERANG", "🌃 vs 🌅"),
            Triple("MUDA", "TUA", "👦 vs 👴"), Triple("LUAS", "SEMPIT", "🏟️ vs 🚪"),
            Triple("GEMBIRA", "DUKA", "🥳 vs 🥺"), Triple("TEGAK", "BENGKOK", "🦯 vs 🪝"),
            Triple("RAPAT", "RENGGANG", "🧱 vs 🪜"), Triple("LURUS", "BELOK", "🛣️ vs 🔄"),
            Triple("SEHAT", "SAKIT", "🏃 vs 🤒"), Triple("TERBIT", "TERBENAM", "🌅 vs 🌇"),
            Triple("DATANG", "PERGI", "👋 vs 🛫"), Triple("LAPAR", "KENYANG", "🤤 vs 😋"),
            Triple("HAUS", "PUAS", "🥤 vs 😌"), Triple("TIDUR", "BANGUN", "🛌 vs ⏰")
        )
        for (ant in antonyms50) {
            val correctVal = ant.second
            val pool = listOf("KECIL", "DINGIN", "GELAP", "PENDEK", "KOTOR", "SEDIH", "LAMBAT", "TURUN", "TUTUP", "RINGAN", "KERING", "LEMBUT", "LEMAH", "SUSAH", "KOSONG", "MALAS", "MURAH", "BURUK", "BELOK", "SAKIT")
            val wrongs = pool.filter { it != correctVal && it != ant.first }.take(2)
            val options = makeOptions(correctVal, wrongs.getOrElse(0) { "LAINNYA" }, wrongs.getOrElse(1) { "BEDA" }, count = 3)

            questions.add(
                Question(
                    id = "bahasa_56_$qId",
                    category = QuizCategory.BAHASA_INDONESIA,
                    ageBracket = AgeBracket.AGE_5_6,
                    questionText = "Lawan kata dari sifat '${ant.first}' adalah?",
                    visualEmoji = ant.third,
                    options = options,
                    correctIndex = 0,
                    explanation = "Lawan kata dari '${ant.first}' adalah '${ant.second}'.",
                    hint = "Pikirkan kebalikan dari sifat tersebut.",
                    difficulty = "Mudah"
                )
            )
            qId++
        } // 100 questions done

        // 3. Suara Hewan, Benda & Tata Krama (50 pertanyaan unik alami)
        val naturalPrompts50 = listOf(
            Triple("Ayam jantan berkokok di pagi hari dengan bunyi seperti apa?", "Kukuruyuk!", listOf("Meong", "Kwek-kwek")),
            Triple("Kucing kesayangan saat menyapa kita mengeong dengan suara bagaimana?", "Meong meong", listOf("Guk guk", "Moo moo")),
            Triple("Bebek yang berenang riang di kolam air bersuara apa?", "Kwek kwek", listOf("Cicit cuit", "Petok petok")),
            Triple("Sapi perah di padang rumput melenguh dengan suara bagaimana?", "Moo moo", listOf("Mbek mbek", "Guk guk")),
            Triple("Kambing yang sedang mencari rumput segar mengembik dengan suara apa?", "Mbeeek", listOf("Meong", "Kukuruyuk")),
            Triple("Burung pipit kecil berkicau merdu di dahan ranting dengan suara bagaimana?", "Cicit cuit", listOf("Guk guk", "Kwek kwek")),
            Triple("Anjing setia penjaga halaman rumah menggonggong dengan suara seperti apa?", "Guk guk", listOf("Meong meong", "Moo moo")),
            Triple("Katak hijau di tepi rawa bernyanyi saat hujan turun dengan suara bagaimana?", "Krok krok", listOf("Cicit cuit", "Moo moo")),
            Triple("Singa sang raja rimba mengaum gagah dengan suara seperti apa?", "Auumm!", listOf("Cicit cuit", "Kwek kwek")),
            Triple("Tikus kecil yang melintas cepat berdecit dengan suara apa?", "Cit cit cit", listOf("Kukuruyuk", "Mbek mbek")),
            Triple("Saat menerima pemberian hadiah boneka dari nenek, ucapan santun apa yang kita sampaikan?", "Terima kasih", listOf("Minta maaf", "Selamat tinggal")),
            Triple("Ketika tidak sengaja menyenggol lengan teman saat bermain, kata santun apa yang kita ucapkan?", "Minta maaf", listOf("Terima kasih", "Permisi")),
            Triple("Sebelum melangkah masuk bertamu ke dalam rumah tetangga, ucapan santun apa yang kita sampaikan?", "Permisi", listOf("Minta maaf", "Cepat buka")),
            Triple("Ketika membutuhkan bantuan ayah untuk mengambil buku di lemari tinggi, kata santun apa yang kita katakan?", "Tolong", listOf("Harus cepat", "Biar saja")),
            Triple("Saat berpamitan kepada teman sekelas setelah lonceng pulang sekolah berbunyi, ucapan apa yang kita sampaikan?", "Sampai jumpa", listOf("Minta tolong", "Minta maaf")),
            Triple("Saat bertemu bapak atau ibu guru di pagi hari di pintu gerbang sekolah, salam apa yang kita ucapkan?", "Selamat pagi", listOf("Selamat tidur", "Sampai jumpa nanti malam")),
            Triple("Bagian tubuh mana yang kita gunakan untuk mendengarkan alunan lagu ceria?", "Telinga", listOf("Mata", "Lidah")),
            Triple("Bagian tubuh mana yang kita gunakan untuk melihat warna-warni pelangi di langit?", "Mata", listOf("Telinga", "Hidung")),
            Triple("Bagian tubuh mana yang kita gunakan untuk menghirup wangi harum bunga melati?", "Hidung", listOf("Lidah", "Telinga")),
            Triple("Bagian tubuh mana yang kita gunakan untuk mengecap manisnya buah semangka segar?", "Lidah", listOf("Hidung", "Telinga")),
            Triple("Bagian tubuh mana yang kita gunakan untuk melangkah dan melompat di halaman bermain?", "Kaki", listOf("Tangan", "Pipi")),
            Triple("Bagian tubuh mana yang kita gunakan untuk memegang krayon dan menggambar pemandangan?", "Tangan", listOf("Kaki", "Dagu")),
            Triple("Pelindung kepala yang kita pakai di atas kepala saat naik sepeda adalah?", "Helm pelindung", listOf("Sepatu", "Kacamata")),
            Triple("Benda tahan air yang kita buka dan pegang agar tidak kehujanan saat melangkah adalah?", "Payung", listOf("Buku cerita", "Bantal")),
            Triple("Alat pembersih yang kita gunakan bersama pasta gigi untuk menggosok gigi adalah?", "Sikat gigi", listOf("Sisir rambut", "Sendok makan")),
            Triple("Benda bergigi rapat yang kita gunakan untuk merapikan rambut kusut sehabis mandi adalah?", "Sisir rambut", listOf("Sikat sepatu", "Gunting kuku")),
            Triple("Kain pelindung kaki yang kita kenakan di telapak kaki sebelum memakai sepatu adalah?", "Kaus kaki", listOf("Topi", "Sarung tangan")),
            Triple("Peralatan makan yang berbentuk cekung untuk menyendok nasi dan sayur berkuah adalah?", "Sendok makan", listOf("Garpu tusuk", "Pisau dapur")),
            Triple("Benda karet yang kita gunakan untuk menghapus goresan pensil di buku tulis adalah?", "Penghapus karet", listOf("Penggaris kayu", "Rautan pensil")),
            Triple("Benda lentur beraneka warna yang ditiup angin melayang tinggi di angkasa saat pesta adalah?", "Balon udara", listOf("Batu kerikil", "Kayu balok")),
            Triple("Gedung tenang yang menyimpan banyak koleksi buku cerita anak untuk dipinjam dan dibaca adalah?", "Perpustakaan", listOf("Bengkel mobil", "Stasiun kereta")),
            Triple("Kendaraan panjang bermesin yang melaju di atas rel baja sambil bersuara semboyan adalah?", "Kereta api", listOf("Perahu layar", "Sepeda motor")),
            Triple("Kendaraan bermesin berbadan besar dengan sepasang sayap yang melesat melintasi awan adalah?", "Pesawat terbang", listOf("Kapal selam", "Mobil sedan")),
            Triple("Kendaraan air yang berlayar mengarungi samudra membawa muatan dan penumpang adalah?", "Kapal laut", listOf("Bus bertingkat", "Helikopter")),
            Triple("Kendaraan dua roda kayuh yang memiliki bel berbunyi kring-kring di setang adalah?", "Sepeda kayuh", listOf("Mobil listrik", "Truk muatan")),
            Triple("Kawasan terbuka hijau yang asri dengan ayunan dan perosotan untuk anak bermain adalah?", "Taman bermain", listOf("Pasar ikan", "Pelabuhan")),
            Triple("Penunjuk waktu berangka di dinding yang berdetik teratur setiap detik adalah?", "Jam dinding", listOf("Kipas angin", "Lampu meja")),
            Triple("Pakaian khusus yang kita kenakan saat hendak berenang di kolam renang adalah?", "Pakaian renang", listOf("Jaket wol tebal", "Seragam pramuka")),
            Triple("Buah merah berbintik manis yang memiliki rasa asam manis segar dan bermahkota daun kecil adalah?", "Buah stroberi", listOf("Buah durian", "Buah alpukat")),
            Triple("Buah beraroma harum semerbak dengan kulit tebal berduri runcing adalah?", "Buah durian", listOf("Buah semangka", "Buah melon")),
            Triple("Umbi sayuran berwarna oranye cerah yang sangat menyehatkan mata dan disukai kelinci adalah?", "Wortel", listOf("Terung ungu", "Cabai merah")),
            Triple("Minuman bergizi berwarna putih gurih yang diperah dari sapi perah sehat adalah?", "Susu murni", listOf("Kopi hitam", "Minyak goreng")),
            Triple("Benda langit yang bersinar lembut menerangi kegelapan malam hari adalah?", "Bulan purnama", listOf("Matahari siang", "Awan mendung")),
            Triple("Alat yang menghasilkan cahaya terang di atas meja belajar ketika malam tiba adalah?", "Lampu belajar", listOf("Termos air", "Kipas angin")),
            Triple("Wadah bertali yang kita gendong di punggung untuk membawa perlengkapan belajar adalah?", "Tas ransel sekolah", listOf("Piring makan", "Wajan penggoreng")),
            Triple("Alat pemotong berbilah tajam dua sisi yang digunakan untuk memotong kertas lipat adalah?", "Gunting kertas", listOf("Sendok garpu", "Kuas lukis")),
            Triple("Bahan pembersih wangi berbusa yang mematikan kuman saat kita mencuci kedua telapak tangan adalah?", "Sabun cuci tangan", listOf("Gula pasir", "Garam dapur")),
            Triple("Kain lembut penyerap air yang kita gunakan untuk mengeringkan badan sehabis mandi segar adalah?", "Handuk mandi", listOf("Selimut tidur", "Taplak meja")),
            Triple("Tenaga medis ramah yang menyembuhkan kucing atau anjing peliharaan saat sakit adalah?", "Dokter hewan", listOf("Montir bengkel", "Koki restoran")),
            Triple("Panggilan penuh kasih sayang untuk perempuan hebat yang melahirkan dan membesarkan kita adalah?", "Ibu tercinta", listOf("Paman", "Sahabat"))
        )
        for (item in naturalPrompts50) {
            val options = makeOptions(item.second, item.third[0], item.third[1], count = 3)
            questions.add(
                Question(
                    id = "bahasa_56_$qId",
                    category = QuizCategory.BAHASA_INDONESIA,
                    ageBracket = AgeBracket.AGE_5_6,
                    questionText = item.first,
                    visualEmoji = "🐾 🗣️",
                    options = options,
                    correctIndex = 0,
                    explanation = "Tepat sekali! Pilihan yang paling benar adalah '${item.second}'.",
                    hint = "Ingat pengalaman sehari-hari bersama keluarga dan teman.",
                    difficulty = "Mudah"
                )
            )
            qId++
        } // Exactly 150 questions for Age 5-6!

        return questions
    }

    // =========================================================================
    // USIA 7-8 TAHUN (150 PERTANYAAN ALAMI)
    // =========================================================================
    private fun generateAge78(): List<Question> {
        val questions = ArrayList<Question>(150)
        var qId = 1

        // 1. Antonim Tingkat Lanjut (50 kata unik berbeda)
        val antonyms78 = listOf(
            Triple("RAJIN", "MALAS", listOf("PINTAR", "CERDAS", "HEMAT")),
            Triple("HEMAT", "BOROS", listOf("PELIT", "KAYA", "DERMAWAN")),
            Triple("BERANI", "PENAKUT", listOf("GAGAH", "KUAT", "PINTAR")),
            Triple("JUJUR", "CURANG", listOf("BAIK", "BOHONG", "PINTAR")),
            Triple("MURAH", "MAHAL", listOf("INDAH", "BANYAK", "SEDIKIT")),
            Triple("MUDAH", "SULIT", listOf("RINGAN", "GAMPANG", "CEPAT")),
            Triple("KUAT", "LEMAH", listOf("BESAR", "KECIL", "HEBAT")),
            Triple("TAJAM", "TUMPUL", listOf("LURUS", "BENGKOK", "KASAR")),
            Triple("RAMAH", "SOMBONG", listOf("SOPAN", "BAIK", "GEMBIRA")),
            Triple("SUBUR", "GERSANG", listOf("KERING", "BASAH", "HIJAU")),
            Triple("DERMAWAN", "PELIT", listOf("KAYA", "PINTAR", "RAMAH")),
            Triple("ASLI", "PALSU", listOf("BARU", "MAHAL", "INDAH")),
            Triple("SEMENTARA", "ABADI", listOf("LAMA", "CEPAT", "SEBENTAR")),
            Triple("AKTIF", "PASIF", listOf("DIAM", "GERAK", "LEMAH")),
            Triple("SEDIH", "GEMBIRA", listOf("MARAH", "KAGET", "BINGUNG")),
            Triple("TAAT", "MEMBANGKANG", listOf("PATUH", "SETIA", "SOPAN")),
            Triple("UNTUNG", "RUGI", listOf("MODAL", "LABA", "SUKSES")),
            Triple("ADIL", "CURANG", listOf("BIJAK", "BENAR", "JUJUR")),
            Triple("BERSIH", "KOTOR", listOf("RAPI", "INDAH", "WANGI")),
            Triple("TENANG", "GELISAH", listOf("DAMAI", "SABAR", "LEMBUT")),
            Triple("TERATUR", "BERANTAKAN", listOf("RAPI", "BERSIH", "TERTATA")),
            Triple("AMAN", "BAHAYA", listOf("DAMAI", "TENTERAM", "NYAMAN")),
            Triple("GAGAH", "LEMAH", listOf("BERANI", "TEGAP", "PERKASA")),
            Triple("KERING", "BASAH", listOf("LEMBAP", "HAUS", "PANAS")),
            Triple("PANDAI", "BODOH", listOf("MALAS", "LEMAH", "LAMBAT")),
            Triple("TERANG", "GELAP", listOf("SILAU", "BENING", "CERAH")),
            Triple("PANJANG", "PENDEK", listOf("LEBAR", "TINGGI", "TEBAL")),
            Triple("CEKUNG", "CEMBUNG", listOf("LURUS", "RATA", "DATAR")),
            Triple("KEKAL", "FANA", listOf("LAMA", "HILANG", "SUSAH")),
            Triple("PERCAYA", "RAGU", listOf("YAKIN", "PASTI", "TEGUH")),
            Triple("TAWAR", "ASIN", listOf("MANIS", "PAHIT", "SEGAR")),
            Triple("JELAS", "SAMAR", listOf("NYATA", "TERANG", "TEGAS")),
            Triple("LUAS", "SEMPIT", listOf("PANJANG", "LEBAR", "LAPANG")),
            Triple("RAPAT", "RENGGANG", listOf("PADAT", "DEKAT", "SESAK")),
            Triple("TEBAL", "TIPIS", listOf("LEBAR", "BERAT", "BESAR")),
            Triple("TINGGI", "PENDEK", listOf("KECIL", "RENDAH", "SEMPIT")),
            Triple("CEPAT", "LAMBAT", listOf("DERAS", "KENCANG", "GESIT")),
            Triple("WANGI", "BUSUK", listOf("HARUM", "SEGAR", "SEDAK")),
            Triple("BERAT", "RINGAN", listOf("BESAR", "KUAT", "BANYAK")),
            Triple("PADAT", "CAIR", listOf("GAS", "BEKU", "LELEH")),
            Triple("DINGIN", "HANGAT", listOf("SEJUK", "BEKU", "PANAS")),
            Triple("KERAS", "LUNAK", listOf("PADAT", "KASAR", "TEGANG")),
            Triple("KASAR", "HALUS", listOf("LICIN", "RATA", "LEMBUT")),
            Triple("MENANG", "KALAH", listOf("JUARA", "UNGGUL", "SUKSES")),
            Triple("BERKUMPUL", "BERPISAH", listOf("BERSATU", "BERTEMU", "BERSAMA")),
            Triple("MENGAPUNG", "TENGGELAM", listOf("BERENANG", "MELAYANG", "HANYUT")),
            Triple("TERPISAH", "BERSATU", listOf("SENDIRI", "PECAH", "CERAI")),
            Triple("MELEPAS", "MENGIKAT", listOf("MENUTUP", "MEMBUANG", "MENAHAN")),
            Triple("DUDUK", "BERDIRI", listOf("JALAN", "LARI", "LOMPAT")),
            Triple("MEMBELI", "MENJUAL", listOf("MENAWAR", "MEMBAYAR", "MENYIMPAN"))
        )
        for (ant in antonyms78) {
            val wrongs = ant.third.filter { it != ant.second }.take(3)
            val options = makeOptions(ant.second, wrongs[0], wrongs.getOrElse(1) { "LAIN" }, wrongs.getOrElse(2) { "BEDA" }, count = 4)

            questions.add(
                Question(
                    id = "bahasa_78_$qId",
                    category = QuizCategory.BAHASA_INDONESIA,
                    ageBracket = AgeBracket.AGE_7_8,
                    questionText = "Lawan kata atau antonim dari kata '${ant.first}' adalah?",
                    visualEmoji = "🆚 Antonim",
                    options = options,
                    correctIndex = 0,
                    explanation = "Lawan kata (antonim) dari kata '${ant.first}' adalah '${ant.second}'.",
                    hint = "Cari kata yang maknanya bertolak belakang.",
                    difficulty = "Sedang"
                )
            )
            qId++
        } // 50 questions done

        // 2. Sinonim / Persamaan Kata (50 kata unik berbeda)
        val synonyms78 = listOf(
            Triple("GEMBIRA", "SENANG", listOf("SEDIH", "MARAH", "KAGET")),
            Triple("PINTAR", "PANDAI", listOf("BODOH", "MALAS", "LEMAH")),
            Triple("INDAH", "ELOK", listOf("JELEK", "BURUK", "SURAM")),
            Triple("SUKAR", "SULIT", listOf("MUDAH", "GAMPANG", "RINGAN")),
            Triple("SAHABAT", "TEMAN", listOf("MUSUH", "LAWAN", "ORANG LAIN")),
            Triple("PAKAIAN", "BAJU", listOf("SEPATU", "TOPI", "TAS")),
            Triple("LEZAT", "ENAK", listOf("PAHIT", "ASIN", "BASI")),
            Triple("MENOLONG", "MEMBANTU", listOf("MEMBIARKAN", "MELAWAN", "MENOLAK")),
            Triple("MENGGAPAI", "MERAIH", listOf("MELEPAS", "MENJAUH", "MEMBUANG")),
            Triple("LUAS", "LAPANG", listOf("SEMPIT", "KECIL", "SESAK")),
            Triple("BERKATA", "BERUCAP", listOf("DIAM", "MENDENGAR", "MELIHAT")),
            Triple("MELIHAT", "MEMANDANG", listOf("MENUTUP", "MENDENGAR", "MERABA")),
            Triple("MENDENGAR", "MENYIMAK", listOf("BERBICARA", "MELAMUN", "MENULIS")),
            Triple("MENGIRA", "MENYANGKA", listOf("MEMASTIKAN", "MELIHAT", "MENAHAN")),
            Triple("MENCINTAI", "MENYAYANGI", listOf("MEMBENCI", "MENJAUHI", "MELUPAKAN")),
            Triple("CEMAS", "KHAWATIR", listOf("TENANG", "GEMBIRA", "BANGGA")),
            Triple("LELAH", "CAPAI", listOf("SEGAR", "SEHAT", "KUAT")),
            Triple("GEMAR", "SUKA", listOf("BENCI", "BOSAN", "ENGGAN")),
            Triple("PEMBERANI", "KSATRIA", listOf("PENAKUT", "PEMALU", "LEMAH")),
            Triple("CERDAS", "CENDEKIA", listOf("BODOH", "LAMBAT", "MALAS")),
            Triple("DERMAWAN", "PEMURAH", listOf("PELIT", "KIKIR", "SERAKAH")),
            Triple("RAJIN", "GIAT", listOf("MALAS", "LAMBAT", "LESU")),
            Triple("MEGAH", "MEWAH", listOf("SEDERHANA", "SEMPIT", "RUNTUH")),
            Triple("KEDIAMAN", "RUMAH", listOf("KANTOR", "JALAN", "SEKOLAH")),
            Triple("SIANG", "HARI", listOf("MALAM", "PETANG", "SUBUH")),
            Triple("KOTA", "PRAJA", listOf("DESA", "DUSUN", "HUTAN")),
            Triple("BUMI", "PERTIWI", listOf("LANGIT", "ANGKASA", "BINTANG")),
            Triple("MATAHARI", "MENTARI", listOf("BULAN", "BINTANG", "AWAN")),
            Triple("ANGIN", "BAYU", listOf("AIR", "API", "TANAH")),
            Triple("LAUT", "SAMUDRA", listOf("DANAU", "SUNGAI", "KOLAM")),
            Triple("HUTAN", "RIMBA", listOf("SAWAH", "KEBUN", "PADANG")),
            Triple("KAWAN", "REKAN", listOf("MUSUH", "PENCURI", "SAINGAN")),
            Triple("GURU", "PENDIDIK", listOf("MURID", "PELAJAR", "SOPIR")),
            Triple("MURID", "SISWA", listOf("PENGAJAR", "ORANG TUA", "DOKTER")),
            Triple("JUARA", "PEMENANG", listOf("PECUNDANG", "PENONTON", "WASIT")),
            Triple("BINGKISAN", "HADIAH", listOf("HUKUMAN", "TAGIHAN", "TUGAS")),
            Triple("TUJUAN", "ARAH", listOf("ASAL", "HALANGAN", "MASALAH")),
            Triple("HASIL", "AKIBAT", listOf("PENYEBAB", "ALASAN", "AWAL")),
            Triple("TUGAS", "KEWAJIBAN", listOf("HAK", "HADIAH", "LIBUR")),
            Triple("KARYA", "CIPTAAN", listOf("TIRUAN", "RUSAKAN", "BEKAS")),
            Triple("RENCANA", "AGENDA", listOf("KENANGAN", "MASALAH", "KEGAGALAN")),
            Triple("TEMPAT", "LOKASI", listOf("WAKTU", "ACARA", "ORANG")),
            Triple("WAKTU", "SAAT", listOf("RUANG", "JARAK", "BIAYA")),
            Triple("ATURAN", "KAIDAH", listOf("KEBEBASAN", "PELANGGARAN", "KESALAHAN")),
            Triple("BATAS", "SEKAT", listOf("JALAN", "PINTU", "TENGAH")),
            Triple("KELOMPOK", "REGU", listOf("INDIVIDU", "SENDIRI", "ORANG")),
            Triple("WANGI", "HARUM", listOf("BAU", "BUSUK", "ASIN")),
            Triple("CEMAR", "KOTOR", listOf("BERSIH", "SUCI", "INDAH")),
            Triple("BERSIH", "SUCI", listOf("KOTOR", "NAJIS", "DEBU")),
            Triple("SELAMAT", "AMAN", listOf("BAHAYA", "CELAKA", "RUGI"))
        )
        for (syn in synonyms78) {
            val wrongs = syn.third.filter { it != syn.second }.take(3)
            val options = makeOptions(syn.second, wrongs[0], wrongs.getOrElse(1) { "LAIN" }, wrongs.getOrElse(2) { "BEDA" }, count = 4)

            questions.add(
                Question(
                    id = "bahasa_78_$qId",
                    category = QuizCategory.BAHASA_INDONESIA,
                    ageBracket = AgeBracket.AGE_7_8,
                    questionText = "Persamaan kata atau sinonim dari kata '${syn.first}' adalah?",
                    visualEmoji = "🤝 Sinonim",
                    options = options,
                    correctIndex = 0,
                    explanation = "Persamaan kata (sinonim) dari '${syn.first}' adalah '${syn.second}'.",
                    hint = "Cari kata yang maknanya paling mirip dan sepadan.",
                    difficulty = "Sedang"
                )
            )
            qId++
        } // 100 questions done

        // 3. Tata Bahasa, Ejaan Baku & Ungkapan (50 pertanyaan unik alami)
        val grammar78 = listOf(
            Triple("Manakah penulisan kata baku tempat membeli obat yang tepat menurut kamus?", "Apotek", listOf("Apotik", "Apoteke", "Apotic")),
            Triple("Manakah penulisan kata baku untuk barisan orang yang sedang berdiri menunggu giliran?", "Antre", listOf("Antri", "Antrian", "Antreer")),
            Triple("Tanda baca apa yang tepat diletakkan di akhir kalimat perintah tegas?", "Tanda seru (!)", listOf("Tanda titik (.)", "Tanda tanya (?)", "Tanda koma (,)")),
            Triple("Tanda baca apa yang wajib diletakkan di akhir kalimat tanya?", "Tanda tanya (?)", listOf("Tanda seru (!)", "Tanda titik (.)", "Tanda petik (\"\")")),
            Triple("Kata dasar dari kata berimbuhan 'memasak' adalah?", "Masak", listOf("Mema", "Memasak", "Sak")),
            Triple("Kata dasar dari kata berimbuhan 'menulis' adalah?", "Tulis", listOf("Nulis", "Menu", "Tuliskan")),
            Triple("Kata dasar dari kata berimbuhan 'menyapu' adalah?", "Sapu", listOf("Nyapu", "Menya", "Punya")),
            Triple("Kata dasar dari kata berimbuhan 'membaca' adalah?", "Baca", listOf("Membacakan", "Mem", "Maca")),
            Triple("Kata penghubung yang tepat melengkapi kalimat: 'Ibu memasak di dapur, ... Ayah membaca koran' adalah?", "sedangkan", listOf("karena", "sehingga", "supaya")),
            Triple("Kata penghubung yang menyatakan alasan sebab akibat adalah?", "karena", listOf("tetapi", "atau", "dan")),
            Triple("Ungkapan 'kutu buku' memiliki arti kiasan untuk orang yang?", "Suka dan gemar membaca buku", listOf("Suka memelihara serangga", "Suka merobek halaman buku", "Malas belajar di kelas")),
            Triple("Ungkapan 'buah tangan' dalam percakapan keluarga bermakna?", "Oleh-oleh sehabis bepergian", listOf("Buah di dahan pohon", "Tangan yang memegang buah", "Hadiah barang mahal")),
            Triple("Ungkapan 'bintang kelas' diberikan kepada murid yang?", "Paling berprestasi dan pandai di kelas", listOf("Suka memandangi bintang di malam hari", "Suka menggambar bintang di dinding", "Paling pendiam di pojok kelas")),
            Triple("Ungkapan 'rendah hati' bermakna memiliki sifat yang?", "Tidak sombong dan ramah kepada semua orang", listOf("Mudah takut pada orang asing", "Suka mengalah tanpa alasan", "Berbadan pendek")),
            Triple("Ungkapan 'besar kepala' digunakan untuk menyebut orang yang memiliki sifat?", "Sombong dan merasa paling hebat", listOf("Memiliki lingkar kepala besar", "Pandai berhitung cepat", "Suka memakai topi besar")),
            Triple("Ungkapan 'meja hijau' dalam percakapan hukum merupakan sebutan kiasan untuk?", "Pengadilan hukum", listOf("Meja makan dicat hijau", "Papan tulis sekolah", "Taman bermain rumput")),
            Triple("Manakah kata baku menurut kamus untuk sarana berolahraga pagi?", "Senam", listOf("Senem", "Sneman", "Senamm")),
            Triple("Manakah penulisan kata baku yang tepat untuk kegiatan istirahat tidur sejenak?", "Tidur", listOf("Tidoor", "Tidor", "Tidurrr")),
            Triple("Imbuhan 'ber-' pada kata 'bersepeda' memiliki arti apa?", "Mengendarai sepeda", listOf("Menjual sepeda", "Membuat sepeda", "Menyimpan sepeda")),
            Triple("Imbuhan 'ber-' pada kata 'berbaju merah' memiliki arti apa?", "Mengenakan baju merah", listOf("Membeli baju merah", "Mencuci baju merah", "Membuang baju merah")),
            Triple("Imbuhan 'me-' pada kata 'menggambar' menunjukkan kegiatan apa?", "Membuat gambar", listOf("Melihat gambar", "Menghapus gambar", "Merobek gambar")),
            Triple("Bentuk jamak (banyak) dari kata 'buku' yang benar dalam bahasa Indonesia adalah?", "Buku-buku", listOf("Para buku", "Banyak buku-buku", "Semua buku-buku")),
            Triple("Bentuk jamak yang tepat untuk menunjukkan banyak kawan bermain adalah?", "Kawan-kawan", listOf("Para kawan-kawan", "Banyak kawan-kawan", "Sekalian kawan-kawan")),
            Triple("Huruf kapital wajib digunakan untuk menuliskan apa di awal kalimat?", "Huruf pertama kata pertama", listOf("Huruf terakhir kata", "Semua huruf dalam kata", "Hanya huruf vokal")),
            Triple("Huruf kapital digunakan untuk menuliskan nama apa?", "Nama orang, kota, dan negara", listOf("Nama benda mati saja", "Nama warna saja", "Nama makanan saja")),
            Triple("Penulisan nama hari yang menggunakan huruf kapital yang benar adalah?", "Hari Senin", listOf("hari senin", "Hari senin", "hari Senin")),
            Triple("Penulisan nama bulan nasional yang benar dengan huruf kapital adalah?", "Bulan Agustus", listOf("bulan agustus", "Bulan agustus", "bulan Agustus")),
            Triple("Tanda koma (,) digunakan di dalam kalimat untuk memisahkan apa?", "Unsur-unsur dalam perincian", listOf("Akhir kalimat berita", "Kalimat perintah", "Awal kalimat")),
            Triple("Kalimat yang diucapkan langsung oleh seseorang dan diapit tanda petik disebut kalimat apa?", "Kalimat langsung", listOf("Kalimat berita biasa", "Kalimat perintah", "Kalimat tanya")),
            Triple("Kalimat yang menceritakan kembali ucapan orang lain tanpa tanda petik disebut kalimat apa?", "Kalimat tidak langsung", listOf("Kalimat langsung", "Kalimat seru", "Kalimat majemuk")),
            Triple("Manakah kalimat yang merupakan contoh kalimat ajakan santun?", "Mari kita menjaga kebersihan kelas bersama.", listOf("Jangan sentuh barang itu!", "Siapakah namamu?", "Saya sedang membaca buku.")),
            Triple("Manakah kalimat yang merupakan contoh kalimat larangan tegas?", "Dilarang membuang sampah sembarangan di sungai!", listOf("Ayo kita belajar berhitung bersama.", "Berapa harga pensil ini?", "Kemarin paman datang berkunjung.")),
            Triple("Kata tanya 'Di mana' digunakan untuk menanyakan tentang apa?", "Tempat atau lokasi keberadaan", listOf("Waktu terjadinya peristiwa", "Alasan penyebab kejadian", "Jumlah banyaknya benda")),
            Triple("Kata tanya 'Kapan' digunakan dalam percakapan untuk menanyakan apa?", "Waktu berlangsungnya peristiwa", listOf("Nama orang yang hadir", "Tempat tujuan perjalanan", "Cara mengerjakan sesuatu")),
            Triple("Kata tanya 'Mengapa' digunakan dalam kalimat untuk menanyakan apa?", "Sebab atau alasan suatu kejadian", listOf("Jumlah barang yang dibeli", "Alat yang digunakan", "Nama pemilik benda")),
            Triple("Kata tanya 'Bagaimana' digunakan untuk menanyakan tentang apa?", "Cara, proses, atau keadaan", listOf("Waktu kejadian", "Lokasi tempat", "Nama pelaku tindakan")),
            Triple("Kata tanya 'Siapa' digunakan khusus untuk menanyakan apa?", "Orang atau pelaku yang terlibat", listOf("Benda mati", "Waktu siang atau malam", "Jumlah angka")),
            Triple("Kata tanya 'Berapa' digunakan dalam kalimat untuk menanyakan apa?", "Jumlah, takaran, atau harga", listOf("Tempat tinggal", "Alasan peristiwa", "Nama orang")),
            Triple("Manakah kata baku menurut kamus untuk sarung tangan penghangat?", "Sarung tangan", listOf("Sarong tangan", "Sarong tanggan", "Sarung tanggan")),
            Triple("Kata berlawanan (antonim) dari kata 'aktif' bergerak di kelas adalah?", "Pasif", listOf("Giat", "Lincah", "Semangat")),
            Triple("Kata dasar dari kata 'pendidikan' adalah kata apa?", "Didik", listOf("Pendidik", "Didikan", "Dikan")),
            Triple("Kata dasar dari kata 'permainan' adalah kata apa?", "Main", listOf("Permain", "Mainan", "Pemain")),
            Triple("Kata dasar dari kata 'makanan' adalah kata apa?", "Makan", listOf("Memakan", "Makanan", "Kanan")),
            Triple("Lengkapilah kalimat perbandingan ini: 'Gajah bertubuh besar, sedangkan kelinci bertubuh ...'", "kecil", listOf("tinggi", "panjang", "tebal")),
            Triple("Lengkapilah kalimat perbandingan ini: 'Cabai rasanya pedas, sedangkan gula rasanya ...'", "manis", listOf("asin", "pahit", "asam")),
            Triple("Lengkapilah kalimat perbandingan ini: 'Es rasanya dingin, sedangkan api terasa ...'", "panas", listOf("sejuk", "hangat", "empuk")),
            Triple("Lengkapilah kalimat ini: 'Siswa kelas dua sedang belajar ... di ruang kelas.'", "tertib", listOf("marah", "berisik", "kotor")),
            Triple("Kalimat yang isinya memberikan kabar informasi kepada pembaca disebut kalimat apa?", "Kalimat berita", listOf("Kalimat tanya", "Kalimat perintah", "Kalimat seru")),
            Triple("Tanda petik dua (\"...\") digunakan untuk mengapit apa dalam teks cerita?", "Petikan langsung dari pembicara", listOf("Nama kota saja", "Angka hitungan saja", "Akhir paragraf")),
            Triple("Di mana letak tanda titik (.) yang benar dalam suatu kalimat berita?", "Di akhir kalimat", listOf("Di awal kalimat", "Di tengah kalimat", "Setelah huruf pertama"))
        )
        for (mec in grammar78) {
            val wrongs = mec.third.take(3)
            val options = makeOptions(mec.second, wrongs[0], wrongs.getOrElse(1) { "LAIN" }, wrongs.getOrElse(2) { "BEDA" }, count = 4)

            questions.add(
                Question(
                    id = "bahasa_78_$qId",
                    category = QuizCategory.BAHASA_INDONESIA,
                    ageBracket = AgeBracket.AGE_7_8,
                    questionText = mec.first,
                    visualEmoji = "✍️ Tata Bahasa",
                    options = options,
                    correctIndex = 0,
                    explanation = "Jawaban yang benar adalah '${mec.second}'.",
                    hint = "Perhatikan aturan tata bahasa dan ejaan baku bahasa Indonesia.",
                    difficulty = "Sedang"
                )
            )
            qId++
        } // Exactly 150 questions for Age 7-8!

        return questions
    }

    // =========================================================================
    // USIA 9-10 TAHUN (150 PERTANYAAN ALAMI)
    // =========================================================================
    private fun generateAge910(): List<Question> {
        val questions = ArrayList<Question>(150)
        var qId = 1

        // 1. Analisis Kalimat SPOK & Konjungsi (50 pertanyaan unik alami)
        val spokPrompts = listOf(
            Triple("Dalam kalimat 'Pak Tani menanam padi di sawah', kata 'padi' menduduki fungsi apa?", "Objek", listOf("Subjek", "Predikat", "Keterangan tempat")),
            Triple("Dalam kalimat 'Ibu menyiram bunga setiap pagi di pekarangan', kata 'menyiram' berfungsi sebagai apa?", "Predikat", listOf("Subjek", "Objek", "Keterangan")),
            Triple("Dalam kalimat 'Siswa membaca buku di perpustakaan sekolah', frasa 'di perpustakaan sekolah' berfungsi sebagai apa?", "Keterangan tempat", listOf("Objek", "Subjek", "Predikat")),
            Triple("Dalam kalimat 'Dokter memeriksa pasien dengan teliti di ruang periksa', frasa 'dengan teliti' berfungsi sebagai apa?", "Keterangan cara", listOf("Keterangan tempat", "Objek", "Predikat")),
            Triple("Dalam kalimat 'Adik tertidur pulas pada malam hari di kamar', frasa 'pada malam hari' berfungsi sebagai apa?", "Keterangan waktu", listOf("Keterangan tempat", "Subjek", "Objek")),
            Triple("Manakah di antara pilihan kalimat berikut yang berpola lengkap Subjek - Predikat - Objek - Keterangan?", "Budi menyapu halaman di pagi hari.", listOf("Budi sedang membaca.", "Adik tertidur pulas.", "Ibu berbelanja di pasar.")),
            Triple("Dalam kalimat 'Rani melukis pemandangan alam nan indah', kata 'Rani' berkedudukan sebagai apa?", "Subjek", listOf("Predikat", "Objek", "Keterangan")),
            Triple("Kata kerja utama yang menyatakan tindakan subjek dalam sebuah kalimat tata bahasa disebut apa?", "Predikat", listOf("Subjek", "Objek", "Pelengkap")),
            Triple("Bagian kalimat yang menjadi sasaran langsung tindakan predikat transitif disebut apa?", "Objek", listOf("Predikat", "Keterangan", "Pelengkap")),
            Triple("Konjungsi antar klausa yang berfungsi menyatakan hubungan sebab adalah kata apa?", "karena", listOf("tetapi", "dan", "atau")),
            Triple("Konjungsi yang digunakan untuk menghubungkan dua pernyataan yang saling berlawanan adalah kata apa?", "tetapi", listOf("dan", "sehingga", "karena")),
            Triple("Konjungsi yang digunakan untuk menyatakan hubungan pemilihan di antara dua hal adalah kata apa?", "atau", listOf("dan", "tetapi", "karena")),
            Triple("Konjungsi yang digunakan untuk menyatakan hubungan penambahan adalah kata apa?", "dan", listOf("tetapi", "atau", "sehingga")),
            Triple("Konjungsi yang menyatakan akibat dari suatu tindakan atau peristiwa sebelumnya adalah kata apa?", "sehingga", listOf("tetapi", "dan", "atau")),
            Triple("Dalam kalimat 'Ayah memperbaiki sepeda motor di garasi', bagian manakah yang berkedudukan sebagai subjek?", "Ayah", listOf("memperbaiki", "sepeda motor", "di garasi")),
            Triple("Dalam kalimat 'Ayah memperbaiki sepeda motor di garasi', bagian manakah yang berfungsi sebagai predikat?", "memperbaiki", listOf("Ayah", "sepeda motor", "di garasi")),
            Triple("Dalam kalimat 'Ayah memperbaiki sepeda motor di garasi', bagian manakah yang berfungsi sebagai objek penderita?", "sepeda motor", listOf("Ayah", "memperbaiki", "di garasi")),
            Triple("Dalam kalimat 'Ayah memperbaiki sepeda motor di garasi', bagian manakah yang berfungsi sebagai keterangan tempat?", "di garasi", listOf("Ayah", "memperbaiki", "sepeda motor")),
            Triple("Kalimat 'Nelayan menangkap ikan tongkol di tengah laut' memiliki pola susunan apa?", "S - P - O - K", listOf("S - P - K", "S - P - O", "S - P")),
            Triple("Kalimat 'Burung-burung camar terbang tinggi' memiliki pola susunan apa?", "S - P - K", listOf("S - P - O", "S - P - O - K", "S - P")),
            Triple("Kalimat 'Adik bayi tersenyum manis' memiliki pola susunan fungsi apa?", "S - P - K", listOf("S - P - O", "S - P - O - K", "S - P")),
            Triple("Kalimat 'Kakek sedang mendengarkan siaran radio' memiliki pola susunan fungsi apa?", "S - P - O", listOf("S - P - K", "S - P", "S - P - O - K")),
            Triple("Kalimat yang hanya memiliki satu klausa pokok dengan subjek dan predikat disebut kalimat apa?", "Kalimat tunggal", listOf("Kalimat majemuk setara", "Kalimat majemuk bertingkat", "Kalimat tanya")),
            Triple("Kalimat yang terdiri dari dua klausa atau lebih yang digabungkan oleh kata penghubung disebut kalimat apa?", "Kalimat majemuk", listOf("Kalimat tunggal", "Kalimat pasif", "Kalimat perintah")),
            Triple("Kalimat di mana subjek melakukan suatu perbuatan aktif disebut kalimat apa?", "Kalimat aktif", listOf("Kalimat pasif", "Kalimat tanya", "Kalimat perintah")),
            Triple("Kalimat di mana subjek dikenai pekerjaan oleh pelaku lain disebut kalimat apa?", "Kalimat pasif", listOf("Kalimat aktif", "Kalimat ajakan", "Kalimat sapaan")),
            Triple("Bentuk pasif dari kalimat aktif 'Kucing menangkap tikus' adalah kalimat apa?", "Tikus ditangkap kucing", listOf("Kucing ditangkap tikus", "Tikus menangkap kucing", "Kucing mengejar tikus")),
            Triple("Bentuk pasif dari kalimat aktif 'Ibu membuat kue bolu' adalah kalimat apa?", "Kue bolu dibuat oleh Ibu", listOf("Ibu dibuat kue bolu", "Kue bolu membuat Ibu", "Ibu membeli kue bolu")),
            Triple("Bentuk pasif dari kalimat aktif 'Dedi menendang bola ke gawang' adalah kalimat apa?", "Bola ditendang Dedi ke gawang", listOf("Dedi ditendang bola ke gawang", "Gawang ditendang Dedi ke bola", "Bola membawa Dedi")),
            Triple("Bentuk aktif dari kalimat pasif 'Surat kabar dibaca kakek di teras' adalah kalimat apa?", "Kakek membaca surat kabar di teras", listOf("Kakek dibaca surat kabar", "Surat kabar membaca kakek", "Teras dibaca kakek")),
            Triple("Awalan (prefiks) yang biasanya membentuk kata kerja pasif dalam bahasa Indonesia adalah?", "Awalan di-", listOf("Awalan me-", "Awalan ber-", "Awalan ter-")),
            Triple("Awalan (prefiks) yang umumnya membentuk kata kerja aktif transitif adalah?", "Awalan me-", listOf("Awalan di-", "Awalan ke-", "Awalan ter-")),
            Triple("Awalan 'ter-' pada kata 'tertumpah' memiliki makna apa?", "Perbuatan yang tidak disengaja", listOf("Perbuatan yang direncanakan", "Saling melakukan perbuatan", "Sedang mengerjakan sesuatu")),
            Triple("Awalan 'ter-' pada kata 'terpandai' di kelas memiliki makna gramatikal apa?", "Paling atau teramat pandai", listOf("Tidak sengaja pandai", "Saling pandai", "Akan menjadi pandai")),
            Triple("Kata ulang 'berlari-lari' memiliki makna proses yang bagaimana?", "Melakukan tindakan santai berulang kali", listOf("Paling cepat berlari", "Saling berlari", "Banyak orang berlari")),
            Triple("Kata ulang 'bersalam-salaman' memiliki makna hubungan yang bagaimana?", "Saling melakukan tindakan bersalaman", listOf("Tidak sengaja bersalaman", "Sendirian bersalaman", "Paling pandai bersalaman")),
            Triple("Kata ulang 'sayur-mayur' merupakan contoh dari kata ulang jenis apa?", "Kata ulang berubah bunyi", listOf("Kata ulang utuh", "Kata ulang semu", "Kata ulang berimbuhan")),
            Triple("Kata ulang 'kupu-kupu' tergolong ke dalam jenis kata ulang apa?", "Kata ulang semu", listOf("Kata ulang utuh", "Kata ulang berubah bunyi", "Kata ulang sebagian")),
            Triple("Kata ulang 'dedaunan' yang berasal dari kata dasar 'daun' tergolong kata ulang apa?", "Kata ulang dwipurwa (sebagian)", listOf("Kata ulang semu", "Kata ulang utuh", "Kata ulang berubah bunyi")),
            Triple("Kalimat 'Meskipun hari hujan deras, Doni tetap berangkat sekolah' menggunakan konjungsi bertingkat apa?", "Meskipun", listOf("tetap", "deras", "sekolah")),
            Triple("Konjungsi 'meskipun' dalam sebuah kalimat menyatakan hubungan makna apa?", "Hubungan pertentangan / perlawanan", listOf("Hubungan penambahan", "Hubungan sebab akibat", "Hubungan tujuan")),
            Triple("Konjungsi 'agar' atau 'supaya' dalam kalimat berfungsi menyatakan hubungan makna apa?", "Hubungan tujuan atau harapan", listOf("Hubungan waktu kejadian", "Hubungan pertentangan", "Hubungan sebab")),
            Triple("Dalam kalimat 'Kakak belajar rajin agar lulus ujian', kata 'agar' bertindak sebagai apa?", "Konjungsi tujuan", listOf("Subjek kalimat", "Predikat kalimat", "Keterangan tempat")),
            Triple("Kata ganti orang pertama tunggal yang sopan dalam percakapan formal bahasa Indonesia adalah?", "Saya", listOf("Kamu", "Mereka", "Dia")),
            Triple("Kata ganti orang kedua tunggal yang santun untuk menyapa lawan bicara adalah?", "Anda", listOf("Saya", "Kita", "Kalian")),
            Triple("Kata ganti orang pertama jamak yang menyertakan pembicara dan pendengar adalah?", "Kita", listOf("Kami", "Mereka", "Kalian")),
            Triple("Kata ganti orang pertama jamak yang tidak menyertakan lawan bicara adalah?", "Kami", listOf("Kita", "Mereka", "Kalian")),
            Triple("Kata ganti penunjuk benda yang letaknya dekat dengan posisi pembicara adalah?", "Ini", listOf("Itu", "Sana", "Situ")),
            Triple("Kata ganti penunjuk benda yang letaknya jauh dari posisi pembicara adalah?", "Itu", listOf("Ini", "Sini", "Begini")),
            Triple("Bagian karangan yang memuat gagasan pokok dan tersusun atas beberapa kalimat padu disebut apa?", "Paragraf", listOf("Kata", "Frasa", "Klausa"))
        )
        for (item in spokPrompts) {
            val wrongs = item.third.take(3)
            val options = makeOptions(item.second, wrongs[0], wrongs.getOrElse(1) { "LAIN" }, wrongs.getOrElse(2) { "BEDA" }, count = 4)

            questions.add(
                Question(
                    id = "bahasa_910_$qId",
                    category = QuizCategory.BAHASA_INDONESIA,
                    ageBracket = AgeBracket.AGE_9_10,
                    questionText = item.first,
                    visualEmoji = "🧩 S-P-O-K",
                    options = options,
                    correctIndex = 0,
                    explanation = "Jawaban yang benar adalah '${item.second}'.",
                    hint = "Analisis peran kata dan struktur pembentuk kalimat.",
                    difficulty = "Tantangan"
                )
            )
            qId++
        } // 50 questions done

        // 2. Peribahasa dan Ungkapan Tradisional (50 pertanyaan unik alami)
        val proverbs910 = listOf(
            Triple("Arti peribahasa 'Air beriak tanda tak dalam' adalah?", "Orang banyak bicara biasanya ilmunya sedikit", listOf("Air sungai mengalir sangat tenang", "Orang pandai selalu bersikap pendiam", "Air dangkal sangat berbahaya dilewati")),
            Triple("Arti peribahasa 'Tong kosong nyaring bunyinya' adalah?", "Orang yang sombong biasanya tidak ada kepandaian nyatanya", listOf("Tong kayu yang berbunyi merdu saat dipukul", "Orang pandai berbicara dengan tegas", "Tong plastik yang tidak berisi air")),
            Triple("Lanjutan yang tepat dari peribahasa 'Berakit-rakit ke hulu, berenang-renang ke ...' adalah?", "tepian", listOf("lautan", "sungai", "muara")),
            Triple("Lanjutan yang tepat dari peribahasa 'Bersakit-sakit dahulu, bersenang-senang ...' adalah?", "kemudian", listOf("sekarang", "selamanya", "nantian")),
            Triple("Arti peribahasa 'Di mana bumi dipijak, di situ langit dijunjung' adalah?", "Wajib menghormati adat istiadat tempat kita berada", listOf("Bumi selalu berada tepat di bawah langit", "Selalu menengadah memandang ke atas langit", "Hanya bangga pada tanah kelahiran sendiri")),
            Triple("Lanjutan yang tepat dari peribahasa 'Seperti ilmu padi, makin berisi makin ...' adalah?", "merunduk", listOf("tinggi", "tegak", "bergoyang")),
            Triple("Arti ungkapan kiasan 'rendah hati' dalam pergaulan sehari-hari adalah?", "Sikap tidak sombong dan santun kepada sesama", listOf("Merasa rendah diri dan takut bicara", "Pemalu saat diajak berkenalan", "Mudah menyerah pada kesulitan")),
            Triple("Arti ungkapan 'lapang dada' ketika menghadapi kekalahan adalah?", "Ikhlas dan sabar menerima kenyataan", listOf("Bernapas dengan lega dan dalam", "Dada yang berukuran lebar", "Suka berolahraga senam pagi")),
            Triple("Lanjutan yang benar dari peribahasa 'Malu bertanya sesat di ...' adalah?", "jalan", listOf("hutan", "sungai", "kota")),
            Triple("Lanjutan yang benar dari peribahasa 'Bersatu kita teguh, bercerai kita ...' adalah?", "runtuh", listOf("jatuh", "pecah", "hilang")),
            Triple("Arti peribahasa 'Ada gula ada semut' adalah?", "Di tempat yang banyak rezeki pasti banyak orang berkumpul", listOf("Semut sangat menyukai gula pasir manis", "Gula selalu dijaga oleh kerumunan semut", "Jangan menaruh gula di lantai rumah")),
            Triple("Arti peribahasa 'Sedia payung sebelum hujan' adalah?", "Mempersiapkan pencegahan sebelum masalah datang", listOf("Membawa payung hitam ke mana pun pergi", "Menunggu hujan reda di teras rumah", "Membeli payung baru saat musim kemarau")),
            Triple("Arti peribahasa 'Bagai pinang dibelah dua' adalah?", "Dua orang yang wajah dan sifatnya sangat mirip", listOf("Buah pinang yang dipotong pisau tajam", "Dua benda yang saling bertolak belakang", "Pohon pinang yang tumbuh bercabang")),
            Triple("Arti peribahasa 'Air tenang menghanyutkan' adalah?", "Orang pendiam tetapi memiliki ilmu yang sangat dalam", listOf("Air kolam yang tenang sangat dingin", "Sungai yang jernih airnya mengalir deras", "Orang penakut yang tidak mau berbicara")),
            Triple("Arti peribahasa 'Nasi sudah menjadi bubur' adalah?", "Penyesalan atas perbuatan yang sudah terlanjur terjadi", listOf("Memasak bubur ayam gurih di pagi hari", "Nasi dingin yang diberi air panas", "Gagal memasak nasi pulen")),
            Triple("Arti peribahasa 'Tak ada gading yang tak retak' adalah?", "Tidak ada manusia yang sempurna tanpa cela", listOf("Gading gajah liar mudah patah", "Barang antik selalu memiliki retakan", "Gajah hutan memiliki gading putih")),
            Triple("Arti peribahasa 'Air susu dibalas dengan air tuba' adalah?", "Kebaikan tulus dibalas dengan kejahatan", listOf("Menukar susu manis dengan racun", "Air putih yang berubah menjadi keruh", "Minuman beracun yang sangat berbahaya")),
            Triple("Arti peribahasa 'Kacang lupa akan kulitnya' adalah?", "Orang yang sombong melupakan asal usulnya setelah sukses", listOf("Mengupas kulit kacang tanah goreng", "Membuang kulit kacang sembarangan", "Kacang kedelai yang diolah menjadi tempe")),
            Triple("Arti peribahasa 'Sepandai-pandai tupai melompat, sekali waktu akan ... juga' adalah?", "gagal atau jatuh", listOf("terbang tinggi", "tidur lelap", "berlari cepat")),
            Triple("Arti peribahasa 'Besar pasak daripada tiang' adalah?", "Pengeluaran belanja lebih besar daripada pendapatan", listOf("Membangun tiang rumah yang sangat besar", "Tiang kayu yang dipukul pasak besi", "Pemasukan uang lebih banyak dari belanja")),
            Triple("Arti peribahasa 'Bagaikan katak dalam tempurung' adalah?", "Orang yang wawasan pengetahuannya sangat sempit", listOf("Katak hijau yang bersembunyi di tempurung kelapa", "Tempurung kelapa yang hanyut di sungai", "Katak sawah yang bersuara nyaring")),
            Triple("Arti peribahasa 'Gali lubang tutup lubang' dalam hal keuangan adalah?", "Membayar utang lama dengan membuat utang yang baru", listOf("Menggali tanah kebun untuk menanam bibit", "Menimbun lubang jalan dengan batu kali", "Membangun sumur air bersih")),
            Triple("Arti peribahasa 'Bagaikan api dalam sekam' adalah?", "Bahaya tersembunyi yang sewaktu-waktu dapat berkobar", listOf("Sekam padi yang dibakar petani di sawah", "Api unggun yang menyala terang benderang", "Asap tebal yang mengepul di udara")),
            Triple("Arti peribahasa 'Sekali mendayung perahu, dua tiga pulau terlampaui' adalah?", "Sekali melakukan tindakan memperoleh beberapa manfaat", listOf("Mendayung perahu kayu melintasi samudra", "Berlibur ke pulau-pulau eksotis", "Lomba perahu dayung tradisional")),
            Triple("Arti peribahasa 'Musang berbulu domba' adalah?", "Orang jahat yang pura-pura bersikap baik dan ramah", listOf("Musang hutan yang memakai bulu domba", "Domba putih yang dipelihara di kandang", "Hewan pemangsa yang jinak")),
            Triple("Arti ungkapan 'panjang tangan' adalah?", "Suka mengambil barang milik orang lain (mencuri)", listOf("Ukuran tangan yang melebihi normal", "Suka menolong orang yang kesulitan", "Suka berjabat tangan dengan teman")),
            Triple("Arti ungkapan 'ringan tangan' saat melihat tetangga bergotong royong adalah?", "Suka membantu dan menolong sesama", listOf("Tangannya tidak memiliki tenaga berat", "Mudah memukul orang lain saat marah", "Suka bermain bulu tangkis")),
            Triple("Arti ungkapan 'darah dingin' saat mengambil keputusan genting adalah?", "Sikap tenang dan tidak panik dalam situasi sulit", listOf("Suhu darah tubuh yang menurun drastis", "Kondisi orang yang kedinginan di kutub", "Penyakit kekurangan sel darah merah")),
            Triple("Arti ungkapan 'kambing hitam' dalam suatu persoalan adalah?", "Orang yang dipersalahkan atas perbuatan orang lain", listOf("Kambing peliharaan yang berbulu hitam legam", "Hewan ternak kurban di hari raya", "Kambing liar di padang rumput")),
            Triple("Arti ungkapan 'cuci tangan' ketika suatu masalah timbul adalah?", "Tidak mau bertanggung jawab atas kesalahan yang terjadi", listOf("Membersihkan telapak tangan dengan air dan sabun", "Membasuh tangan sebelum menyantap hidangan", "Menyiram tanaman dengan selang air")),
            Triple("Arti ungkapan 'banting tulang' yang dilakukan seorang ayah adalah?", "Bekerja keras tanpa kenal lelah demi keluarga", listOf("Tulang tubuh yang patah terbentur tanah", "Berlatih seni bela diri gulat", "Membawa beban berat di punggung")),
            Triple("Arti ungkapan 'gulung tikar' yang dialami seorang pengusaha adalah?", "Mengalami kebangkrutan usaha", listOf("Merapikan tikar pandan sehabis duduk", "Membeli tikar baru untuk ruang tamu", "Menjual tikar anyaman tradisional")),
            Triple("Arti ungkapan 'naik daun' bagi seorang seniman cilik berbakat adalah?", "Sedang berada di puncak popularitas dan sukses", listOf("Memanjat daun pohon kelapa yang tinggi", "Daun tanaman yang tumbuh memanjang ke atas", "Memungut daun gugur di halaman taman")),
            Triple("Arti ungkapan 'muka masam' saat seseorang sedang kecewa adalah?", "Wajah yang cemberut tampak tidak senang", listOf("Wajah orang sehabis memakan buah asam", "Kulit wajah yang terkena air cuka", "Wajah yang tersenyum riang gembira")),
            Triple("Arti ungkapan 'tutup usia' yang tertulis dalam berita duka adalah?", "Meninggal dunia", listOf("Merayakan hari ulang tahun", "Menghitung jumlah umur hidup", "Menutup kalender tahunan")),
            Triple("Arti ungkapan 'angkat kaki' dari suatu tempat pertemuan adalah?", "Pergi atau meninggalkan tempat tersebut", listOf("Mengangkat satu kaki saat berdiri tegak", "Melompati rintangan di jalanan", "Membersihkan kotoran di sepatu")),
            Triple("Arti peribahasa 'Menepuk air di dulang, terpercik muka sendiri' adalah?", "Membuka aib keluarga sendiri akan mempermalukan diri sendiri", listOf("Bermain percikan air di baskom cuci", "Mencuci muka dengan air sejuk di pagi hari", "Menyiram air ke tanah kering")),
            Triple("Arti ungkapan 'buah bibir' dalam pembicaraan hangat masyarakat adalah?", "Bahan perbincangan atau topik yang ramai dibicarakan", listOf("Buah yang manis dimakan dengan bibir", "Bibir yang berwarna merah merekah", "Bicara manis untuk merayu orang lain")),
            Triple("Arti ungkapan 'makan hati' ketika menghadapi perlakuan buruk adalah?", "Menderita batin menahan rasa sedih dan kecewa", listOf("Menyantap masakan hati sapi pedas", "Menjaga kesehatan organ hati tubuh", "Suka memarahi orang lain")),
            Triple("Arti peribahasa 'Harimau mati meninggalkan belang, gajah mati meninggalkan gading' adalah?", "Manusia yang wafat dikenang karena jasa dan perbuatannya", listOf("Kulit harimau loreng sangat berharga", "Gading gajah putih sangat mahal harganya", "Hewan liar dilindungi di suaka margasatwa")),
            Triple("Lanjutan yang tepat dari peribahasa 'Lidah tak bertulang, kata-kata tak ...' adalah?", "bertepi", listOf("berbunyi", "bermakna", "berharga")),
            Triple("Arti ungkapan 'lupa daratan' ketika seseorang memperoleh banyak pujian adalah?", "Menjadi sombong dan kehilangan kendali diri", listOf("Tersesat saat berlayar di tengah samudra", "Tidak menemukan jalan pulang ke darat", "Berada di atas pesawat terbang")),
            Triple("Arti ungkapan 'kaki tangan' seorang pemimpin organisasi adalah?", "Orang kepercayaan yang membantu melaksanakan tugas", listOf("Kedua tangan dan kedua kaki tubuh", "Anggota tubuh yang bertugas bergerak", "Peralatan bantu untuk berjalan")),
            Triple("Arti ungkapan 'senyum simpul' yang tampak di wajah seseorang adalah?", "Senyum tipis yang penuh arti rahasia", listOf("Senyuman lebar menampakkan gigi", "Tali yang diikat membentuk simpul", "Wajah orang yang sedang menangis")),
            Triple("Arti peribahasa 'Anjing menggonggong, kafilah tetap berlalu' adalah?", "Terus maju pantang mundur walau banyak cemoohan", listOf("Anjing penjaga yang setia mengawal tuannya", "Rombongan unta yang melintasi gurun pasir", "Mendengarkan semua pendapat orang lain")),
            Triple("Arti ungkapan 'lapang dada' terhadap kritik yang membangun adalah?", "Menerima saran dengan pikiran terbuka dan tidak tersinggung", listOf("Melonggarkan kancing kemeja di dada", "Dada yang lebar dan atletis", "Berteriak lantang di lapangan luas")),
            Triple("Arti ungkapan 'keras kepala' yang dimiliki oleh seorang anak adalah?", "Sukar dinasihati dan bersikukuh pada kemauannya sendiri", listOf("Tulang tengkorak kepala yang sangat kuat", "Kepala yang sakit karena terbentur batu", "Anak yang rajin belajar di sekolah")),
            Triple("Arti ungkapan 'darah biru' dalam konteks silsilah keturunan adalah?", "Keturunan bangsawan atau keluarga ningrat raja", listOf("Orang yang warna darahnya biru muda", "Penyakit darah langka di rumah sakit", "Orang yang suka memakai baju biru")),
            Triple("Arti ungkapan 'otak encer' yang disematkan pada siswa juara adalah?", "Cerdas, pandai, dan cepat tanggap memahami pelajaran", listOf("Cairan di dalam rongga otak manusia", "Kepala pusing karena belajar berlebihan", "Siswa yang suka minum susu cair")),
            Triple("Arti peribahasa 'Bagai pungguk merindukan bulan' adalah?", "Mengharapkan sesuatu hal yang mustahil untuk digapai", listOf("Burung pungguk yang terbang di malam hari", "Bulan sabit yang tampak indah di langit malam", "Burung malam yang merindukan sarangnya"))
        )
        for (item in proverbs910) {
            val wrongs = item.third.take(3)
            val options = makeOptions(item.second, wrongs[0], wrongs.getOrElse(1) { "LAIN" }, wrongs.getOrElse(2) { "BEDA" }, count = 4)

            questions.add(
                Question(
                    id = "bahasa_910_$qId",
                    category = QuizCategory.BAHASA_INDONESIA,
                    ageBracket = AgeBracket.AGE_9_10,
                    questionText = item.first,
                    visualEmoji = "📜 Peribahasa",
                    options = options,
                    correctIndex = 0,
                    explanation = "Jawaban yang tepat adalah '${item.second}'.",
                    hint = "Ingat pesan moral dan kearifan peribahasa nusantara.",
                    difficulty = "Tantangan"
                )
            )
            qId++
        } // 100 questions done

        // 3. PUEBI, Ejaan, Pantun, Majas & Sastra (50 pertanyaan unik alami)
        val advancedPuebi = listOf(
            Triple("Manakah penulisan kata baku menurut PUEBI / KBBI untuk petunjuk kebaikan?", "Nasihat", listOf("Nasehat", "Nasehad", "Nasikhat")),
            Triple("Manakah penulisan kata baku menurut PUEBI / KBBI untuk kegiatan menerapkan teori?", "Praktik", listOf("Praktek", "Practic", "Praktikkan")),
            Triple("Manakah penulisan kata baku menurut PUEBI / KBBI untuk susunan rencana kegiatan?", "Jadwal", listOf("Jadual", "Jadwalin", "Jatwal")),
            Triple("Manakah penulisan kata baku menurut PUEBI / KBBI untuk tempat periksa dokter spesialis?", "Klinik", listOf("Kliniek", "Klenik", "Clinik")),
            Triple("Manakah penulisan kata baku menurut PUEBI / KBBI untuk lembaran tanda terima pembayaran?", "Kuitansi", listOf("Kwitansi", "Kwintansi", "Kuitansiil")),
            Triple("Manakah penulisan kata baku menurut PUEBI / KBBI untuk sistem pertahanan tubuh?", "Sistem", listOf("Sistim", "Systeim", "System")),
            Triple("Manakah penulisan kata baku menurut PUEBI / KBBI untuk pekerjaan khusus seseorang?", "Karier", listOf("Karir", "Carear", "Karirrr")),
            Triple("Manakah penulisan kata baku menurut PUEBI / KBBI untuk sarana transportasi gerbong rel?", "Kereta", listOf("Krita", "Krete", "Keretta")),
            Triple("Manakah penulisan kata baku menurut PUEBI / KBBI untuk bahan pembuat kain?", "Kaus", listOf("Kaos", "Kahos", "Koas")),
            Triple("Manakah penulisan kata baku menurut PUEBI / KBBI untuk suasana ramai tanpa aturan?", "Kacau", listOf("Kacauw", "Kacaou", "Khacau")),
            Triple("Puisi lama empat baris bersajak a-b-a-b yang terdiri atas sampiran dan isi disebut apa?", "Pantun", listOf("Syair", "Gurindam", "Cerpen")),
            Triple("Baris pertama dan baris kedua pada sebuah bait pantun berfungsi sebagai apa?", "Sampiran pantun", listOf("Isi pantun", "Tema pantun", "Amanat pantun")),
            Triple("Baris ketiga dan baris keempat pada sebuah bait pantun memuat apa?", "Isi dan maksud pantun", listOf("Sampiran pantun", "Rima luaran", "Judul pantun")),
            Triple("Puisi lama bersajak terus a-a-a-a yang berasal dari tradisi sastra Arab-Persia disebut apa?", "Syair", listOf("Pantun", "Gurindam", "Soneta")),
            Triple("Puisi lama dua baris bersajak a-a yang memuat nasihat moral berpasangan disebut apa?", "Gurindam", listOf("Pantun", "Syair", "Karmina")),
            Triple("Gaya bahasa yang membandingkan benda mati seolah-olah bernyawa dan berperilaku seperti manusia disebut?", "Majas Personifikasi", listOf("Majas Metafora", "Majas Hiperbola", "Majas Litotes")),
            Triple("Gaya bahasa yang menyatakan perbandingan langsung tanpa menggunakan kata penghubung seperti majas kiasan disebut?", "Majas Metafora", listOf("Majas Personifikasi", "Majas Hiperbola", "Majas Litotes")),
            Triple("Gaya bahasa yang melebih-lebihkan kenyataan secara luar biasa untuk memberi penekanan disebut?", "Majas Hiperbola", listOf("Majas Litotes", "Majas Personifikasi", "Majas Metafora")),
            Triple("Gaya bahasa yang merendahkan diri dengan maksud bersikap santun disebut?", "Majas Litotes", listOf("Majas Hiperbola", "Majas Metafora", "Majas Personifikasi")),
            Triple("Kalimat 'Ombak berkejar-kejaran di tepi pantai pasir putih' merupakan contoh penggunaan majas apa?", "Personifikasi", listOf("Hiperbola", "Metafora", "Litotes")),
            Triple("Kalimat 'Suaranya menggelegar membelah angkasa raya' merupakan contoh penggunaan majas apa?", "Hiperbola", listOf("Litotes", "Personifikasi", "Metafora")),
            Triple("Kalimat 'Buku adalah jendela dunia yang membuka wawasan ilmu' merupakan contoh majas apa?", "Metafora", listOf("Personifikasi", "Hiperbola", "Litotes")),
            Triple("Kalimat 'Mampirlah ke gubuk kami yang sederhana ini' merupakan contoh dari majas apa?", "Litotes", listOf("Hiperbola", "Personifikasi", "Metafora")),
            Triple("Penulisan nama kota dan provinsi yang benar menggunakan huruf kapital menurut PUEBI adalah?", "Surabaya, Jawa Timur", listOf("surabaya, jawa timur", "Surabaya, jawa Timur", "surabaya, Jawa timur")),
            Triple("Penulisan judul buku karangan yang tepat sesuai kaidah penulisan huruf kapital adalah?", "Petualangan Pintar di Hutan Tropis", listOf("petualangan pintar di hutan tropis", "Petualangan Pintar Di Hutan Tropis", "Petualangan pintar di hutan tropis")),
            Triple("Unsur intrinsik cerita yang menunjukkan pesan moral didikan yang ingin disampaikan pengarang disebut?", "Amanat", listOf("Alur", "Latar", "Tokoh")),
            Triple("Rangkaian peristiwa sebab-akibat yang membangun jalannya cerita dari awal sampai akhir disebut?", "Alur (Plot)", listOf("Latar", "Tokoh", "Tema")),
            Triple("Keterangan mengenai waktu, tempat, dan suasana berlangsungnya peristiwa dalam cerita disebut?", "Latar (Setting)", listOf("Alur", "Amanat", "Tokoh")),
            Triple("Tokoh utama dalam sebuah cerita yang memiliki sifat baik dan berbudi luhur disebut tokoh apa?", "Tokoh Protagonis", listOf("Tokoh Antagonis", "Tokoh Tritagonis", "Tokoh Figuran")),
            Triple("Tokoh penentang tokoh utama yang umumnya berwatak jahat atau memicu konflik disebut tokoh apa?", "Tokoh Antagonis", listOf("Tokoh Protagonis", "Tokoh Tritagonis", "Tokoh Figuran")),
            Triple("Tokoh penengah yang bijaksana di antara pihak yang berselisih dalam alur dongeng disebut tokoh apa?", "Tokoh Tritagonis", listOf("Tokoh Protagonis", "Tokoh Antagonis", "Tokoh Figuran")),
            Triple("Sudut pandang pengarang yang menggunakan kata ganti 'aku' atau 'saya' sebagai pelaku cerita disebut sudut pandang apa?", "Sudut pandang orang pertama", listOf("Sudut pandang orang ketiga", "Sudut pandang serba tahu", "Sudut pandang orang kedua")),
            Triple("Sudut pandang pengarang yang menggunakan nama tokoh atau kata ganti 'ia' dan 'mereka' disebut sudut pandang apa?", "Sudut pandang orang ketiga", listOf("Sudut pandang orang pertama", "Sudut pandang campuran", "Sudut pandang orang kedua")),
            Triple("Cerita rakyat tradisional yang menceritakan tentang asal usul penamaan suatu tempat atau danau disebut?", "Legenda", listOf("Mite", "Fabel", "Sage")),
            Triple("Cerita dongeng dengan tokoh binatang yang dapat berbicara dan berperilaku layaknya manusia disebut?", "Fabel", listOf("Legenda", "Mite", "Hikayat")),
            Triple("Cerita rakyat yang berhubungan dengan kisah dewa-dewi atau kekuatan gaib supranatural disebut?", "Mite (Mitos)", listOf("Fabel", "Sage", "Cerpen")),
            Triple("Cerita rakyat yang memuat kisah kepahlawanan atau keberanian ksatria zaman dahulu disebut?", "Sage", listOf("Mite", "Fabel", "Anekdot")),
            Triple("Cerita lucu yang singkat dan menarik serta mengandung pesan kritikan atau sindiran halus disebut?", "Anekdot", listOf("Fabel", "Legenda", "Sage")),
            Triple("Sinonim dari kata 'reboisasi' dalam upaya pelestarian lingkungan hidup adalah?", "Penghijauan kembali", listOf("Penebangan pohon", "Pembakaran hutan", "Penggalian tambang")),
            Triple("Sinonim dari kata 'evakuasi' saat terjadi bencana alam gunung meletus adalah?", "Penyelamatan warga", listOf("Pemberian nama", "Pemeriksaan kesehatan saja", "Pembangunan posko saja")),
            Triple("Lawan kata (antonim) dari kata 'konvergen' (memusat ke satu titik) adalah kata apa?", "Divergen (Menyebar)", listOf("Lurus", "Paralel", "Melengkung")),
            Triple("Lawan kata (antonim) dari kata 'fakta' (kenyataan yang sebenarnya) dalam teks berita adalah?", "Opini (Pendapat)", listOf("Berita", "Kabar", "Bukti")),
            Triple("Pernyataan yang dapat dibuktikan kebenarannya berdasarkan bukti nyata di lapangan disebut kalimat apa?", "Kalimat fakta", listOf("Kalimat opini", "Kalimat tanya", "Kalimat ajakan")),
            Triple("Pernyataan yang masih berupa tanggapan, pikiran, atau pendapat subjektif seseorang disebut kalimat apa?", "Kalimat opini", listOf("Kalimat fakta", "Kalimat baku", "Kalimat efektif")),
            Triple("Kalimat yang disusun secara tepat memenuhi kaidah tata bahasa dan mudah dipahami tanpa makna ganda disebut?", "Kalimat efektif", listOf("Kalimat bertele-tele", "Kalimat kiasan", "Kalimat ambigu")),
            Triple("Daftar kata istilah penting beserta penjelasannya yang biasanya diletakkan di halaman akhir buku disebut?", "Glosarium", listOf("Daftar pustaka", "Indeks", "Kata pengantar")),
            Triple("Daftar alfabetis kata atau istilah di buku yang disertai halaman kemunculannya disebut apa?", "Indeks", listOf("Glosarium", "Daftar isi", "Daftar pustaka")),
            Triple("Daftar sumber buku, jurnal, dan rujukan yang digunakan oleh penulis di akhir karangan disebut apa?", "Daftar pustaka", listOf("Glosarium", "Indeks", "Daftar isi")),
            Triple("Tanda hubung (-) digunakan dalam penulisan kata bahasa Indonesia untuk merangkaikan apa?", "Kata ulang dan bentuk terikat", listOf("Akhir kalimat berita", "Awal alinea baru", "Nama penulis")),
            Triple("Tanda pisah (—) dalam sebuah kalimat panjang digunakan untuk menandai apa?", "Penyisipan keterangan penjelas", listOf("Pertanyaan penutup", "Perintah langsung", "Singkatan nama"))
        )
        for (item in advancedPuebi) {
            val wrongs = item.third.take(3)
            val options = makeOptions(item.second, wrongs[0], wrongs.getOrElse(1) { "LAIN" }, wrongs.getOrElse(2) { "BEDA" }, count = 4)

            questions.add(
                Question(
                    id = "bahasa_910_$qId",
                    category = QuizCategory.BAHASA_INDONESIA,
                    ageBracket = AgeBracket.AGE_9_10,
                    questionText = item.first,
                    visualEmoji = "📚 Bahasa Indonesia",
                    options = options,
                    correctIndex = 0,
                    explanation = "Jawaban yang benar adalah '${item.second}'.",
                    hint = "Ingat kaidah PUEBI, ejaan baku, dan sastra bahasa Indonesia.",
                    difficulty = "Tantangan"
                )
            )
            qId++
        } // Exactly 150 questions for Age 9-10!

        return questions
    }
}
