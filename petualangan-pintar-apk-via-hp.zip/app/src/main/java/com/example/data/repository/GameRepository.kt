package com.example.data.repository

import com.example.data.local.AppDatabase
import com.example.data.local.BadgeEntity
import com.example.data.local.CategoryProgressEntity
import com.example.data.local.GameDao
import com.example.data.local.QuizHistoryEntity
import com.example.data.local.UserProfileEntity
import com.example.data.model.AgeBracket
import com.example.data.model.BadgeInfo
import com.example.data.model.Question
import com.example.data.model.QuestionAnswerRecord
import com.example.data.model.QuizCategory
import com.example.data.model.QuizResultSummary
import com.example.data.source.QuestionBank
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext

class GameRepository(private val dao: GameDao) {

    val userProfile: Flow<UserProfileEntity> = dao.getUserProfile().map { profile ->
        profile ?: UserProfileEntity().also { defaultProfile ->
            withContext(Dispatchers.IO) {
                dao.insertOrUpdateProfile(defaultProfile)
            }
        }
    }.flowOn(Dispatchers.IO)

    val categoryProgressList: Flow<List<CategoryProgressEntity>> = dao.getAllCategoryProgress().map { list ->
        if (list.isEmpty()) {
            withContext(Dispatchers.IO) {
                AppDatabase.seedInitialData(dao)
            }
        }
        list
    }.flowOn(Dispatchers.IO)

    val allBadges: Flow<List<BadgeInfo>> = dao.getAllBadges().map { list ->
        if (list.isEmpty()) {
            withContext(Dispatchers.IO) {
                AppDatabase.seedInitialData(dao)
            }
        }
        list.map {
            BadgeInfo(
                id = it.id,
                title = it.title,
                description = it.description,
                emoji = it.emoji,
                isUnlocked = it.isUnlocked,
                unlockedAt = it.unlockedAt
            )
        }
    }.flowOn(Dispatchers.IO)

    val recentHistory: Flow<List<QuizHistoryEntity>> = dao.getRecentHistory().flowOn(Dispatchers.IO)

    suspend fun getQuestionsForQuiz(
        category: QuizCategory,
        ageBracket: AgeBracket
    ): List<Question> = withContext(Dispatchers.IO) {
        val progress = dao.getCategoryProgress(category.id)
        val level = progress?.currentLevel ?: 1
        QuestionBank.getQuestionsForQuiz(category, ageBracket, currentLevel = level, limit = 10)
    }

    suspend fun updateSelectedAge(ageBracket: AgeBracket) = withContext(Dispatchers.IO) {
        val current = UserProfileEntity(selectedAgeId = ageBracket.id)
        dao.insertOrUpdateProfile(current.copy(selectedAgeId = ageBracket.id))
    }

    suspend fun updateSettings(soundEnabled: Boolean, hapticEnabled: Boolean, ageBracket: AgeBracket) =
        withContext(Dispatchers.IO) {
            dao.insertOrUpdateProfile(
                UserProfileEntity(
                    id = 1,
                    selectedAgeId = ageBracket.id,
                    soundEnabled = soundEnabled,
                    hapticEnabled = hapticEnabled
                )
            )
        }

    suspend fun recordQuizCompletion(
        category: QuizCategory,
        ageBracket: AgeBracket,
        records: List<QuestionAnswerRecord>
    ): QuizResultSummary = withContext(Dispatchers.IO) {
        val correctCount = records.count { it.isCorrect }
        val hintsUsed = records.count { it.usedHint }
        val totalQuestions = records.size

        // Calculate stars (0 to 3)
        val stars = when {
            correctCount >= 9 -> 3
            correctCount >= 7 -> 2
            correctCount >= 4 -> 1
            else -> 0
        }

        val percentage = if (totalQuestions > 0) (correctCount * 100) / totalQuestions else 0

        // 1. Update Category Progress
        val existingProgress = dao.getCategoryProgress(category.id) ?: CategoryProgressEntity(categoryId = category.id)
        val newStars = existingProgress.starsEarned + stars
        val newHighScore = maxOf(existingProgress.highestScore, correctCount)
        val newTimesPlayed = existingProgress.timesPlayed + 1
        val newLevel = 1 + (newStars / 6) // Levels up every 6 stars

        val updatedProgress = existingProgress.copy(
            starsEarned = newStars,
            highestScore = newHighScore,
            timesPlayed = newTimesPlayed,
            currentLevel = newLevel
        )
        dao.insertCategoryProgress(updatedProgress)

        // 2. Save Session History locally
        dao.insertQuizHistory(
            QuizHistoryEntity(
                categoryId = category.id,
                ageBracketId = ageBracket.id,
                score = correctCount,
                totalQuestions = totalQuestions,
                starsEarned = stars,
                timestamp = System.currentTimeMillis()
            )
        )

        // 3. Read all categories to compute total stars & rank
        val allCategoryIds = listOf("math", "bahasa", "logika", "umum", "bonus")
        val allCategories = allCategoryIds.map { id ->
            dao.getCategoryProgress(id) ?: CategoryProgressEntity(categoryId = id)
        }
        val totalStarsSum = allCategories.sumOf { it.starsEarned }
        val totalCompletedSum = allCategories.sumOf { it.timesPlayed }

        val rank = when {
            totalStarsSum >= 40 -> "Legenda Penjelajah 👑"
            totalStarsSum >= 25 -> "Kapten Petualang 🧭"
            totalStarsSum >= 15 -> "Penjelajah Handal 🏕️"
            totalStarsSum >= 5 -> "Penjelajah Terampil 🎒"
            else -> "Penjelajah Pemula 🐣"
        }

        dao.insertOrUpdateProfile(
            UserProfileEntity(
                id = 1,
                selectedAgeId = ageBracket.id,
                totalStars = totalStarsSum,
                completedQuizzesCount = totalCompletedSum,
                explorerRank = rank
            )
        )

        // 4. Evaluate Badges
        val newlyUnlocked = mutableListOf<BadgeInfo>()
        val now = System.currentTimeMillis()

        suspend fun checkAndUnlock(badgeId: String) {
            val rows = dao.unlockBadge(badgeId, now)
            if (rows > 0) {
                val badgeMeta = when (badgeId) {
                    "badge_first_mission" -> BadgeInfo(badgeId, "Langkah Pertama", "Menyelesaikan kuis petualangan pertama", "🎒", true, now)
                    "badge_perfect_score" -> BadgeInfo(badgeId, "Bintang Sempurna", "Meraih skor 10/10 tanpa salah!", "🌟", true, now)
                    "badge_math_star" -> BadgeInfo(badgeId, "Jago Hitung Cilik", "Menyelesaikan misi kuis Matematika", "🧮", true, now)
                    "badge_bahasa_star" -> BadgeInfo(badgeId, "Kutu Buku Cilik", "Menyelesaikan misi Bahasa Indonesia", "📖", true, now)
                    "badge_logic_star" -> BadgeInfo(badgeId, "Detektif Pola", "Menyelesaikan misi Logika & Pola", "🧩", true, now)
                    "badge_nature_star" -> BadgeInfo(badgeId, "Sahabat Dunia", "Menyelesaikan misi Pengetahuan Umum", "🌍", true, now)
                    "badge_five_stars" -> BadgeInfo(badgeId, "Kolektor Bintang", "Kumpulkan total 15 bintang emas", "⭐", true, now)
                    "badge_explorer_master" -> BadgeInfo(badgeId, "Kapten Petualang", "Mencapai Level 5 dalam petualangan", "🧭", true, now)
                    "badge_no_hints" -> BadgeInfo(badgeId, "Mandiri Hebat", "Menyelesaikan sesi tanpa membuka petunjuk", "💡", true, now)
                    else -> null
                }
                badgeMeta?.let { newlyUnlocked.add(it) }
            }
        }

        // Always check first mission
        checkAndUnlock("badge_first_mission")

        // Perfect score
        if (correctCount == totalQuestions && totalQuestions >= 10) {
            checkAndUnlock("badge_perfect_score")
        }

        // Category specific badges
        when (category) {
            QuizCategory.MATEMATIKA -> checkAndUnlock("badge_math_star")
            QuizCategory.BAHASA_INDONESIA -> checkAndUnlock("badge_bahasa_star")
            QuizCategory.LOGIKA -> checkAndUnlock("badge_logic_star")
            QuizCategory.PENGETAHUAN_UMUM -> checkAndUnlock("badge_nature_star")
            QuizCategory.BONUS_CAMPURAN -> {}
        }

        // Hints
        if (hintsUsed == 0 && correctCount >= 7) {
            checkAndUnlock("badge_no_hints")
        }

        // Stars milestone
        if (totalStarsSum >= 15) {
            checkAndUnlock("badge_five_stars")
        }

        // Level milestone
        if (newLevel >= 5 || totalStarsSum >= 24) {
            checkAndUnlock("badge_explorer_master")
        }

        QuizResultSummary(
            category = category,
            ageBracket = ageBracket,
            totalQuestions = totalQuestions,
            correctCount = correctCount,
            starsEarned = stars,
            scorePercentage = percentage,
            hintsUsedCount = hintsUsed,
            records = records,
            newBadgesUnlocked = newlyUnlocked
        )
    }

    suspend fun resetAllProgress() = withContext(Dispatchers.IO) {
        dao.clearCategoryProgress()
        dao.clearProfile()
        dao.resetBadges()
        dao.clearHistory()
        QuestionBank.clearRecentHistory()
        AppDatabase.seedInitialData(dao)
    }
}
