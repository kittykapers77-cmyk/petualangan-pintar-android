package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "user_profile")
data class UserProfileEntity(
    @PrimaryKey val id: Int = 1,
    val selectedAgeId: String = "5-6",
    val soundEnabled: Boolean = true,
    val hapticEnabled: Boolean = true,
    val totalStars: Int = 0,
    val completedQuizzesCount: Int = 0,
    val explorerRank: String = "Penjelajah Pemula"
)

@Entity(tableName = "category_progress")
data class CategoryProgressEntity(
    @PrimaryKey val categoryId: String,
    val starsEarned: Int = 0,
    val highestScore: Int = 0,
    val timesPlayed: Int = 0,
    val currentLevel: Int = 1
)

@Entity(tableName = "badges")
data class BadgeEntity(
    @PrimaryKey val id: String,
    val title: String,
    val description: String,
    val emoji: String,
    val isUnlocked: Boolean = false,
    val unlockedAt: Long = 0L
)

@Entity(tableName = "quiz_history")
data class QuizHistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val categoryId: String,
    val ageBracketId: String,
    val score: Int,
    val totalQuestions: Int,
    val starsEarned: Int,
    val timestamp: Long = System.currentTimeMillis()
)
