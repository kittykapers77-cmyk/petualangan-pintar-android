package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Question
import com.example.ui.components.BigCartoonButton
import com.example.ui.theme.AdventureOrange
import com.example.ui.theme.CreamBackground
import com.example.ui.theme.ErrorSoft
import com.example.ui.theme.ExplorerBlue
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.SunnyYellow
import com.example.ui.viewmodel.QuizUiState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QuizScreen(
    state: QuizUiState,
    onSelectOption: (Int) -> Unit,
    onToggleHint: () -> Unit,
    onNextQuestion: () -> Unit,
    onRequestExit: () -> Unit,
    onConfirmExit: () -> Unit,
    onDismissExit: () -> Unit,
    showExitDialog: Boolean,
    modifier: Modifier = Modifier
) {
    val question = state.currentQuestion
    val questionIndex = state.currentIndex + 1
    val totalCount = state.questions.size
    val progressFraction = if (totalCount > 0) questionIndex.toFloat() / totalCount.toFloat() else 0f
    val categoryColor = Color(state.category.colorHex)

    if (showExitDialog) {
        AlertDialog(
            onDismissRequest = onDismissExit,
            title = {
                Text(
                    text = "Keluar dari Misi?",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
            },
            text = {
                Text(
                    text = "Progres kuis sesi ini tidak akan tersimpan jika kamu keluar sekarang.",
                    fontSize = 14.sp
                )
            },
            confirmButton = {
                TextButton(
                    onClick = onConfirmExit,
                    modifier = Modifier.testTag("confirm_exit_quiz")
                ) {
                    Text("Ya, Keluar", color = ErrorSoft, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(
                    onClick = onDismissExit,
                    modifier = Modifier.testTag("dismiss_exit_quiz")
                ) {
                    Text("Lanjutkan Main", fontWeight = FontWeight.Bold)
                }
            },
            shape = RoundedCornerShape(20.dp)
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                navigationIcon = {
                    IconButton(
                        onClick = onRequestExit,
                        modifier = Modifier.testTag("quiz_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Kembali ke Beranda",
                            tint = MaterialTheme.colorScheme.onSurface
                        )
                    }
                },
                title = {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = state.category.title,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 16.sp,
                                    color = categoryColor
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = categoryColor.copy(alpha = 0.15f)
                                ) {
                                    Text(
                                        text = question?.difficulty ?: "Mudah",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = categoryColor,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                            Text(
                                text = "Soal $questionIndex dari $totalCount",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        // Hint Action Button
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = if (state.isHintRevealed) SunnyYellow else Color(0xFFFEF3C7),
                            border = BorderStroke(1.dp, AdventureOrange),
                            modifier = Modifier
                                .clickable { onToggleHint() }
                                .testTag("quiz_hint_button")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Lightbulb,
                                    contentDescription = "Petunjuk",
                                    tint = AdventureOrange,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "Petunjuk",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF78350F)
                                )
                            }
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = CreamBackground
                )
            )
        },
        containerColor = CreamBackground,
        modifier = modifier
    ) { innerPadding ->
        if (question == null) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding),
                contentAlignment = Alignment.Center
            ) {
                Text("Memuat misi penjelajah...", fontSize = 16.sp)
            }
            return@Scaffold
        }

        BoxWithConstraints(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            val isTabletWide = maxWidth >= 600.dp
            val scrollState = rememberScrollState()

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(scrollState)
                    .padding(horizontal = if (isTabletWide) 32.dp else 16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Progress Bar
                LinearProgressIndicator(
                    progress = { progressFraction },
                    modifier = Modifier
                        .fillMaxWidth()
                        .widthIn(max = 640.dp)
                        .height(10.dp)
                        .clip(RoundedCornerShape(8.dp)),
                    color = categoryColor,
                    trackColor = Color(0xFFE2E8F0)
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Question Box
                QuestionCard(
                    question = question,
                    isHintRevealed = state.isHintRevealed,
                    categoryColor = categoryColor,
                    modifier = Modifier.widthIn(max = 640.dp)
                )

                Spacer(modifier = Modifier.height(20.dp))

                // Options List
                OptionsGroup(
                    question = question,
                    selectedOptionIndex = state.selectedOptionIndex,
                    isAnswerSubmitted = state.isAnswerSubmitted,
                    onSelect = onSelectOption,
                    modifier = Modifier.widthIn(max = 640.dp)
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Explanation & Next Button
                AnimatedVisibility(
                    visible = state.isAnswerSubmitted,
                    enter = fadeIn() + slideInVertically(
                        initialOffsetY = { 80 },
                        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy)
                    )
                ) {
                    val isCorrect = state.selectedOptionIndex == question.correctIndex
                    ExplanationFeedbackCard(
                        isCorrect = isCorrect,
                        explanation = question.explanation,
                        isLastQuestion = questionIndex >= totalCount,
                        onNext = onNextQuestion,
                        categoryColor = categoryColor,
                        modifier = Modifier.widthIn(max = 640.dp)
                    )
                }

                Spacer(modifier = Modifier.height(32.dp))
            }
        }
    }
}

@Composable
private fun QuestionCard(
    question: Question,
    isHintRevealed: Boolean,
    categoryColor: Color,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(26.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Visual Emoji Display
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = categoryColor.copy(alpha = 0.1f),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 14.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 18.dp, horizontal = 12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = question.visualEmoji,
                        fontSize = 32.sp,
                        textAlign = TextAlign.Center
                    )
                }
            }

            // Question Text
            Text(
                text = question.questionText,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
                textAlign = TextAlign.Center,
                lineHeight = 28.sp,
                modifier = Modifier.fillMaxWidth()
            )

            // Hint Drawer if expanded
            if (isHintRevealed) {
                Spacer(modifier = Modifier.height(14.dp))
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFEF9C3)),
                    border = BorderStroke(1.dp, Color(0xFFFACC15)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("💡", fontSize = 20.sp)
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "Petunjuk Penjelajah:",
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = Color(0xFF854D0E)
                            )
                            Text(
                                text = question.hint,
                                fontSize = 13.sp,
                                color = Color(0xFF713F12),
                                lineHeight = 18.sp
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun OptionsGroup(
    question: Question,
    selectedOptionIndex: Int?,
    isAnswerSubmitted: Boolean,
    onSelect: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        question.options.forEachIndexed { index, optionText ->
            val isSelected = selectedOptionIndex == index
            val isCorrectOption = index == question.correctIndex

            val (bgColor, borderColor, textColor) = when {
                !isAnswerSubmitted -> {
                    if (isSelected) {
                        Triple(Color(0xFFE0F2FE), ExplorerBlue, ExplorerBlue)
                    } else {
                        Triple(Color.White, Color(0xFFE2E8F0), MaterialTheme.colorScheme.onSurface)
                    }
                }
                isCorrectOption -> {
                    // Correct answer always glows green once submitted
                    Triple(Color(0xFFDCFCE7), SuccessGreen, Color(0xFF166534))
                }
                isSelected && !isCorrectOption -> {
                    // Chosen wrong answer shows soft red
                    Triple(Color(0xFFFEE2E2), ErrorSoft, Color(0xFF991B1B))
                }
                else -> {
                    Triple(Color(0xFFF8FAFC), Color(0xFFE2E8F0), Color.Gray)
                }
            }

            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = bgColor),
                border = BorderStroke(
                    width = if (isAnswerSubmitted && (isCorrectOption || isSelected)) 2.5.dp else 1.5.dp,
                    color = borderColor
                ),
                elevation = CardDefaults.cardElevation(if (isSelected || isCorrectOption) 4.dp else 2.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable(enabled = !isAnswerSubmitted) { onSelect(index) }
                    .testTag("quiz_option_$index")
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Option letter pill (A, B, C, D)
                    val letter = ('A' + index).toString()
                    Surface(
                        shape = CircleShape,
                        color = when {
                            isAnswerSubmitted && isCorrectOption -> SuccessGreen
                            isAnswerSubmitted && isSelected && !isCorrectOption -> ErrorSoft
                            else -> Color(0xFFE2E8F0)
                        },
                        modifier = Modifier.size(36.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            if (isAnswerSubmitted && isCorrectOption) {
                                Icon(
                                    imageVector = Icons.Default.Check,
                                    contentDescription = "Benar",
                                    tint = Color.White,
                                    modifier = Modifier.size(20.dp)
                                )
                            } else if (isAnswerSubmitted && isSelected && !isCorrectOption) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "Salah",
                                    tint = Color.White,
                                    modifier = Modifier.size(20.dp)
                                )
                            } else {
                                Text(
                                    text = letter,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    color = Color(0xFF334155)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.width(14.dp))

                    Text(
                        text = optionText,
                        fontSize = 17.sp,
                        fontWeight = if (isAnswerSubmitted && isCorrectOption) FontWeight.Bold else FontWeight.SemiBold,
                        color = textColor,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }
    }
}

@Composable
private fun ExplanationFeedbackCard(
    isCorrect: Boolean,
    explanation: String,
    isLastQuestion: Boolean,
    onNext: () -> Unit,
    categoryColor: Color,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isCorrect) Color(0xFFF0FDF4) else Color(0xFFFFFBEB)
        ),
        border = BorderStroke(
            1.5.dp,
            if (isCorrect) SuccessGreen else AdventureOrange
        ),
        elevation = CardDefaults.cardElevation(6.dp),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = if (isCorrect) "🎉 Hebat Sekali! Benar!" else "💡 Hampir Tepat! Yuk Pelajari:",
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 17.sp,
                    color = if (isCorrect) Color(0xFF15803D) else Color(0xFFB45309)
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = explanation,
                fontSize = 14.sp,
                lineHeight = 20.sp,
                color = MaterialTheme.colorScheme.onSurface
            )

            Spacer(modifier = Modifier.height(16.dp))

            BigCartoonButton(
                text = if (isLastQuestion) "Lihat Hasil Misi 🏆" else "Pertanyaan Berikutnya ➔",
                onClick = onNext,
                backgroundColor = if (isCorrect) SuccessGreen else categoryColor,
                modifier = Modifier.fillMaxWidth(),
                testTag = "quiz_next_button"
            )
        }
    }
}
