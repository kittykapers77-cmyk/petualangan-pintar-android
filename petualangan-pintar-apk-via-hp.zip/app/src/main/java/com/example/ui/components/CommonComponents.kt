package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AdventureOrange
import com.example.ui.theme.ErrorSoft
import com.example.ui.theme.ExplorerBlue
import com.example.ui.theme.JungleGreen
import com.example.ui.theme.StarEmpty
import com.example.ui.theme.StarGold
import com.example.ui.theme.SunnyYellow
import kotlin.random.Random

@Composable
fun BigCartoonButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    backgroundColor: Color = AdventureOrange,
    contentColor: Color = Color.White,
    icon: @Composable (() -> Unit)? = null,
    enabled: Boolean = true,
    testTag: String = "big_cartoon_button"
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.96f else 1.0f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
        label = "button_scale"
    )

    Button(
        onClick = onClick,
        enabled = enabled,
        shape = RoundedCornerShape(22.dp),
        interactionSource = interactionSource,
        colors = ButtonDefaults.buttonColors(
            containerColor = backgroundColor,
            contentColor = contentColor,
            disabledContainerColor = Color.LightGray,
            disabledContentColor = Color.White
        ),
        elevation = ButtonDefaults.buttonElevation(
            defaultElevation = 6.dp,
            pressedElevation = 2.dp
        ),
        modifier = modifier
            .scale(scale)
            .height(58.dp)
            .testTag(testTag)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            if (icon != null) {
                icon()
                Spacer(modifier = Modifier.width(8.dp))
            }
            Text(
                text = text,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.5.sp
            )
        }
    }
}

@Composable
fun StarRatingRow(
    stars: Int,
    maxStars: Int = 3,
    starSize: Int = 36,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier,
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        for (i in 1..maxStars) {
            val isEarned = i <= stars
            Icon(
                imageVector = Icons.Default.Star,
                contentDescription = if (isEarned) "Bintang Terisi" else "Bintang Kosong",
                tint = if (isEarned) StarGold else StarEmpty,
                modifier = Modifier
                    .size(starSize.dp)
                    .padding(horizontal = 4.dp)
            )
        }
    }
}

@Composable
fun ParentGateDialog(
    onDismiss: () -> Unit,
    onSuccess: () -> Unit,
    modifier: Modifier = Modifier
) {
    val num1 = remember { Random.nextInt(6, 10) }
    val num2 = remember { Random.nextInt(5, 10) }
    val correctAnswer = remember { num1 * num2 }

    var inputAnswer by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Lock,
                    contentDescription = null,
                    tint = ExplorerBlue,
                    modifier = Modifier.size(28.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Zona Orang Tua",
                    fontWeight = FontWeight.Bold,
                    fontSize = 20.sp
                )
            }
        },
        text = {
            Column {
                Text(
                    text = "Untuk masuk ke pengaturan suara & data, silakan jawab soal matematika di bawah ini:",
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(16.dp))
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "$num1 × $num2 = ?",
                            fontSize = 28.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = ExplorerBlue
                        )
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))
                OutlinedTextField(
                    value = inputAnswer,
                    onValueChange = {
                        inputAnswer = it.filter { char -> char.isDigit() }
                        errorMessage = null
                    },
                    label = { Text("Jawaban Anda") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    isError = errorMessage != null,
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("parent_gate_input")
                )
                if (errorMessage != null) {
                    Text(
                        text = errorMessage ?: "",
                        color = ErrorSoft,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val ans = inputAnswer.toIntOrNull()
                    if (ans == correctAnswer) {
                        onSuccess()
                    } else {
                        errorMessage = "Jawaban belum tepat, silakan coba lagi."
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = ExplorerBlue),
                modifier = Modifier.testTag("parent_gate_submit")
            ) {
                Text("Buka Pengaturan")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Batal")
            }
        },
        shape = RoundedCornerShape(24.dp),
        modifier = modifier.testTag("parent_gate_dialog")
    )
}

@Composable
fun TutorialDialog(
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "🧭 Panduan Penjelajah Cilik",
                    fontWeight = FontWeight.Bold,
                    fontSize = 20.sp
                )
            }
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                TutorialStepItem(
                    step = "1",
                    icon = "🎯",
                    title = "Pilih Usia & Kategori",
                    desc = "Pilih kelompok usia (5-6, 7-8, atau 9-10 tahun) dan pilih pulau petualangan yang ingin kamu jelajahi."
                )
                TutorialStepItem(
                    step = "2",
                    icon = "🧠",
                    title = "Jawab 10 Pertanyaan Seru",
                    desc = "Tiap misi terdiri dari 10 soal menyenangkan dengan tombol besar yang mudah ditekan."
                )
                TutorialStepItem(
                    step = "3",
                    icon = "💡",
                    title = "Gunakan Bantuan Petunjuk",
                    desc = "Jika bingung, tekan tombol Petunjuk untuk membantumu menemukan jawaban yang tepat."
                )
                TutorialStepItem(
                    step = "4",
                    icon = "⭐",
                    title = "Raih Bintang & Buka Lencana",
                    desc = "Kumpulkan bintang emas untuk menaikkan level pulau dan dapatkan lencana trofi penjelajah!"
                )
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = AdventureOrange),
                modifier = Modifier.testTag("tutorial_close_button")
            ) {
                Text("Saya Siap Berpetualang! 🚀")
            }
        },
        shape = RoundedCornerShape(24.dp),
        modifier = modifier.testTag("tutorial_dialog")
    )
}

@Composable
private fun TutorialStepItem(
    step: String,
    icon: String,
    title: String,
    desc: String
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.Top
    ) {
        Surface(
            shape = CircleShape,
            color = SunnyYellow,
            modifier = Modifier.size(36.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Text(
                    text = icon,
                    fontSize = 18.sp
                )
            }
        }
        Spacer(modifier = Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = desc,
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                lineHeight = 18.sp
            )
        }
    }
}
