package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.audio.SoundEffectManager
import com.example.data.local.AppDatabase
import com.example.data.local.CategoryProgressEntity
import com.example.data.local.UserProfileEntity
import com.example.data.model.AgeBracket
import com.example.data.model.BadgeInfo
import com.example.data.model.Question
import com.example.data.model.QuestionAnswerRecord
import com.example.data.model.QuizCategory
import com.example.data.model.QuizResultSummary
import com.example.data.repository.GameRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed class GameScreen {
    object Home : GameScreen()
    object Quiz : GameScreen()
    object Result : GameScreen()
    object Badges : GameScreen()
    object ParentSettings : GameScreen()
    object ReviewAnswers : GameScreen()
}

data class QuizUiState(
    val category: QuizCategory = QuizCategory.MATEMATIKA,
    val ageBracket: AgeBracket = AgeBracket.AGE_5_6,
    val questions: List<Question> = emptyList(),
    val currentIndex: Int = 0,
    val selectedOptionIndex: Int? = null,
    val isAnswerSubmitted: Boolean = false,
    val isHintRevealed: Boolean = false,
    val hintUsedForCurrentQuestion: Boolean = false,
    val records: List<QuestionAnswerRecord> = emptyList(),
    val isFinished: Boolean = false
) {
    val currentQuestion: Question?
        get() = questions.getOrNull(currentIndex)
}

class GameViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getInstance(application)
    private val repository = GameRepository(db.gameDao())
    val soundManager = SoundEffectManager(application)

    // Navigation state
    private val _currentScreen = MutableStateFlow<GameScreen>(GameScreen.Home)
    val currentScreen: StateFlow<GameScreen> = _currentScreen.asStateFlow()

    // Dialog flags
    private val _showTutorial = MutableStateFlow(false)
    val showTutorial: StateFlow<Boolean> = _showTutorial.asStateFlow()

    private val _showParentGate = MutableStateFlow(false)
    val showParentGate: StateFlow<Boolean> = _showParentGate.asStateFlow()

    private val _showExitQuizDialog = MutableStateFlow(false)
    val showExitQuizDialog: StateFlow<Boolean> = _showExitQuizDialog.asStateFlow()

    // Active Quiz state
    private val _quizState = MutableStateFlow(QuizUiState())
    val quizState: StateFlow<QuizUiState> = _quizState.asStateFlow()

    // Latest result
    private val _latestResult = MutableStateFlow<QuizResultSummary?>(null)
    val latestResult: StateFlow<QuizResultSummary?> = _latestResult.asStateFlow()

    // Database reactive streams
    val userProfile: StateFlow<UserProfileEntity> = repository.userProfile
        .stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            UserProfileEntity()
        )

    val categoryProgressList: StateFlow<List<CategoryProgressEntity>> = repository.categoryProgressList
        .stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )

    val badgesList: StateFlow<List<BadgeInfo>> = repository.allBadges
        .stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )

    init {
        viewModelScope.launch {
            userProfile.collect { profile ->
                soundManager.isSoundEnabled = profile.soundEnabled
                soundManager.isHapticEnabled = profile.hapticEnabled
            }
        }
    }

    fun navigateTo(screen: GameScreen) {
        soundManager.playClick()
        _currentScreen.value = screen
    }

    fun openTutorial() {
        soundManager.playClick()
        _showTutorial.value = true
    }

    fun closeTutorial() {
        soundManager.playClick()
        _showTutorial.value = false
    }

    fun openParentGate() {
        soundManager.playClick()
        _showParentGate.value = true
    }

    fun closeParentGate() {
        soundManager.playClick()
        _showParentGate.value = false
    }

    fun onParentGateSuccess() {
        soundManager.playCelebration()
        _showParentGate.value = false
        _currentScreen.value = GameScreen.ParentSettings
    }

    fun setAgeBracket(bracket: AgeBracket) {
        soundManager.playClick()
        viewModelScope.launch {
            repository.updateSelectedAge(bracket)
        }
    }

    fun updateSettings(sound: Boolean, haptic: Boolean, age: AgeBracket) {
        soundManager.isSoundEnabled = sound
        soundManager.isHapticEnabled = haptic
        if (sound) soundManager.playClick()
        viewModelScope.launch {
            repository.updateSettings(sound, haptic, age)
        }
    }

    fun resetAllProgress() {
        soundManager.playClick()
        viewModelScope.launch {
            repository.resetAllProgress()
            _currentScreen.value = GameScreen.Home
        }
    }

    fun startQuiz(category: QuizCategory) {
        soundManager.playClick()
        viewModelScope.launch {
            val ageBracket = AgeBracket.fromId(userProfile.value.selectedAgeId)
            val questions = repository.getQuestionsForQuiz(category, ageBracket)
            _quizState.value = QuizUiState(
                category = category,
                ageBracket = ageBracket,
                questions = questions,
                currentIndex = 0,
                selectedOptionIndex = null,
                isAnswerSubmitted = false,
                isHintRevealed = false,
                hintUsedForCurrentQuestion = false,
                records = emptyList(),
                isFinished = false
            )
            _currentScreen.value = GameScreen.Quiz
        }
    }

    fun selectOption(optionIndex: Int) {
        val state = _quizState.value
        if (state.isAnswerSubmitted) return // Already submitted for this question
        val question = state.currentQuestion ?: return

        val isCorrect = (optionIndex == question.correctIndex)
        if (isCorrect) {
            soundManager.playCorrect()
        } else {
            soundManager.playIncorrect()
        }

        val record = QuestionAnswerRecord(
            question = question,
            selectedOptionIndex = optionIndex,
            isCorrect = isCorrect,
            usedHint = state.hintUsedForCurrentQuestion
        )

        _quizState.value = state.copy(
            selectedOptionIndex = optionIndex,
            isAnswerSubmitted = true,
            records = state.records + record
        )
    }

    fun toggleHint() {
        val state = _quizState.value
        soundManager.playHint()
        _quizState.value = state.copy(
            isHintRevealed = !state.isHintRevealed,
            hintUsedForCurrentQuestion = true
        )
    }

    fun nextQuestion() {
        val state = _quizState.value
        soundManager.playClick()

        if (state.currentIndex + 1 < state.questions.size) {
            _quizState.value = state.copy(
                currentIndex = state.currentIndex + 1,
                selectedOptionIndex = null,
                isAnswerSubmitted = false,
                isHintRevealed = false,
                hintUsedForCurrentQuestion = false
            )
        } else {
            // Finish quiz and record results
            completeQuiz()
        }
    }

    private fun completeQuiz() {
        val state = _quizState.value
        viewModelScope.launch {
            val summary = repository.recordQuizCompletion(
                category = state.category,
                ageBracket = state.ageBracket,
                records = state.records
            )
            _latestResult.value = summary
            soundManager.playCelebration()
            _quizState.value = state.copy(isFinished = true)
            _currentScreen.value = GameScreen.Result
        }
    }

    fun requestExitQuiz() {
        soundManager.playClick()
        _showExitQuizDialog.value = true
    }

    fun confirmExitQuiz() {
        soundManager.playClick()
        _showExitQuizDialog.value = false
        _currentScreen.value = GameScreen.Home
    }

    fun dismissExitQuizDialog() {
        soundManager.playClick()
        _showExitQuizDialog.value = false
    }

    override fun onCleared() {
        super.onCleared()
        soundManager.release()
    }
}
