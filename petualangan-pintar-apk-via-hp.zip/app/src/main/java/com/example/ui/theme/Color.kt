package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary & Accent Palette (Ceria & Ramah Anak)
val SunnyYellow = Color(0xFFFFB703)
val AdventureOrange = Color(0xFFFB8500)
val ExplorerBlue = Color(0xFF0077B6)
val SkyBlueLight = Color(0xFFE0F2FE)
val JungleGreen = Color(0xFF38B000)
val JungleGreenLight = Color(0xFFE8F5E9)
val MagicPurple = Color(0xFF7209B7)
val MagicPurpleLight = Color(0xFFF3E8FF)
val CoralRed = Color(0xFFE76F51)
val CoralRedLight = Color(0xFFFFEBE8)

val CreamBackground = Color(0xFFFFFDF5)
val SurfaceCard = Color(0xFFFFFFFF)
val TextDark = Color(0xFF1E293B)
val TextMedium = Color(0xFF64748B)

val StarGold = Color(0xFFFFC107)
val StarEmpty = Color(0xFFCBD5E1)
val SuccessGreen = Color(0xFF22C55E)
val ErrorSoft = Color(0xFFEF4444)
