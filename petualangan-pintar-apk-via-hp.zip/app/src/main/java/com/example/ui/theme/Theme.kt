package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

private val PlayfulColorScheme = lightColorScheme(
    primary = AdventureOrange,
    onPrimary = SurfaceCard,
    primaryContainer = SunnyYellow,
    onPrimaryContainer = TextDark,
    secondary = ExplorerBlue,
    onSecondary = SurfaceCard,
    secondaryContainer = SkyBlueLight,
    onSecondaryContainer = ExplorerBlue,
    tertiary = JungleGreen,
    onTertiary = SurfaceCard,
    tertiaryContainer = JungleGreenLight,
    onTertiaryContainer = JungleGreen,
    background = CreamBackground,
    onBackground = TextDark,
    surface = SurfaceCard,
    onSurface = TextDark,
    surfaceVariant = SkyBlueLight,
    onSurfaceVariant = TextMedium
)

val PlayfulShapes = Shapes(
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(20.dp),
    large = RoundedCornerShape(28.dp),
    extraLarge = RoundedCornerShape(36.dp)
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = false, // Always vibrant cheerful light palette for kids
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = PlayfulColorScheme,
        typography = Typography,
        shapes = PlayfulShapes,
        content = content
    )
}
